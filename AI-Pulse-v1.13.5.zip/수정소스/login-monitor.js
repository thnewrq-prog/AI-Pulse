/* Only a tab opened by Account Connect is eligible for automatic closing. */
const loginProbes=new Set(),loginRetryTimers=new Map();
async function closeConnectedLogin(id){
 const {pulseRuntime={}}=await api.storage.session.get('pulseRuntime'),request=pulseRuntime.autoCloseLogins?.[id];
 if(!request||pulseRuntime.pickers?.[id])return false;
 if(Date.now()>request.expires){await session(s=>{delete s.autoCloseLogins?.[id];});return false;}
 try{const tab=await api.tabs.get(request.tabId);if(!PulseConnection.allowed(tab.url,id))return false;
 await api.tabs.remove(request.tabId);await session(s=>{delete s.autoCloseLogins?.[id];if(s.loginTabs[id]===request.tabId)delete s.loginTabs[id];});return true;
 }catch{return false;}
}
async function probeConnectedLogin(id){
 if(loginProbes.has(id))return;loginProbes.add(id);
 if(loginRetryTimers.has(id)){clearTimeout(loginRetryTimers.get(id));loginRetryTimers.delete(id);}
 let retrySuno=false;
 try{
  const {pulseRuntime={}}=await api.storage.session.get('pulseRuntime'),r=pulseRuntime.autoCloseLogins?.[id];if(!r||pulseRuntime.pickers?.[id])return;
  if(Date.now()>r.expires){await session(s=>{delete s.autoCloseLogins?.[id];});return;}
  const {pulse=emptyState()}=await api.storage.local.get('pulse');syncCustomProviders(pulse.customProviders);if(!pulse.connections?.[id]?.enabled)return;
  const tab=await api.tabs.get(r.tabId);if(tab.status!=='complete'||!PulseConnection.allowed(tab.url,id))return;
  let sunoSession=false;
  if(id==='suno')try{
   const auth=await api.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>{
    // Return a boolean only. No cookie, token, account ID, or session ID leaves the page.
    const c=globalThis.Clerk;return !!(c?.loaded&&c.user?.id&&c.session?.id&&c.session.status==='active');
   }});sunoSession=auth[0]?.result===true;
  }catch{}
  await inject(tab.id);const results=await api.scripting.executeScript({target:{tabId:tab.id},func:async(id,binding,sunoSession=false)=>{
   const creditLogin=['comfy','suno','higgsfield'].includes(id);
   const shown=e=>!!e&&!e.closest('[hidden],[aria-hidden="true"]')&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
   const label=e=>((e.getAttribute('aria-label')||'')+' '+(e.innerText||'')).replace(/\s+/g,' ').trim();
   if(creditLogin){
    // Never close a page while credentials, verification, or consent are pending.
    const pendingAuth=()=>{
    const authRoute=/\/(?:sign-?in|log-?in|auth|oauth|callback|verify|verification)(?:\/|$)/i.test(location.pathname);
    const inputs=[...document.querySelectorAll('input[type="password"],input[autocomplete="one-time-code"],input[name="otp"],iframe[src*="captcha"],iframe[src*="challenge"]')].some(shown);
    const authDialog=[...document.querySelectorAll('[role="dialog"],[aria-modal="true"]')].some(e=>shown(e)&&/sign\s*in|log\s*in|로그인|verify\s+(?:your|email|identity)|verification\s*code|인증\s*(?:코드|번호)|동의|consent/i.test(label(e)));
    return authRoute||inputs||authDialog;
    };
    if(pendingAuth())return {confirmed:false,account:false};
    const signedIn=()=>{
     // Comfy renders this control only when isLoggedIn is true.
     if(id==='comfy'&&[...document.querySelectorAll('[data-testid="current-user-button"]')].some(shown))return true;
     if([...document.querySelectorAll('button.cl-userButtonTrigger')].some(shown))return true;
     if(id==='suno'&&sunoSession)return true;
     const controls=[...document.querySelectorAll('[role="menuitem"],button,a,[role="button"]')];
     const logout=/^(?:sign\s*out|log\s*out|로그아웃)(?:\s*[↗→])?$/i;
     // aria-label and visible text can both say "Sign out"; test each independently.
     return controls.some(e=>shown(e)&&[e.getAttribute('aria-label')||'',e.innerText||''].some(value=>logout.test(value.trim())));
    };
    let account=signedIn();
    if(!account){
     // Reveal only the account/avatar menu, never a purchase or sign-in action.
     const explicit='[data-testid="user-menu-button"],[data-testid="profile-button"],[aria-label="User menu"],[aria-label="Account menu"],[aria-label="Profile menu"],[aria-label="프로필 메뉴"],[aria-label="계정 메뉴"],[aria-label="Open user menu"],[aria-label="Open profile menu"],[data-testid="user-menu-trigger"]';
     const avatars='header button[aria-haspopup],aside button[aria-haspopup],nav button[aria-haspopup],[role="navigation"] button[aria-haspopup],button[data-slot="dropdown-menu-trigger"]';
     const trigger=[...document.querySelectorAll(explicit+','+avatars)].find(e=>shown(e)&&!e.disabled&&!/sign\s*(?:in|up)|log\s*in|로그인|가입|guest|게스트|buy|upgrade|구매|충전/i.test(label(e))&&(e.matches(explicit)||e.querySelector('img[alt*="avatar" i],img[alt*="profile" i],img[alt*="user" i],[class*="avatar" i]')));
     if(trigger&&trigger.getAttribute('aria-expanded')!=='true'){
      trigger.click();await new Promise(resolve=>setTimeout(resolve,350));account=signedIn();
     }
    }
    if(pendingAuth())return {confirmed:false,account:false};
    if(account)return {confirmed:true,account:true,read:{metrics:[]}};
   }
   let read;
   try{read=globalThis.PulseCollector?.collect(id,binding);}catch(e){if(!creditLogin)throw e;}
   const metrics=read?.metrics||[];
   const visible=e=>e&&e.getClientRects().length>0;
   const selectors={gemini:'[aria-label^="Google 계정:"],[aria-label^="Google Account:"],a[href*="accounts.google.com/SignOutOptions"]',gpt:'[data-testid="accounts-profile-button"],[data-testid="profile-button"]',claude:'[data-testid="user-menu-button"],[aria-label="User menu"]'};
   const account=selectors[id]&&[...document.querySelectorAll(selectors[id])].some(e=>visible(e)&&!/로그인|log in|sign in|guest|게스트/i.test((e.getAttribute('aria-label')||'')+' '+(e.innerText||'')));
   return {confirmed:metrics.length>0||!!account,account:!!account,read};
  },args:[id,pulse.connections[id].binding||null,sunoSession]});
  const data=results[0]?.result;if(!data?.confirmed){retrySuno=id==='suno';return;}
  const metrics=PulseConnection.cleanMetrics(data.read?.metrics);if(!metrics.length&&!data.account)return;await mutate(s=>{if(!s.connections[id])return;s.connections[id].loginConfirmedAt=new Date().toISOString();if(metrics.length){s.connections[id].lastSuccessAt=s.connections[id].loginConfirmedAt;s.snapshots[id]={id,status:'ok',metrics,checkedAt:new Date().toISOString(),mode:'screen',message:'계정 연결을 확인했습니다.'};}});
  await closeConnectedLogin(id);
 }catch{}finally{loginProbes.delete(id);if(retrySuno)loginRetryTimers.set(id,setTimeout(()=>{loginRetryTimers.delete(id);probeConnectedLogin(id);},3000));}
}
async function monitorConnectedLogin(id,tabId){await session(s=>{s.autoCloseLogins||={};s.autoCloseLogins[id]={tabId,expires:Date.now()+600000};});
 const delays=['comfy','suno','higgsfield'].includes(id)?[1000,3000,5000,8000,12000,20000,30000]:[1000,4000,7000];
 for(const delay of delays)setTimeout(()=>probeConnectedLogin(id),delay);
}
api.tabs.onUpdated.addListener((tabId,change)=>{if(change.status!=='complete'&&!change.url)return;ready.then(async()=>{const {pulseRuntime={}}=await api.storage.session.get('pulseRuntime');for(const [id,r] of Object.entries(pulseRuntime.autoCloseLogins||{}))if(r.tabId===tabId&&(change.status==='complete'||id==='suno'&&change.url))probeConnectedLogin(id);}).catch(()=>{});});
api.alarms.onAlarm.addListener(a=>{if(a.name!=='pulse-login-monitor')return;ready.then(async()=>{const {pulseRuntime={}}=await api.storage.session.get('pulseRuntime');for(const id of Object.keys(pulseRuntime.autoCloseLogins||{}))probeConnectedLogin(id);}).catch(()=>{});});
ready.then(()=>api.alarms.create('pulse-login-monitor',{periodInMinutes:1})).catch(()=>{});

