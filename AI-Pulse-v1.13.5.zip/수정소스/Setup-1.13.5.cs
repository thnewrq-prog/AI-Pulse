﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Windows.Forms;
[assembly: AssemblyTitle("AI Pulse 트레이 중복·Suno 연결 수정 설치")]
[assembly: AssemblyVersion("1.13.5.0")]
[assembly: AssemblyFileVersion("1.13.5.0")]
class Setup {
 [STAThread] static void Main(){
  Application.EnableVisualStyles();
  string dir=Path.Combine(Path.GetTempPath(),"AI-Pulse-1.13.5-"+Guid.NewGuid().ToString("N"));
  try {
   if(Process.GetProcessesByName("AIPulseDesktop").Length>0){MessageBox.Show("트레이의 AI Pulse를 종료하고 브라우저를 닫은 뒤 설치 파일을 다시 실행해 주세요.","AI Pulse 업데이트");return;}
   Directory.CreateDirectory(dir);string path=Path.Combine(dir,"AI-Pulse-v1.13.5.msi");
   using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.msi"))using(var output=File.Create(path)){input.CopyTo(output);}
   using(var sha=SHA256.Create())using(var stream=File.OpenRead(path)){if(BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","")!="950C118D0A7DF00CC77C4012FC876FEA9F57B3366E24059CB1E54EEEF9EB764E")throw new Exception("설치 파일 무결성 검증 실패");}
   var p=Process.Start(new ProcessStartInfo("msiexec.exe","/i \""+path+"\" /norestart"){UseShellExecute=true});p.WaitForExit();
   if(p.ExitCode==1602)return;
   if(p.ExitCode==3010){MessageBox.Show("설치가 완료되었습니다. Windows를 다시 시작해 주세요.","AI Pulse");return;}
   if(p.ExitCode!=0)throw new Exception("Windows Installer 오류 코드: "+p.ExitCode);
   string app=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"AIPulse","AIPulseDesktop.exe");
   if(File.Exists(app))Process.Start(new ProcessStartInfo(app){UseShellExecute=true});
   MessageBox.Show("AI Pulse 1.13.5 설치가 완료되었습니다.\n브라우저를 다시 실행하고 확장 관리에서 AI Pulse를 새로고침해 주세요.\n트레이 중복 표시 및 Suno 계정 연결 후 창 닫힘을 수정했습니다.","AI Pulse");
  }catch(Exception e){MessageBox.Show(e.Message,"AI Pulse 설치 오류",MessageBoxButtons.OK,MessageBoxIcon.Error);}
  finally{try{Directory.Delete(dir,true);}catch{}}
 }
}







