$ErrorActionPreference='Stop'
Add-Type -Path (Resolve-Path work/mono.cecil/lib/net40/Mono.Cecil.dll)
Add-Type -Path (Resolve-Path work/mono.cecil/lib/net40/Mono.Cecil.Rocks.dll)
$rp=[Mono.Cecil.ReaderParameters]::new();$rp.ReadingMode=[Mono.Cecil.ReadingMode]::Immediate
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Resolve-Path work/AIPulseDesktop-before-tray.exe),$rp)
$d=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Resolve-Path work/TrayCoordinator.dll),$rp)
$module=$a.MainModule;$type=$d.MainModule.Types|Where-Object Name -eq TrayCoordinator
$methods=@{};$fields=@{};foreach($m in $type.Methods){$methods[$m.FullName]=$m};foreach($f in $type.Fields){$fields[$f.FullName]=$f}
$type.BaseType=$module.ImportReference($type.BaseType)
foreach($i in $type.Interfaces){$i.InterfaceType=$module.ImportReference($i.InterfaceType)}
foreach($f in $type.Fields){$f.FieldType=$module.ImportReference($f.FieldType)}
foreach($m in $type.Methods){
 $m.ReturnType=$module.ImportReference($m.ReturnType);foreach($p in $m.Parameters){$p.ParameterType=$module.ImportReference($p.ParameterType)}
 if(!$m.HasBody){continue}
 foreach($v in $m.Body.Variables){$v.VariableType=if($v.VariableType.FullName -eq $type.FullName){$type}else{$module.ImportReference($v.VariableType)}}
 foreach($e in $m.Body.ExceptionHandlers){if($e.CatchType){$e.CatchType=$module.ImportReference($e.CatchType)}}
 foreach($i in $m.Body.Instructions){
  if($i.Operand -is [Mono.Cecil.MethodReference]){if($methods.ContainsKey($i.Operand.FullName)){$i.Operand=$methods[$i.Operand.FullName]}else{$i.Operand=$module.ImportReference($i.Operand)}}
  elseif($i.Operand -is [Mono.Cecil.FieldReference]){if($fields.ContainsKey($i.Operand.FullName)){$i.Operand=$fields[$i.Operand.FullName]}else{$i.Operand=$module.ImportReference($i.Operand)}}
  elseif($i.Operand -is [Mono.Cecil.TypeReference]){$i.Operand=if($i.Operand.FullName -eq $type.FullName){$type}else{$module.ImportReference($i.Operand)}}
 }
}
[void]$d.MainModule.Types.Remove($type);$module.Types.Add($type)
$desktop=$module.Types|Where-Object Name -eq Desktop
$ctor=$desktop.Methods|Where-Object Name -eq '.ctor'
$visible=$ctor.Body.Instructions|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.FullName -match 'NotifyIcon::set_Visible'}
if(@($visible).Count -ne 1 -or $visible.Previous.OpCode.Code -ne [Mono.Cecil.Cil.Code]::Ldc_I4_1){throw 'Unexpected initial tray visibility'}
$visible.Previous.OpCode=[Mono.Cecil.Cil.OpCodes]::Ldc_I4_0
$ret=$ctor.Body.Instructions|Where-Object OpCode -eq ([Mono.Cecil.Cil.OpCodes]::Ret)|Select-Object -Last 1
$tray=$desktop.Fields|Where-Object Name -eq tray
$ops=@([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldarg_1),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Brtrue,$ret),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldarg_0),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldarg_0),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldfld,$tray),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call,($type.Methods|Where-Object Name -eq Attach)))
foreach($i in $ctor.Body.Instructions){if($i.Operand -eq $ret){$i.Operand=$ops[0]}}
$il=$ctor.Body.GetILProcessor();foreach($op in $ops){$il.InsertBefore($ret,$op)}
[Mono.Cecil.Rocks.MethodBodyRocks]::SimplifyMacros($ctor.Body)
$render=$desktop.Methods|Where-Object Name -eq Render
$store=$render.Body.Instructions|Where-Object {$_.OpCode.Code -eq [Mono.Cecil.Cil.Code]::Stfld -and $_.Operand.Name -eq 'lastPulse'}
$next=$store.Next;$pulse=$desktop.Fields|Where-Object Name -eq lastPulse
$ops=@([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldarg_0),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldarg_0),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldfld,$pulse),[Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call,($type.Methods|Where-Object Name -eq Snapshot)))
$il=$render.Body.GetILProcessor();foreach($op in $ops){$il.InsertBefore($next,$op)}
[Mono.Cecil.Rocks.MethodBodyRocks]::SimplifyMacros($render.Body)
$a.Name.Version=[Version]'1.13.5.0';foreach($ca in $a.CustomAttributes){if($ca.AttributeType.FullName -eq 'System.Reflection.AssemblyFileVersionAttribute'){$ca.ConstructorArguments[0]=[Mono.Cecil.CustomAttributeArgument]::new($module.TypeSystem.String,'1.13.5.0')}}
$a.Write((Join-Path (Resolve-Path work/build) 'AIPulseDesktop.exe'))
'Embedded coordinated tray ownership; patched constructor and snapshot rendering'
