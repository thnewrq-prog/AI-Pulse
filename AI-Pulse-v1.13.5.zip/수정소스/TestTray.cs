﻿using System;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using System.Reflection;
using System.Runtime.CompilerServices;
class TestTray {
 static Type t;static int n;static HashSet<int> shown=new HashSet<int>();static Dictionary<int,long> live=new Dictionary<int,long>();
 static object Call(string name,params object[] args){return t.GetMethod(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,args);}
 static void Assert(bool condition,string name){if(!condition)throw new Exception(name);n++;Console.WriteLine("PASS "+name);}
 static void Step(MemoryMappedViewAccessor s,int pid,int score){
  Func<int,long,bool> alive=delegate(int p,long start){return live.ContainsKey(p)&&live[p]==start;};
  Action hide=delegate{shown.Remove(pid);};Action show=delegate{shown.Add(pid);};Call("Evaluate",s,pid,live[pid],score,alive,hide,show);if(shown.Count>1)throw new Exception("Duplicate tray ownership");
 }
 static int Main(string[] args){try{
  var a=Assembly.LoadFrom(args[0]);t=a.GetType("TrayCoordinator");
  using(var map=MemoryMappedFile.CreateNew(null,128))using(var s=map.CreateViewAccessor()){
   live[101]=1001;live[202]=2002;live[303]=3003;
   Step(s,101,0);Assert(shown.SetEquals(new[]{101}),"one empty profile gets one usable tray");
   Step(s,202,7);Assert(shown.SetEquals(new[]{101}),"populated browser requests takeover without creating second icon");
   Step(s,101,0);Assert(shown.Count==0&&s.ReadInt32(0)==202,"old empty tray hides before ownership transfers");
   Step(s,202,7);Assert(shown.SetEquals(new[]{202}),"populated browser becomes sole visible tray");
   for(int i=0;i<20;i++){Step(s,101,0);Step(s,303,0);Step(s,202,7);}Assert(shown.SetEquals(new[]{202}),"empty profiles stay hidden across repeated updates");
   Step(s,303,7);Assert(shown.SetEquals(new[]{202})&&s.ReadInt32(24)==0,"equal connected profiles do not oscillate");
   Step(s,303,8);Step(s,202,7);Step(s,303,8);Assert(shown.SetEquals(new[]{303}),"higher populated profile takeover keeps one visible tray");
   shown.Remove(303);live.Remove(303);Step(s,202,7);Assert(shown.SetEquals(new[]{202}),"surviving connection takes over after owner exits");
   shown.Remove(202);live[202]=9999;Step(s,101,0);Assert(shown.SetEquals(new[]{101}),"reused process ID does not retain stale ownership");
  }
  var conn=new Dictionary<string,object>{{"a",new Dictionary<string,object>{{"enabled",true}}},{"b",new Dictionary<string,object>{{"enabled",false}}},{"c",new Dictionary<string,object>{{"enabled",true}}}};
  Assert((int)Call("Score",new Dictionary<string,object>{{"connections",conn}})==2,"only enabled service connections contribute to tray priority");
  Assert((int)Call("Score",new Dictionary<string,object>())==0,"empty snapshots handled");
  foreach(var m in t.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance|BindingFlags.DeclaredOnly))if(m.GetMethodBody()!=null)RuntimeHelpers.PrepareMethod(m.MethodHandle);
  foreach(var ctor in t.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance))RuntimeHelpers.PrepareMethod(ctor.MethodHandle);
  Console.WriteLine("PASS JIT preparation of all embedded coordinator methods and constructor");Console.WriteLine(n+" tray ownership checks passed; no tray icon or application window created");return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
