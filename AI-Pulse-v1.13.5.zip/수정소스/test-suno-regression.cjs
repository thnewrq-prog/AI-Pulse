const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const source=fs.readFileSync('work/app/AI-Pulse/login-monitor.js','utf8');let count=0;
async function check(id,name,o={},expected=false){
 const removed=[],timers=[];let opened=false,reads=0;
 function element(text='',hidden=false,attrs={}){return {innerText:text,disabled:false,getClientRects:()=>hidden?[]:[{}],closest:()=>null,getAttribute:n=>attrs[n]||null,matches:()=>true,querySelector:()=>null,click(){opened=true}}}
 const logout=element(o.logout||'Sign out',o.hidden,{'aria-label':o.logoutAria||''}),trigger=element(o.guest?'Guest':'Profile',false,{'aria-expanded':o.expanded?'true':'false'}),current=element('Current user',o.hidden),auth=element('Verify your identity');
 const doc={querySelectorAll(sel){
  if(sel.includes('input[type='))return o.password?[auth]:[];
  if(sel==='[role="dialog"],[aria-modal="true"]')return o.authDialog||o.dialogAfterOpen&&opened?[auth]:[];
  if(sel==='[data-testid="current-user-button"]')return o.comfyButton?[current]:[];
  if(sel==='button.cl-userButtonTrigger')return o.clerk?[current]:[];
  if(sel==='[role="menuitem"],button,a,[role="button"]')return o.signedIn||opened&&!o.dialogAfterOpen?[logout]:[];
  if(sel.includes('[data-testid="user-menu-button"]'))return o.menu?[trigger]:[];
  return [];
 }};
 const runtime={loginTabs:{[id]:7},autoCloseLogins:o.manual?{}:{[id]:{tabId:7,expires:Date.now()+(o.expired?-1:600000)}},pickers:o.picker?{[id]:{}}:{}};
 const pulse={snapshots:{},connections:{[id]:{enabled:!o.disconnected}}};const event={addListener(){}};
 const c={console,Date,URL,Set,Map,clearTimeout(){},Clerk:o.session?{loaded:true,user:{id:'test-user-not-returned'},session:{id:'test-session-not-returned',status:o.sessionStatus||'active'}}:undefined,document:doc,location:{pathname:o.authRoute?'/auth/callback':'/account'},getComputedStyle:()=>({visibility:'visible'}),setTimeout:(fn,ms)=>{timers.push(ms);if(ms===350)fn()},ready:new Promise(()=>{}),emptyState:()=>({}),syncCustomProviders(){},inject:async()=>{},PulseConnection:{allowed:()=>!o.wrongOrigin,cleanMetrics:a=>a||[]},PulseCollector:{collect:()=>{reads++;if(o.collectorError)throw Error('layout changed');return {metrics:o.balance?[{kind:'balance',amount:100,unit:'credits'}]:[]}}},session:async fn=>fn(runtime),mutate:async fn=>fn(pulse),api:{storage:{session:{get:async()=>({pulseRuntime:runtime})},local:{get:async()=>({pulse})}},tabs:{get:async()=>({id:7,status:'complete',url:'https://example.test/account'}),remove:async id=>removed.push(id),onUpdated:event},alarms:{onAlarm:event},scripting:{executeScript:async opts=>[{result:await opts.func(...(opts.args||[]))}]}}};
 vm.createContext(c);vm.runInContext(source,c);await c.probeConnectedLogin(id);
 assert.equal(removed.length,expected?1:0,id+': '+name);
 if(expected){assert(pulse.connections[id].loginConfirmedAt);if(!o.balance)assert.equal(pulse.snapshots[id],undefined);assert.equal(runtime.autoCloseLogins[id],undefined)}
 if(expected&&(o.comfyButton||o.clerk||o.signedIn||o.session))assert.equal(reads,0,'account detection independent of balance reader');
 count++;console.log('PASS '+id+' '+name);
}
(async()=>{
 for(const id of ['comfy','suno','higgsfield']){
  await check(id,'authenticated menu without readable balance',{signedIn:true},true);
  await check(id,'Korean logout menu',{signedIn:true,logout:'로그아웃'},true);
  await check(id,'log out spelling',{signedIn:true,logout:'Log out'},true);
  await check(id,'reveal account menu',{menu:true},true);
  await check(id,'signed-in Clerk control',{clerk:true},true);
  await check(id,'unreadable balance and no proof remains open');
  await check(id,'readable balance still closes',{balance:true},true);
  await check(id,'collector errors do not block account confirmation',{signedIn:true,collectorError:true},true);
  await check(id,'collector errors without proof remain open',{collectorError:true});
  await check(id,'password prompt blocks closing',{signedIn:true,password:true,balance:true});
  await check(id,'verification dialog blocks closing',{signedIn:true,authDialog:true,balance:true});
  await check(id,'authentication callback blocks closing',{signedIn:true,authRoute:true,balance:true});
  await check(id,'dialog opened by profile control stays open',{menu:true,dialogAfterOpen:true,balance:true});
  await check(id,'guest menu is not opened',{menu:true,guest:true});
  await check(id,'hidden logout ignored',{signedIn:true,hidden:true});
  await check(id,'manual official page preserved',{manual:true,signedIn:true});
  await check(id,'balance picker preserved',{picker:true,signedIn:true});
  await check(id,'expired watch preserved',{expired:true,signedIn:true});
  await check(id,'disconnected service preserved',{disconnected:true,signedIn:true});
  await check(id,'foreign origin preserved',{wrongOrigin:true,signedIn:true});
 }
 await check('comfy','authenticated current user button without balance',{comfyButton:true},true);
 await check('comfy','hidden current user button ignored',{comfyButton:true,hidden:true});
 for(const id of ['gemini','gpt','claude','midjourney']){await check(id,'existing metrics path retained',{balance:true},true);await check(id,'targeted menu logic does not affect other services',{signedIn:true});}
 await check('suno','active page session without menu or readable balance',{session:true},true);
 await check('suno','pending MFA session remains open',{session:true,sessionStatus:'pending'});
 await check('suno','signed-out session remains open',{session:true,sessionStatus:'ended'});
 await check('suno','active session with verification dialog stays open',{session:true,authDialog:true});
 await check('suno','active session on auth callback stays open',{session:true,authRoute:true});
 await check('suno','active session with password prompt stays open',{session:true,password:true});
 await check('suno','active session never closes manual page',{session:true,manual:true});
 await check('suno','active session never closes balance picker',{session:true,picker:true});
 await check('suno','active session after watch expires remains open',{session:true,expired:true});
 await check('suno','duplicate aria-label and text logout detection',{signedIn:true,logout:'Sign out',logoutAria:'Sign out'},true);
 await check('suno','Korean duplicated logout detection',{signedIn:true,logout:'로그아웃',logoutAria:'로그아웃'},true);
 console.log(count+' login behavior checks passed');
})().catch(e=>{console.error(e);process.exit(1)});

