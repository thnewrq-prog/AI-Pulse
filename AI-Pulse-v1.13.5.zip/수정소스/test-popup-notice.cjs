const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const original=fs.readFileSync('work/v1.13.5/extracted/AI-Pulse/popup.js','utf8');
const patched=fs.readFileSync('work/popup-notice-fix/popup.js','utf8');
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
function boot(source){
 const nodes=new Map();const node=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',disabled:false});return nodes.get(id);};
 const timers=new Map(),posts=[];let next=0,receive;
 const c={console,Map,Set,Promise,Error,Number,Math,Date,devicePixelRatio:1,
  setTimeout(fn,ms){const id=++next;timers.set(id,{fn,ms});return id;},clearTimeout(id){timers.delete(id);},
  requestAnimationFrame(fn){fn();},document:{getElementById:node,body:{getBoundingClientRect:()=>({height:500})}},
  chrome:{webview:{postMessage:m=>posts.push(m),addEventListener:(event,fn)=>{receive=fn;}}},
  PulseI18n:{getLang:()=> 'ko',setLang(){},applyStaticDOM(){},t:key=>key,locale:()=> 'ko-KR',translateMetricLabel:x=>x},
  PulseLayout:{visible:()=>[],refreshOrder:ids=>ids},syncCustomProviders(){},PROVIDERS:{},PulseRefreshWarning:{notify(){}}
 };
 vm.runInNewContext(source,c);
 return {node,posts,timers,message:msg=>receive({data:msg}),fire(ms){for(const [id,t] of [...timers])if(t.ms===ms&&timers.has(id)){timers.delete(id);t.fn();}},state(){receive({data:{type:'pulse-state',state:{connections:{},snapshots:{},jobs:{},customProviders:{},language:'ko'}}});}};
}
(async()=>{
 let h=boot(original);h.fire(120000);await flush();assert.match(h.node('notice').textContent,/응답이 지연/);h.fire(6000);assert.match(h.node('notice').textContent,/응답이 지연/);console.log('REPRODUCED original timeout notice remains indefinitely');
 h=boot(patched);h.fire(120000);await flush();assert.match(h.node('notice').textContent,/응답이 지연/);h.fire(6000);assert.equal(h.node('notice').textContent,'');console.log('PASS timeout remains visible briefly then clears');
 h=boot(patched);h.state();await flush();assert.equal([...h.timers.values()].filter(t=>t.ms===120000).length,0);h.fire(120000);await flush();assert.equal(h.node('notice').textContent,'');console.log('PASS valid state fulfills initial read; no later false timeout');
 h=boot(patched);h.fire(120000);await flush();h.state();await flush();assert.equal(h.node('notice').textContent,'');console.log('PASS recovered state immediately clears old timeout');
 h=boot(patched);h.state();await flush();await h.node('refreshAll').onclick();const oldTimer=[...h.timers.keys()][0];await h.node('refreshAll').onclick();assert(!h.timers.has(oldTimer));assert.equal(h.node('notice').textContent,'popup.needConnect');h.fire(6000);assert.equal(h.node('notice').textContent,'');console.log('PASS replacement notice cancels earlier expiration');
 h=boot(patched);h.state();await flush();const opening=h.node('openDashboard').onclick();h.state();await flush();assert.equal([...h.timers.values()].filter(t=>t.ms===120000).length,1);h.fire(120000);await opening;assert.match(h.node('notice').textContent,/응답이 지연/);h.fire(6000);assert.equal(h.node('notice').textContent,'');console.log('PASS state update does not falsely complete dashboard command');
 h=boot(patched);h.state();await flush();await h.node('refreshAll').onclick();const opened=h.node('openDashboard').onclick();const request=h.posts.filter(m=>m.type==='open-dashboard').at(-1);h.message({type:'desktop-response',requestId:request.requestId,result:{ok:true}});await opened;assert.equal(h.node('notice').textContent,'');assert(h.posts.some(m=>m.type==='hide-popup'));console.log('PASS successful command clears notice and preserves popup action');
 console.log('6 regression checks passed; original issue reproduced.');
})().catch(e=>{console.error(e);process.exitCode=1;});
