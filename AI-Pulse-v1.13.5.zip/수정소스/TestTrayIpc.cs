using System;
using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.Reflection;
using System.Threading;
class TestTrayIpc {
 static int Main(string[] args){try{
  if(args.Length>1&&args[1]=="child"){
   string channel=args[2];int score=int.Parse(args[3]);var t=Assembly.LoadFrom(args[0]).GetType("TrayCoordinator");var eval=t.GetMethod("Evaluate");int pid=Process.GetCurrentProcess().Id;long started=Process.GetCurrentProcess().StartTime.ToUniversalTime().Ticks;
   using(var map=MemoryMappedFile.OpenExisting(channel))using(var view=map.CreateViewAccessor())using(var gate=Mutex.OpenExisting(channel+".lock")){
    Func<int,long,bool> alive=delegate(int id,long start){try{using(var p=Process.GetProcessById(id))return !p.HasExited&&p.StartTime.ToUniversalTime().Ticks==start;}catch{return false;}};
    Action hide=delegate{if(view.ReadInt32(80)==pid)view.Write(80,0);};Action show=delegate{int other=view.ReadInt32(80);if(other!=0&&other!=pid)throw new Exception("Duplicate visible owners across processes");view.Write(80,pid);view.Write(score==0?88:92,1);};
    int loops=score==0?80:45;if(score>0)Thread.Sleep(400);
    for(int i=0;i<loops;i++){gate.WaitOne();try{eval.Invoke(null,new object[]{view,pid,started,score,alive,hide,show});}finally{gate.ReleaseMutex();}Thread.Sleep(30);}
    gate.WaitOne();try{hide();if(view.ReadInt32(0)==pid)view.Write(0,0);}finally{gate.ReleaseMutex();}
   }return 0;
  }
  string name="Local\\Codex-AIPulse-Test-"+Guid.NewGuid().ToString("N");string self=Assembly.GetExecutingAssembly().Location;
  using(var map=MemoryMappedFile.CreateNew(name,128))using(var view=map.CreateViewAccessor())using(var gate=new Mutex(false,name+".lock")){
   var a=Process.Start(new ProcessStartInfo(self,"\""+args[0]+"\" child "+name+" 0"){UseShellExecute=false,CreateNoWindow=true});var b=Process.Start(new ProcessStartInfo(self,"\""+args[0]+"\" child "+name+" 7"){UseShellExecute=false,CreateNoWindow=true});
   if(!a.WaitForExit(10000)||!b.WaitForExit(10000)||a.ExitCode!=0||b.ExitCode!=0)throw new Exception("Cross-process election failed");
   if(view.ReadInt32(88)!=1||view.ReadInt32(92)!=1||view.ReadInt32(80)!=0)throw new Exception("Ownership handoff or cleanup failed");
   Console.WriteLine("PASS two real background processes coordinate through shared memory/mutex without duplicate visible-owner callbacks");Console.WriteLine("PASS empty to populated takeover and exit cleanup; no real tray icons created");
  }return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
