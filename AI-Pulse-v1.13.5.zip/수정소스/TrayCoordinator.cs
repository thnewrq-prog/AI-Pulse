﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.Threading;
using System.Windows.Forms;

// Each browser keeps its native messaging connection; only one owns the visible tray.
internal sealed class TrayCoordinator : IDisposable
{
    private Form form;
    private NotifyIcon tray;
    private System.Windows.Forms.Timer timer;
    private Mutex sync;
    private MemoryMappedFile memory;
    private MemoryMappedViewAccessor state;
    private int pid, score;
    private long started;
    private bool ready, disposed;
    private const string Channel="Local\\AIPulse.TrayOwner.v1";
    public static void Attach(Form form,NotifyIcon tray)
    {
        TrayCoordinator c=new TrayCoordinator(form,tray);
        form.Tag=c;
    }
    private TrayCoordinator(Form f,NotifyIcon icon)
    {
        form=f;tray=icon;pid=Process.GetCurrentProcess().Id;started=Process.GetCurrentProcess().StartTime.ToUniversalTime().Ticks;
        tray.Visible=false;
        sync=new Mutex(false,Channel+".Lock");memory=MemoryMappedFile.CreateOrOpen(Channel,128);state=memory.CreateViewAccessor();
        timer=new System.Windows.Forms.Timer();timer.Interval=400;timer.Tick+=Tick;form.FormClosed+=OnClosed;timer.Start();
    }
    public static int Score(Dictionary<string,object> pulse)
    {
        object value;int result=0;
        if(pulse!=null&&pulse.TryGetValue("connections",out value)){
            var connections=value as Dictionary<string,object>;
            if(connections!=null)foreach(var item in connections){var c=item.Value as Dictionary<string,object>;object enabled;if(c!=null&&c.TryGetValue("enabled",out enabled)&&enabled is bool&&(bool)enabled)result++;}
        }
        return result;
    }
    public static void Snapshot(Form form,Dictionary<string,object> pulse)
    {
        var c=form.Tag as TrayCoordinator;if(c==null)return;c.score=Score(pulse);c.ready=true;c.Tick(null,EventArgs.Empty);
    }
    private static bool Alive(int processId,long start)
    {
        if(processId<=0)return false;
        try{using(Process p=Process.GetProcessById(processId))return !p.HasExited&&p.StartTime.ToUniversalTime().Ticks==start;}catch{return false;}
    }
    // Stable on equal scores, including two profiles with no linked accounts.
    public static bool Prefer(int candidateScore,int ownerScore){return candidateScore>ownerScore;}
    private void HideTray()
    {
        tray.Visible=false;if(form.Visible)form.Hide();
    }
    private void Tick(object sender,EventArgs e)
    {
        if(disposed||!ready)return;
        bool locked=false;
        try{
            try{locked=sync.WaitOne(100);}catch(AbandonedMutexException){locked=true;}
            if(!locked)return;
            Evaluate(state,pid,started,score,Alive,HideTray,ShowTray);
        }catch{tray.Visible=false;}
        finally{if(locked)sync.ReleaseMutex();}
    }
    private void ShowTray(){tray.Visible=true;}
    public static void Evaluate(MemoryMappedViewAccessor state,int pid,long started,int score,Func<int,long,bool> alive,Action hide,Action show)
    {
            int owner=state.ReadInt32(0);long ownerStart=state.ReadInt64(8);
            if(owner==pid&&ownerStart==started){
                state.Write(16,score);
                int pending=state.ReadInt32(24);long pendingStart=state.ReadInt64(32);
                if(pending!=0&&alive(pending,pendingStart)&&Prefer(state.ReadInt32(40),score)){
                    // Hide first, then hand off. The second process never shows a second icon during takeover.
                    hide();state.Write(0,pending);state.Write(8,pendingStart);state.Write(16,state.ReadInt32(40));state.Write(24,0);return;
                }
                state.Write(24,0);show();return;
            }
            hide();
            if(!alive(owner,ownerStart)){
                state.Write(0,pid);state.Write(8,started);state.Write(16,score);state.Write(24,0);show();return;
            }
            if(Prefer(score,state.ReadInt32(16))){
                int pending=state.ReadInt32(24);long pendingStart=state.ReadInt64(32);
                if(!alive(pending,pendingStart)||Prefer(score,state.ReadInt32(40))||pending==pid){state.Write(24,pid);state.Write(32,started);state.Write(40,score);}
            }
    }
    private void OnClosed(object sender,FormClosedEventArgs e){Dispose();}
    public void Dispose()
    {
        if(disposed)return;disposed=true;timer.Stop();timer.Dispose();bool locked=false;
        try{
            try{locked=sync.WaitOne(100);}catch(AbandonedMutexException){locked=true;}
            if(locked){if(state.ReadInt32(0)==pid&&state.ReadInt64(8)==started)state.Write(0,0);if(state.ReadInt32(24)==pid)state.Write(24,0);}
        }finally{if(locked)sync.ReleaseMutex();state.Dispose();memory.Dispose();sync.Dispose();}
    }
}
