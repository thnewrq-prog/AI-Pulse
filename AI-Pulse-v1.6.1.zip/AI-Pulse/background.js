importScripts('providers.js','connection.js','binding.js','layout.js','comfy-balance.js','background-renderer.js');
const api=chrome;
const pending=new Map();
let scheduledBatch=null;
const scheduledIds=new Set();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function bounded(promise,ms,message){
  let timer;const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new PulseConnection.Failure('timeout',message)),ms);});
  return Promise.race([promise,deadline]).finally(()=>clearTimeout(timer));
}
const emptyState=()=>({schema:2,connections:{},snapshots:{},history:[],jobs:{}});
let writeQueue=Promise.resolve(),sessionQueue=Promise.resolve();
function mutate(fn){
  const result=writeQueue.then(async()=>{const {pulse=emptyState()}=await api.storage.local.get('pulse');pulse.connections||={};pulse.snapshots||={};pulse.history||=[];pulse.jobs||={};await fn(pulse);await api.storage.local.set({pulse});return pulse;});
  writeQueue=result.catch(()=>{});return result;
}
function session(fn){
  const result=sessionQueue.then(async()=>{const {pulseRuntime={loginTabs:{},tempTabs:{}}}=await api.storage.session.get('pulseRuntime');pulseRuntime.loginTabs||={};pulseRuntime.tempTabs||={};await fn(pulseRuntime);await api.storage.session.set({pulseRuntime});return pulseRuntime;});
  sessionQueue=result.catch(()=>{});return result;
}
const ready=(async()=>{
  // Persisted tab numbers from a previous browser launch are never trusted.
  const {pulseRuntime}=await api.storage.session.get('pulseRuntime');
  for(const [id,tabId] of Object.entries(pulseRuntime?.tempTabs||{}))try{const t=await api.tabs.get(tabId);if(PulseConnection.allowed(t.url,id))await api.tabs.remove(tabId);}catch{}
  await session(s=>{s.tempTabs={};});
  await mutate(s=>{
    s.schema=2;
    for(const c of Object.values(s.connections))delete c.tabId;
    const higgs=s.connections.higgsfield;
    if(higgs&&!higgs.adapter121){
      if(!higgs.binding&&(!higgs.entryUrl||/^https:\/\/(?:www\.)?higgsfield\.ai\/me\/settings\/?$/.test(higgs.entryUrl)))higgs.entryUrl=PROVIDERS.higgsfield.url;
      higgs.adapter121=true;
    }
    const comfy=s.connections.comfy;
    if(comfy&&!comfy.adapter122){
      if(!comfy.binding&&(!comfy.entryUrl||/^https:\/\/(?:www\.)?comfy\.org\/cloud\/?$/.test(comfy.entryUrl)))comfy.entryUrl=PROVIDERS.comfy.url;
      comfy.adapter122=true;
    }
    const midjourney=s.connections.midjourney;
    if(midjourney&&!midjourney.adapter131){if(!midjourney.binding)midjourney.entryUrl=PROVIDERS.midjourney.url;midjourney.adapter131=true;}
    if(midjourney&&!midjourney.adapter133){midjourney.entryUrl=PROVIDERS.midjourney.url;midjourney.navigation=[];midjourney.adapter133=true;}
    for(const id of Object.keys(s.jobs))s.snapshots[id]={id,status:'interrupted',metrics:[],checkedAt:new Date().toISOString(),message:'브라우저가 닫혀 이전 조회가 중단되었습니다. 갱신을 누르면 다시 조회합니다.'};
    s.jobs={};
  });
})();
api.action.onClicked.addListener(async()=>{
  await ready;const url=api.runtime.getURL('index.html');const tabs=await api.tabs.query({});const tab=tabs.find(t=>t.url===url);
  if(tab){await api.tabs.update(tab.id,{active:true});await api.windows.update(tab.windowId,{focused:true});}else await api.tabs.create({url});
});
async function waitReady(tabId,early=false){
  for(let i=0;i<(early?90:45);i++){
    const t=await api.tabs.get(tabId);
    if(t.status==='complete'){if(!early)await sleep(300);return t;}
    if(early)try{
      const result=await api.scripting.executeScript({target:{tabId},injectImmediately:true,func:()=>!!document.body&&document.readyState!=='loading'});
      if(result[0]?.result===true)return t;
    }catch{}
    await sleep(early?200:400);
  }
  throw new PulseConnection.Failure('network-error','공식 사이트 응답이 늦습니다. 인터넷 연결을 확인하고 다시 갱신해 주세요.');
}
async function loginTab(id){
  const {pulseRuntime={}}=await api.storage.session.get('pulseRuntime');const tabId=pulseRuntime.loginTabs?.[id];
  if(!tabId)return null;
  try{const t=await api.tabs.get(tabId);return PulseConnection.allowed(t.url,id)?t:null;}catch{return null;}
}
async function rememberLoginRoute(id){
  const t=await loginTab(id);const entry=t&&PulseConnection.safeEntry(t.url,id);
  if(id==='comfy'&&entry&&new URL(entry).origin!=='https://cloud.comfy.org')return;
  if(id==='midjourney'&&entry&&!/^\/account\/?$/.test(new URL(entry).pathname))return;
  if(entry)await mutate(s=>{if(s.connections[id])s.connections[id].entryUrl=entry;});
}
async function openLogin(id){
  const existing=await loginTab(id);
  if(existing){await api.tabs.update(existing.id,{active:true});await api.windows.update(existing.windowId,{focused:true});return existing;}
  const {pulse=emptyState()}=await api.storage.local.get('pulse');const url=PulseConnection.safeEntry(pulse.connections[id]?.entryUrl,id)||PROVIDERS[id].url;
  const t=await api.tabs.create({url,active:true});await session(s=>{s.loginTabs[id]=t.id;});return t;
}
async function inject(tabId){await api.scripting.executeScript({target:{tabId},injectImmediately:true,files:['providers.js','parser.js','credit-parser.js','credit-collector.js','binding.js','collector.js','navigator.js']});}
async function readAutomatic(tabId,id,navigation,binding=null,report=async()=>{}){
  // A settings link can load a new document. Re-inject after navigation.
  for(let attempt=0;attempt<3;attempt++){
    await report('loading');
    await PulseBackgroundRenderer.verify(tabId);
    const t=await waitReady(tabId,['midjourney','comfy','higgsfield','suno'].includes(id));
    if(!PulseConnection.allowed(t.url,id))throw new PulseConnection.Failure('auth-required','로그인이 만료되었습니다. ‘다시 로그인’을 눌러 공식 사이트에서 로그인해 주세요.');
    try{
      await report('reading');
        await inject(tabId);
      const output=await api.scripting.executeScript({target:{tabId},injectImmediately:true,func:(provider,steps,bound)=>PulseNavigator.run(provider,steps,bound),args:[id,navigation||[],binding]});
      const r=output[0]?.result;if(r)return r;
    }catch(e){if(attempt===2)throw e;}
  }
  throw new PulseConnection.Failure('layout-changed','자동 조회를 마치지 못했습니다. 다시 갱신해 주세요.');
}
async function createRefreshTab(id,url){return PulseBackgroundRenderer.create(id,url);}
async function refresh(id,automatic=true){
  if(pending.has(id))return pending.get(id);
  if(scheduledIds.has(id))return {id,status:'scheduled'};
  const execute=async()=>{
    const {pulse=emptyState()}=await api.storage.local.get('pulse');if(!pulse.connections[id]?.enabled)return {id,status:'disconnected'};
    let temporaryTab,result,expired=false;
    await mutate(s=>{s.jobs[id]={startedAt:new Date().toISOString(),stage:'opening'};});
    const report=stage=>expired?Promise.resolve():mutate(s=>{if(s.jobs[id])s.jobs[id].stage=stage;});
    try{
      const collect=async()=>{
      if(!await api.permissions.contains({origins:providerPatterns(id)}))throw new PulseConnection.Failure('permission-required','사이트 접근 권한이 없습니다. ‘연결 복구’를 눌러 권한을 다시 허용해 주세요.');
      let read;
      if(automatic){
        if(!pulse.connections[id].binding)await rememberLoginRoute(id);
        const {pulse:current}=await api.storage.local.get('pulse');const c=current.connections[id];
        temporaryTab=await createRefreshTab(id,id==='midjourney'?PROVIDERS[id].url:PulseConnection.safeEntry(c.entryUrl,id)||PROVIDERS[id].url);
        if(expired){await PulseBackgroundRenderer.stop(temporaryTab.id);try{await api.tabs.remove(temporaryTab.id);}catch{}throw new PulseConnection.Failure('timeout','조회 시간이 초과되었습니다.');}
        await session(s=>{s.tempTabs[id]=temporaryTab.id;});
        const screen=readAutomatic(temporaryTab.id,id,c.navigation,c.binding,report);
        read=id==='comfy'?await Promise.race([screen,PulseBackgroundRenderer.waitBalance(temporaryTab.id)]):await screen;
      }else{
        const t=await loginTab(id);if(!t)throw new PulseConnection.Failure('needs-view','수동 화면 읽기는 ‘공식 화면 열기’로 연 탭에서만 가능합니다. 일반 조회는 갱신 버튼을 사용하세요.');
        await inject(t.id);const output=await api.scripting.executeScript({target:{tabId:t.id},func:provider=>PulseCollector.collect(provider),args:[id]});read=output[0]?.result;
      }
      return read;
      };
      const read=await bounded(collect(),45000,PROVIDERS[id].name+' 조회를 45초 안에 완료하지 못했습니다. 공식 화면 응답이 지연되었습니다. 다시 갱신하거나 공식 화면의 상태를 확인해 주세요.');
      if(!read)throw new PulseConnection.Failure('layout-changed','사용량을 읽지 못했습니다. 다시 갱신해 주세요.');
      const metrics=PulseConnection.cleanMetrics(read.metrics);
      const status=metrics.length?'ok':['auth-required','challenge','no-quota','layout-changed'].includes(read.status)?read.status:'no-quota';
      result={id,status,metrics,checkedAt:new Date().toISOString(),mode:automatic?'automatic':'screen',message:PulseConnection.message(status,id,read.comfyStage)};
      if(temporaryTab&&status==='auth-required')result.message='로그인이 필요합니다. 공식 화면 열기에서 로그인한 뒤 다시 갱신해 주세요.';
      if(temporaryTab&&status==='challenge')result.message='공식 화면에서 보안 확인을 완료한 뒤 다시 갱신해 주세요.';
      if(id==='comfy'&&['no-quota','layout-changed'].includes(status)){const messages={'app-not-ready':'Comfy 앱이 제한 시간 안에 준비되지 않았습니다. 공식 화면에서 앱 로딩과 로그인 상태를 확인해 주세요.','profile-visible':'Comfy 앱은 열렸지만 계정 메뉴의 잔액을 찾지 못했습니다. 잔액 위치 지정을 한 번 사용해 주세요.','counter-missing':'Comfy 계정 메뉴가 열렸지만 잔액 응답이나 숫자가 도착하지 않았습니다. 잠시 후 다시 갱신해 주세요.','settings-open':'Comfy 설정 화면에서 잔액을 찾지 못했습니다. 잔액 위치 지정을 한 번 사용해 주세요.'};result.message=messages[read.comfyStage]||'Comfy의 공식 잔액 응답과 화면 수치를 읽지 못했습니다. 공식 화면에서 로그인 상태를 확인해 주세요.';}
      else if(['no-quota','layout-changed'].includes(status))result.message='백그라운드 화면에서 수치를 읽지 못했습니다. 이 사이트는 화면 활성화가 필요할 수 있습니다. 공식 화면 열기 후 수동 화면 읽기를 사용해 주세요.';
      if(status==='ok'){
        const entry=PulseConnection.safeEntry(read.entryUrl,id);
        const navigation=PulseConnection.cleanNavigation(read.navigation);
        await mutate(s=>{if(s.connections[id]){s.connections[id].lastSuccessAt=result.checkedAt;if(entry)s.connections[id].entryUrl=entry;if(navigation.length)s.connections[id].navigation=navigation;}});
      }
    }catch(e){result={id,status:e.code||'network-error',metrics:[],checkedAt:new Date().toISOString(),mode:automatic?'automatic':'screen',message:e instanceof PulseConnection.Failure?e.message:'조회 중 연결이 끊겼습니다. 인터넷 연결을 확인한 뒤 다시 갱신해 주세요.'};}
    finally{
      expired=true;
      if(temporaryTab)await PulseBackgroundRenderer.stop(temporaryTab.id);
      const keepOpen=false;
      // Close only the fresh tab owned by this request, never a conversation tab.
      if(temporaryTab&&!keepOpen)try{await bounded(api.tabs.remove(temporaryTab.id),5000,'조회 창을 정리하지 못했습니다.');}catch{}
      await session(s=>{delete s.tempTabs[id];});
    }
    await mutate(s=>{delete s.jobs[id];if(!s.connections[id]?.enabled)return;s.snapshots[id]=result;if(result.status==='ok'){s.history.unshift({id,at:result.checkedAt,metrics:result.metrics,mode:result.mode});s.history=s.history.slice(0,120);}});
    return result;
  };
  // Every service runs independently; no foreground queue or fixed batch size.
  const task=execute();
  pending.set(id,task);try{return await task;}finally{pending.delete(id);}
}
async function scheduleRefreshAll(){
  if(scheduledBatch||pending.size)throw Error('이미 갱신 중입니다. 완료 후 다시 눌러 주세요.');
  scheduledBatch=true;
  try{
    const {pulse=emptyState()}=await api.storage.local.get('pulse');
    const ids=PulseLayout.visible(pulse.layout).filter(id=>pulse.connections[id]?.enabled);
    if(!ids.length)throw Error('표시 중인 연결 서비스가 없습니다. 계정 연결과 화면 편집을 확인해 주세요.');
    const startsAt=Date.now()+1500;
    ids.forEach(id=>scheduledIds.add(id));
    await mutate(s=>{for(const id of ids)s.jobs[id]={startedAt:new Date(startsAt).toISOString(),stage:'scheduled'};});
    // The worker owns the delay and requests. Closing the popup does not cancel it.
    setTimeout(async()=>{
      scheduledIds.clear();
      try{await Promise.allSettled(ids.map(id=>refresh(id)));}finally{scheduledBatch=null;}
    },1500);
    return {ok:true,count:ids.length,startsAt};
  }catch(e){scheduledBatch=null;scheduledIds.clear();throw e;}
}
api.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(sender.id===api.runtime.id&&msg.type==='save-binding'){
    (async()=>{
      await ready;const id=msg.id;
      if(!Object.hasOwn(PROVIDERS,id)||!PROVIDERS[id].type||!sender.tab?.id||!PulseConnection.allowed(sender.url,id))throw Error('허용된 공식 계정 탭에서만 저장할 수 있습니다.');
      const {pulseRuntime={}}=await api.storage.session.get('pulseRuntime'),request=pulseRuntime.pickers?.[id];
      if(!request||request.tabId!==sender.tab.id||request.nonce!==msg.nonce||Date.now()>request.expires)throw Error('위치 연결 시간이 만료되었습니다. 대시보드에서 다시 시작해 주세요.');
      const binding=PulseBinding.clean(msg.binding),entryUrl=PulseConnection.safeEntry(sender.url,id);
      if(!binding||!entryUrl)throw Error('계정 또는 크레딧 화면에서 잔액을 선택해 주세요.');
      const output=await api.scripting.executeScript({target:{tabId:sender.tab.id},func:b=>PulseBinding.read(document,b),args:[binding]});
      const metric=PulseConnection.cleanMetrics([output[0]?.result])[0];if(!metric)throw Error('선택한 숫자를 잔액으로 읽지 못했습니다.');
      await mutate(s=>{if(!s.connections[id]?.enabled)throw Error('연결이 해제되었습니다.');s.connections[id].binding=binding;s.connections[id].entryUrl=entryUrl;s.connections[id].lastSuccessAt=new Date().toISOString();s.snapshots[id]={id,status:'ok',metrics:[metric],mode:'screen',checkedAt:new Date().toISOString(),message:'직접 지정한 공식 화면의 잔액입니다.'};});
      await session(s=>{delete s.pickers[id];});return {ok:true};
    })().then(reply).catch(e=>reply({error:e.message}));return true;
  }
  if(sender.id!==api.runtime.id||![api.runtime.getURL('index.html'),api.runtime.getURL('popup.html')].includes(sender.url))return false;
  const run=async()=>{
    await ready;
    if(msg.type==='refresh-all')return scheduleRefreshAll();
    if(msg.type==='read')return (await api.storage.local.get('pulse')).pulse||emptyState();
    if(msg.type==='set-layout'){
      const layout=PulseLayout.clean(msg.layout);
      await mutate(s=>{s.layout=layout;});return {ok:true,layout};
    }
    if(msg.type==='clear'){
      if(pending.size||scheduledBatch)throw Error('조회가 끝난 뒤 삭제해 주세요.');
      await api.storage.local.remove('pulse');await api.storage.session.remove('pulseRuntime');
      await api.permissions.remove({origins:Object.keys(PROVIDERS).flatMap(providerPatterns)});return {ok:true};
    }
    const id=msg.id;if(!Object.hasOwn(PROVIDERS,id))throw Error('지원하지 않는 서비스입니다.');
    if(msg.type==='bind'){
      if(!PROVIDERS[id].type)throw Error('크레딧 서비스에서만 사용할 수 있습니다.');
      if(pending.has(id))throw Error('갱신이 끝난 뒤 위치를 지정해 주세요.');
      if(!await api.permissions.contains({origins:providerPatterns(id)}))throw Error('계정 연결에서 접근 권한을 허용해 주세요.');
      const t=await openLogin(id);await waitReady(t.id);if(!PulseConnection.allowed((await api.tabs.get(t.id)).url,id))throw Error('먼저 공식 사이트에서 로그인해 주세요.');
      await inject(t.id);const nonce=crypto.randomUUID();await session(s=>{s.pickers||={};s.pickers[id]={tabId:t.id,nonce,expires:Date.now()+900000};});
      await api.scripting.executeScript({target:{tabId:t.id},files:['picker.js']});
      await api.scripting.executeScript({target:{tabId:t.id},func:(provider,key)=>PulsePicker.start(provider,key),args:[id,nonce]});return {ok:true};
    }
    if(msg.type==='connect'||msg.type==='open'){
      if(!await api.permissions.contains({origins:providerPatterns(id)}))throw Error('사이트 접근 권한을 허용해 주세요.');
      await mutate(s=>{s.connections[id]={...s.connections[id],enabled:true};});await openLogin(id);return {ok:true};
    }
    if(msg.type==='disconnect'){
      if(pending.has(id)||scheduledIds.has(id))throw Error('이 서비스의 조회가 끝난 뒤 해제해 주세요.');
      await mutate(s=>{delete s.connections[id];delete s.snapshots[id];s.history=s.history.filter(h=>h.id!==id);});
      await session(s=>{delete s.loginTabs[id];});await api.permissions.remove({origins:providerPatterns(id)});return {ok:true};
    }
    if(msg.type==='refresh')return refresh(id);
    if(msg.type==='scan')return refresh(id,false);
    throw Error('알 수 없는 요청입니다.');
  };
  run().then(reply).catch(e=>reply({error:e.message}));return true;
});
