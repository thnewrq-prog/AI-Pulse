/* Deliberately conservative: never derive quota from chat counts or CSS widths. */
(function(root) {
  const usage = /usage|사용량|사용\s*한도|이용\s*한도|plan\s*limits|weekly\s*limits|current\s*session/i;
  const remaining = /remaining|\bleft\b|남[은음아]|잔여|사용\s*가능/i;
  const used = /\bused\b|consumed|사용[됨했한]|소진|사용량/i;
  const time = /weekly|week|주간|이번\s*주|일주일|매주/i;
  function parsePercent(text) {
    const m = String(text).match(/([+-]?\d+(?:[.,]\d+)?)\s*[%％]/);
    if (!m) return null;
    const n = Number(m[1].replace(',', '.'));
    return Number.isFinite(n) && n >= 0 && n <= 100 ? n : null;
  }
  function parseBlock(block) {
    const valueText = block.valueText || '';
    if ((valueText.match(/[%％]/g)||[]).length > 1) return null;
    let value = parsePercent(valueText);
    if (value == null && Number.isFinite(block.value) && Number.isFinite(block.max) && block.max > 0 && block.value >= 0 && block.value <= block.max) value = 100 * block.value / block.max;
    if (value == null) return null;
    const label = String(block.label || '').replace(/\s+/g,' ').trim().slice(0,100);
    if (!label || !usage.test(block.context || label)) return null;
    // Direction must be explicit near the number; an ambiguous bar stays unknown.
    const direction = remaining.test(valueText) ? 'remaining' : used.test(valueText) ? 'used' : remaining.test(label) ? 'remaining' : used.test(label) ? 'used' : null;
    if (!direction) return null;
    const percentUsed = Math.round((direction === 'remaining' ? 100 - value : value) * 10) / 10;
    return {label, period: time.test(label) ? 'week' : /5\s*(?:h|hour|시간)|session|세션|현재/i.test(label) ? 'session' : 'other', percentUsed, sourceValue: Math.round(value * 10)/10, direction, reset: String(block.reset || '').slice(0,140)};
  }
  function parseBlocks(blocks) {
    const seen = new Set();
    return blocks.map(parseBlock).filter(m => {
      if (!m) return false;
      const key = m.label.toLowerCase() + '|' + m.percentUsed;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    }).slice(0,16);
  }
  root.UsageParser = {parsePercent, parseBlock, parseBlocks};
})(globalThis);
