(() => {
  'use strict';
  const native=typeof chrome!=='undefined' && !!chrome.runtime?.id && !!chrome.storage?.local;
  let state={connections:{},snapshots:{},history:[]};
  let period='session',view='dashboard',toastTimer;
  let editing=false,draft=null,dragged=null,savingLayout=false;
  const displayLayout=()=>PulseLayout.clean(editing?draft:state.layout);
  if(!native)try{state.layout=JSON.parse(localStorage.getItem('pulsePreviewLayout')||'null');}catch{}
  const busy=new Set();
  const working=id=>busy.has(id)||!!state.jobs?.[id];
  const statusNames={'renderer-unavailable':'백그라운드 실행 확인 필요','auth-required':'재로그인 필요',challenge:'보안 확인','permission-required':'권한 복구 필요','network-error':'연결 재시도',timeout:'조회 시간 초과','layout-changed':'화면 확인 필요','no-quota':'수치 미제공',interrupted:'조회 중단'};
  const $=id=>document.getElementById(id);
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const date=value=>new Date(value).toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false});
  const clock=value=>new Date(value).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',hour12:false});
  function toast(message,error=false){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;$('toast').classList.toggle('error-toast',error);toastTimer=setTimeout(()=>$('toast').hidden=true,6000);}
  async function send(type,id,extra={}){if(!native)throw Error('확장 프로그램 설치 후 사용할 수 있어요. 설치 안내를 확인해 주세요.');const response=await chrome.runtime.sendMessage({type,id,...extra});if(response?.error)throw Error(response.error);return response;}
  async function load(){if(native)state=await send('read');render();}
  function changeView(next){view=next;document.querySelectorAll('.view').forEach(e=>e.hidden=e.id!==view);document.querySelectorAll('.nav-item').forEach(e=>e.classList.toggle('active',e.dataset.view===view));const names={dashboard:'사용량 대시보드',connections:'계정 연결',history:'갱신 기록',help:'사용 방법'};$('breadcrumb').innerHTML='워크스페이스 <span>/</span> '+names[view];window.scrollTo(0,0);}
  const logo=(id,extra='')=>`<div class="provider-logo ${extra}" style="--provider:${PROVIDERS[id].color}">${PROVIDERS[id].mark}</div>`;
  const number=n=>Number(n).toLocaleString('ko-KR',{maximumFractionDigits:2});
  function metricText(m){
    if(m.kind!=='balance')return m.percentUsed+'% 사용';
    const prefix=m.approximate?'약 ':'';
    if(m.unit==='gpu_minutes'){
      const hours=Math.floor(m.amount/60),minutes=Math.round((m.amount-hours*60)*100)/100;
      return prefix+(hours?hours+'시간 ':'')+number(minutes)+'분';
    }
    return prefix+number(m.amount)+' credits';
  }
  function balanceCard(id){
    const p=PROVIDERS[id],connected=state.connections[id]?.enabled,s=state.snapshots[id],loading=working(id),valid=s?.status==='ok';
    const metrics=valid?s.metrics.filter(m=>m.kind==='balance'):[],m=metrics[0];
    const stale=valid&&Date.now()-new Date(s.checkedAt).getTime()>300000;
    const status=loading?'자동 조회 중':!connected?'미연결':valid?(stale?'이전 조회':'확인 완료'):statusNames[s?.status]||'첫 갱신 대기';
    const unit=p.type==='gpu'?'Fast GPU 잔여 시간':'크레딧 잔액';
    const job=state.jobs?.[id],elapsed=job?Math.max(0,Math.floor((Date.now()-new Date(job.startedAt).getTime())/1000)):0;
    const stage={scheduled:'자동 시작 대기',opening:'백그라운드 조회 준비 중',loading:'공식 사이트 불러오는 중',reading:'계정 메뉴에서 잔액 읽는 중'}[job?.stage]||'조회 중';
    const note=loading?(job?`${stage} · ${elapsed}초 경과 · 최대 45초 동안 조회합니다.`:'다른 서비스와 동시에 백그라운드 조회 중입니다.'):!connected?'한 번 로그인한 뒤 갱신 버튼으로 확인하세요.':!valid?s?.message||p.hint:m?.label||'표시 가능한 잔액이 없습니다.';
    return `<article class="service-card credit-card" style="--provider:${p.color}"><div class="card-head">${logo(id)}<div class="provider-title"><h3>${p.name}</h3><small>${p.company}</small></div><span class="status ${valid&&!stale?'ok':connected?'warn':''}">${status}</span></div><div class="card-middle"><div class="balance-label">${unit}</div><div class="balance-value ${m?'has-value':''} ${m&&m.amount<=0?'low-balance':''}"><strong>${loading?'···':m?escape(metricText(m)):'—'}</strong><span>${m?(stale?'이전 조회 · 다시 갱신해 주세요':'공식 화면의 잔여량'):'계정 연결 후 확인'}</span></div><p class="empty-note">${escape(note)}</p>${metrics.slice(1).map(m=>`<div class="metric-line"><span>${escape(m.label)}</span><b>${escape(metricText(m))}</b></div>`).join('')}</div><div class="card-actions">${connected?`<button class="button secondary" data-action="refresh" data-id="${id}" ${loading?'disabled':''}>↻ 잔액 갱신</button><button class="icon-button" data-action="open" data-id="${id}" aria-label="${p.name} 공식 계정 열기" ${loading?'disabled':''}>↗</button>`:`<button class="button secondary" data-action="connect" data-id="${id}">＋ 계정 연결</button>`}</div><div class="card-meta"><span>공식 계정의 잔여량</span><span>${s?.checkedAt?'조회 '+clock(s.checkedAt):'아직 갱신하지 않음'}</span></div></article>`;
  }
  function card(id){
    if(PROVIDERS[id].type)return balanceCard(id);
    const p=PROVIDERS[id],connected=state.connections[id]?.enabled,s=state.snapshots[id],loading=working(id);
    const valid=s?.status==='ok';
    const stale=valid && Date.now()-new Date(s.checkedAt).getTime()>300000;
    const metrics=valid?s.metrics:[];
    const chosen=metrics.filter(m=>period==='all'||m.period===period);
    const m=chosen[0];
    const label=loading?'자동 조회 중':!connected?'미연결':valid?(stale?'이전 조회':'확인 완료'):statusNames[s?.status]||'첫 갱신 대기';
    let note=!connected?'한 번 로그인하고,<br>다음부터는 갱신 버튼만 누르세요.':loading?'백그라운드에서 자동 조회 중입니다.<br>공식 페이지를 직접 열지 않아도 됩니다.':!valid?escape(s?.message||'로그인했다면 갱신을 눌러 주세요. 재시작 후에도 연결 설정을 기억합니다.'):!m?'이 기간의 한도가 표시되지 않았어요.<br>‘전체 한도’에서 확인해 주세요.':escape(m.label);
    const value=m?`${m.percentUsed}<small>%</small>`:'—';
    const circumference=364.42;
    const circle=m?`<circle class="progress" cx="72" cy="72" r="58" stroke-dasharray="${circumference}" stroke-dashoffset="${circumference*(1-m.percentUsed/100)}"/>`:'';
    const extras=chosen.slice(1).map(m=>`<div class="metric-line"><span>${escape(m.label)}</span><b>${m.percentUsed}% 사용</b></div>`).join('');
    return `<article class="service-card" style="--provider:${p.color}"><div class="card-head">${logo(id)}<div class="provider-title"><h3>${p.name}</h3><small>${p.company}</small></div><span class="status ${valid&&!stale?'ok':connected?'warn':''}">${label}</span></div><div class="card-middle"><div class="quota-label">${period==='session'?'현재 세션':period==='week'?'주간':'공식 화면의 한도'} 사용률</div><div class="gauge" role="img" aria-label="${m?escape(m.label)+' 사용률 '+m.percentUsed+'%':'사용량 수치 없음'}"><svg viewBox="0 0 144 144" aria-hidden="true"><circle class="track" cx="72" cy="72" r="58"/>${circle}</svg><div class="gauge-center ${m?'has-value':''}"><strong>${loading?'···':value}</strong></div></div><div class="gauge-caption">${m?(stale?'이전 조회':'한도 사용률'):'사용량 확인 대기'}</div><p class="empty-note ${loading?'loading-text':''}">${note}</p>${m?.reset?`<p class="reset-note">${escape(m.reset)}</p>`:''}${extras}</div><div class="card-actions">${connected?`<button class="button secondary" data-action="open" data-id="${id}" ${loading?'disabled':''}>공식 화면 열기 ↗</button><button class="icon-button ${loading?'spin':''}" data-action="refresh" data-id="${id}" title="${p.name} 갱신" aria-label="${p.name} 갱신" ${loading?'disabled':''}>↻</button>`:`<button class="button secondary" data-action="connect" data-id="${id}">＋ 계정 연결</button>`}</div><div class="card-meta"><span>${connected?'공식 웹페이지 표시값':'브라우저 로그인으로 연결'}</span><span>${s?.checkedAt?'조회 '+clock(s.checkedAt):'아직 갱신하지 않음'}</span></div></article>`;
  }
  function rows(items){if(!items.length)return '<div class="empty-history"><span class="empty-symbol">◷</span><b>아직 갱신 기록이 없어요</b><p>계정을 연결하고 첫 사용량·잔액을 확인해 보세요.</p></div>';return items.filter(h=>PROVIDERS[h.id]).map(h=>`<div class="history-row">${logo(h.id)}<div><b>${PROVIDERS[h.id].name}</b><p>${h.metrics.slice(0,3).map(m=>`${escape(m.label)} ${escape(metricText(m))}`).join(' · ')}</p></div><time datetime="${escape(h.at)}">${date(h.at)}</time></div>`).join('');}
  function renderLayout(){
    const layout=displayLayout(),ids=PulseLayout.visible(layout);
    $('editLayout').textContent=editing?'편집 중':'✎ 화면 편집';
    $('editLayout').setAttribute('aria-expanded',String(editing));$('editLayout').hidden=editing;
    $('layoutEditor').hidden=!editing;$('cards').classList.toggle('layout-editing',editing);
    if(editing)$('serviceToggles').innerHTML=layout.order.map(id=>`<label class="service-toggle"><input type="checkbox" data-show-service="${id}" ${layout.hidden.includes(id)?'':'checked'} ${savingLayout?'disabled':''}><span>${PROVIDERS[id].name}</span></label>`).join('');
    $('saveLayout').disabled=savingLayout;$('cancelLayout').disabled=savingLayout;
    $('resetLayout').disabled=savingLayout;
    $('cards').innerHTML=ids.map(id=>card(id).replace('<article ',`<article data-service="${id}" `)).join('');
    $('emptyLayout').hidden=ids.length!==0;
    if(editing)for(const [index,id] of ids.entries()){
      const element=$('cards').querySelector(`[data-service="${id}"]`),tools=document.createElement('div');tools.className='card-edit-tools';
      tools.innerHTML=`<button class="drag-handle" draggable="true" data-drag-id="${id}" aria-label="${PROVIDERS[id].name} 끌어서 이동" title="끌어서 이동">⠿</button><span>${index+1}</span><button data-layout-action="previous" data-id="${id}" aria-label="${PROVIDERS[id].name} 앞으로 이동" ${index===0?'disabled':''}>←</button><button data-layout-action="next" data-id="${id}" aria-label="${PROVIDERS[id].name} 뒤로 이동" ${index===ids.length-1?'disabled':''}>→</button><button data-layout-action="hide" data-id="${id}" aria-label="${PROVIDERS[id].name} 숨기기">숨기기</button>`;
      element.prepend(tools);
    }
  }
  function moveCard(id,target){draft=PulseLayout.move(draft,id,target);render();}
  async function finishEditing(){
    savingLayout=true;render();const layout=PulseLayout.clean(draft);
    try{if(native)await send('set-layout',null,{layout});else localStorage.setItem('pulsePreviewLayout',JSON.stringify(layout));state.layout=layout;editing=false;draft=null;toast('서비스 순서와 표시 설정을 저장했습니다.');}catch(e){toast('편집 내용을 저장하지 못했습니다: '+e.message,true);}finally{savingLayout=false;render();}
  }
  function render(){
    if(dragged)return;
    const focused=document.activeElement,focusedToggle=focused?.dataset.showService,focusedMove=focused?.dataset.layoutAction,focusedId=focused?.dataset.id;
    const connected=Object.keys(PROVIDERS).filter(id=>state.connections[id]?.enabled).length;
    $('connectedCount').innerHTML=connected+' <small>/ '+Object.keys(PROVIDERS).length+'</small>';
    document.querySelector('[data-view="connections"] i').textContent=Object.keys(PROVIDERS).length;
    $('readCount').innerHTML=Object.values(state.snapshots).filter(s=>s.status==='ok').length+' <small>개 서비스</small>';
    const dates=Object.values(state.snapshots).map(s=>s.checkedAt).filter(Boolean).sort();
    $('lastRefresh').textContent=dates.length?clock(dates.at(-1)):'아직 없음';
    const running=new Set([...busy,...Object.keys(state.jobs||{})]).size;
    $('refreshMeta').textContent=running?`${running}개 서비스 자동 조회 중` : dates.length?date(dates.at(-1)):'연결 후 갱신해 주세요';
    renderLayout();
    $('recentHistory').innerHTML=rows(state.history.slice(0,3));$('fullHistory').innerHTML=rows(state.history);
    $('connectionCards').innerHTML=Object.entries(PROVIDERS).map(([id,p])=>`<article class="connection-row">${logo(id)}<div><h3>${p.name} <small style="font-size:11px;color:#8c9889;font-weight:400">${p.company}</small></h3><p>${escape(p.hint)}</p><p>${state.connections[id]?.enabled?'사이트 접근 허용됨 · 로그인 완료 여부는 갱신으로 확인':'아직 연결하지 않았어요'}</p></div><div class="connection-buttons">${state.connections[id]?.enabled?`<button class="button secondary" data-action="open" data-id="${id}" ${busy.has(id)?'disabled':''}>공식 화면 열기 ↗</button><button class="button secondary" data-action="disconnect" data-id="${id}" ${busy.has(id)?'disabled':''}>연결 해제</button>`:`<button class="button primary" data-action="connect" data-id="${id}">계정 연결 ↗</button>`}</div></article>`).join('');
    for(const [index,id] of Object.keys(PROVIDERS).entries()) {
      if(!state.connections[id]?.enabled)continue;
      const cardElement=$('cards').querySelector(`[data-service="${id}"]`),snapshot=state.snapshots[id];
      if(cardElement){
      const meta=cardElement.querySelector('.card-meta');
      const recovery=['auth-required','challenge','permission-required'].includes(snapshot?.status);
      const action=cardElement.querySelector('.card-actions .button');
      action.dataset.action=recovery?(snapshot.status==='permission-required'?'connect':'open'):'refresh';
      action.textContent=recovery?(snapshot.status==='permission-required'?' 연결 복구 ↗':snapshot.status==='challenge'?' 로그인 확인 ↗':' 다시 로그인 ↗'):PROVIDERS[id].type?'↻ 잔액 갱신':'↻ 사용량 갱신';
      action.classList.toggle('primary',!recovery);action.disabled=working(id);
      const icon=cardElement.querySelector('.icon-button');icon.dataset.action=recovery?'refresh':'open';icon.textContent=recovery?'↻':'↗';icon.title=recovery?'사용량 다시 갱신':'로그인·공식 화면 확인';icon.setAttribute('aria-label',PROVIDERS[id].name+' '+icon.title);icon.disabled=working(id);
      icon.classList.toggle('spin',working(id)&&recovery);
      meta.firstElementChild.textContent='재시작 후에도 갱신 지원';
      if(PROVIDERS[id].type){const bind=document.createElement('button');bind.className='text-button';bind.dataset.action='bind';bind.dataset.id=id;bind.textContent=state.connections[id].binding?'잔액 위치 다시 지정':'잔액 위치 지정';bind.disabled=working(id);meta.firstElementChild.replaceWith(bind);}
      if(state.snapshots[id]?.mode==='screen')meta.lastElementChild.textContent='화면 읽음 '+clock(state.snapshots[id].checkedAt);
      }
      const row=$('connectionCards').children[index],info=row.querySelector('p:last-child');
      info.textContent=state.connections[id].lastSuccessAt?'자동 조회 준비됨 · 브라우저를 다시 켜도 갱신으로 조회':'연결 설정 저장됨 · 로그인 후 첫 갱신을 눌러 주세요';
      const buttons=row.querySelector('.connection-buttons');
      const scan=document.createElement('button');scan.className='text-button';scan.dataset.action='scan';scan.dataset.id=id;scan.disabled=working(id);scan.textContent='수동 화면 읽기';scan.title='문제 해결용: 열린 공식 화면의 표시값만 읽습니다';buttons.append(scan);
      buttons.querySelectorAll('button').forEach(b=>b.disabled=working(id));
    }
    const refreshing=busy.size>0||Object.keys(state.jobs||{}).length>0;$('refreshAll').disabled=refreshing||editing;$('refreshAll').classList.toggle('busy',refreshing);$('refreshAll').lastElementChild.textContent=refreshing?'자동 조회 중…':'전체 갱신';$('clearData').disabled=refreshing;
    $('exportData').disabled=!state.history.length;
    if(editing){const target=focusedToggle?$(`serviceToggles`).querySelector(`[data-show-service="${focusedToggle}"]`):focusedMove&&focusedId?$('cards').querySelector(`[data-layout-action="${focusedMove}"][data-id="${focusedId}"]`):null;if(target&&!target.disabled)target.focus({preventScroll:true});}
  }
  async function connect(id){
    if(!native){changeView('help');toast('확장 프로그램을 설치하면 실제 계정을 연결할 수 있어요.');return;}
    // Keep this permission request directly within the click's user gesture.
    const granted=await chrome.permissions.request({origins:providerPatterns(id)});
    if(!granted){toast('연결하려면 해당 서비스의 사이트 접근을 허용해 주세요.',true);return;}
    await send('connect',id);await load();toast('공식 페이지에서 로그인한 뒤 대시보드의 갱신을 누르세요. 이후 공식 탭은 닫아도 됩니다.');
  }
  async function refresh(ids,mode='refresh'){
    ids=PulseLayout.refreshOrder(ids);
    if(!native){changeView('help');toast('확장 프로그램을 설치한 뒤 갱신할 수 있어요.');return;}
    if(!ids.length){changeView('connections');toast('먼저 확인할 AI 계정을 연결해 주세요.');return;}
    for(const id of ids)busy.add(id);render();
    let successes=0;const failures=[];
    await Promise.all(ids.map(async id=>{try{const r=await send(mode,id);if(r.status==='ok')successes++;else failures.push(PROVIDERS[id].name+': '+(statusNames[r.status]||'조회 실패'));}catch(e){failures.push(PROVIDERS[id].name+': '+e.message);}finally{busy.delete(id);await load();}}));
    toast(successes?`${successes}개 서비스 ${mode==='scan'?'화면 읽기':'자동 조회'} 완료${failures.length?' · '+failures.join(', '):''}`:failures.join(' · ')||'조회를 마치지 못했습니다. 다시 갱신해 주세요.',!successes);
  }
  document.addEventListener('click',async event=>{
    const layoutAction=event.target.closest('[data-layout-action]');
    if(layoutAction&&editing&&!savingLayout){const {id,layoutAction:type}=layoutAction.dataset,ids=PulseLayout.visible(draft),index=ids.indexOf(id);if(type==='hide'){draft.hidden=[...new Set([...draft.hidden,id])];render();}else{const target=ids[index+(type==='previous'?-1:1)];if(target)moveCard(id,target);}return;}
    const nav=event.target.closest('[data-view]');if(nav){changeView(nav.dataset.view);return;}
    const segment=event.target.closest('[data-period]');if(segment){period=segment.dataset.period;document.querySelectorAll('[data-period]').forEach(e=>{const selected=e===segment;e.classList.toggle('selected',selected);e.setAttribute('aria-pressed',String(selected));});render();return;}
    const action=event.target.closest('[data-action]');if(!action)return;
    const {id,action:type}=action.dataset;
    try{if(type==='connect')await connect(id);if(type==='open')await send('open',id);if(type==='bind'){await send('bind',id);toast('공식 탭의 안내에 따라 잔액 숫자를 한 번 클릭해 연결해 주세요.');}if(type==='disconnect'){await send('disconnect',id);await load();toast(PROVIDERS[id].name+' 연결과 보관 기록을 삭제했습니다.');}if(type==='refresh')await refresh([id]);if(type==='scan')await refresh([id],'scan');}catch(e){toast(e.message,true);}
  });
  $('editLayout').addEventListener('click',()=>{editing=true;draft=PulseLayout.clean(state.layout);render();});
  $('saveLayout').addEventListener('click',finishEditing);
  $('cancelLayout').addEventListener('click',()=>{editing=false;draft=null;render();});
  $('resetLayout').addEventListener('click',()=>{draft=PulseLayout.defaults();render();});
  $('serviceToggles').addEventListener('change',event=>{const id=event.target.dataset.showService;if(!editing||savingLayout||!Object.hasOwn(PROVIDERS,id))return;draft.hidden=event.target.checked?draft.hidden.filter(item=>item!==id):[...new Set([...draft.hidden,id])];render();});
  $('cards').addEventListener('dragstart',event=>{const handle=event.target.closest('[data-drag-id]');if(!editing||savingLayout||!handle){event.preventDefault();return;}dragged=handle.dataset.dragId;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',dragged);handle.closest('.service-card').classList.add('dragging');});
  $('cards').addEventListener('dragover',event=>{if(!dragged)return;const target=event.target.closest('[data-service]');if(!target)return;event.preventDefault();event.dataTransfer.dropEffect='move';$('cards').querySelectorAll('.drop-target').forEach(e=>e.classList.remove('drop-target'));target.classList.add('drop-target');});
  $('cards').addEventListener('drop',event=>{if(!dragged)return;event.preventDefault();const id=dragged,target=event.target.closest('[data-service]')?.dataset.service;dragged=null;if(target)moveCard(id,target);else render();});
  $('cards').addEventListener('dragend',()=>{dragged=null;render();});
  $('refreshAll').addEventListener('click',async()=>{const ids=PulseLayout.visible(state.layout).filter(id=>state.connections[id]?.enabled);if(!ids.length&&Object.values(state.connections).some(c=>c.enabled)){toast('표시 중인 연결 서비스가 없습니다. 화면 편집에서 서비스를 켜 주세요.');return;}if(!native){refresh(ids);return;}if(!ids.length){changeView('connections');toast('먼저 계정을 연결해 주세요.');return;}try{const result=await send('refresh-all');PulseRefreshWarning.notify(result.count);await load();}catch(e){toast(e.message,true);}});
  $('exportData').addEventListener('click',()=>{
    const data={application:'AI Pulse',exportedAt:new Date().toISOString(),history:state.history};
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='ai-pulse-'+new Date().toISOString().slice(0,10)+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  $('clearData').addEventListener('click',async()=>{if(!native){toast('미리보기에는 저장된 사용량이 없습니다.');return;}if(!confirm('AI Pulse의 계정 연결과 모든 사용량 기록을 이 브라우저에서 삭제할까요?'))return;try{await send('clear');await load();toast('연결과 사용량 기록을 삭제했습니다.');}catch(e){toast(e.message,true);}});
  $('clearData').textContent='계정 연결·사용량 기록 모두 삭제';
  const scanHelp=document.createElement('p');scanHelp.textContent='자동 조회 문제를 진단할 때는 계정 연결 화면의 ‘공식 화면 열기’와 ‘수동 화면 읽기’를 사용할 수 있습니다. 평소에는 갱신 버튼만 사용하면 됩니다.';$('help').querySelectorAll('article')[3].append(scanHelp);
  $('helpLinks').innerHTML=Object.values(PROVIDERS).map(p=>`<a href="${p.help}" target="_blank" rel="noopener noreferrer">${p.name} 공식 안내 ↗</a>`).join('');
  $('previewNotice').hidden=native;
  if(native){chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.pulse){state=changes.pulse.newValue||{connections:{},snapshots:{},history:[]};render();}});}
  load().catch(e=>{render();toast('저장된 정보를 불러오지 못했습니다: '+e.message,true);});
  setInterval(()=>{if(!editing)render();},5000);
})();
