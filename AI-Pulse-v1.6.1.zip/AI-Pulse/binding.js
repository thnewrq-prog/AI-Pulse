/* A user-selected balance location, stored locally with no account text or tokens. */
globalThis.PulseBinding=(()=>{
  const kinds=new Set(['settings','balance','account','profile','sidebar']);
  const visible=el=>el&&el.getClientRects().length&&!el.closest('input,textarea,[contenteditable="true"],[hidden],[aria-hidden="true"]')&&el.ownerDocument.defaultView.getComputedStyle(el).visibility!=='hidden';
  const text=el=>String(el?.innerText||el?.textContent||'').trim().replace(/\s+/g,' ');
  function classify(el){
    const testId=el.getAttribute('data-testid');
    if(['current-user-button','header-account'].includes(testId))return 'profile';
    if(testId==='manage-plan-menu-item')return 'account';
    if(testId==='plans-credits-menu-item'||(el.getAttribute('data-nav-id')==='workspace'&&el.closest('[data-testid="settings-dialog"]')))return 'balance';
    const name=(el.getAttribute('aria-label')||el.getAttribute('title')||text(el)).replace(/\s*[（(](?:ctrl|cmd|control|⌘).*$/i,'').trim();
    if(/^(?:settings(?:\s*(?:&|and)\s*help)?|설정(?:\s*및\s*도움말)?)$/i.test(name))return 'settings';
    if(/^(?:plan\s*(?:&|and)\s*credits|credits?|credit\s*balance|usage\s*details|크레딧|요금제\s*(?:및|&)\s*크레딧)$/i.test(name))return 'balance';
    if(/^(?:manage\s+(?:plan|account|subscription)|my\s+account|subscription|계정\s*관리|구독\s*관리)$/i.test(name))return 'account';
    if(/^(?:open\s+)?(?:profile|user|account)(?:\s+menu)?$|^(?:프로필|계정)\s*메뉴$/i.test(name)||(el.getAttribute('aria-haspopup')==='menu'&&el.querySelector('img')))return 'profile';
    if(/^(?:open|expand)\s+(?:sidebar|menu)$|^(?:메뉴|사이드바)\s*열기$/i.test(name))return 'sidebar';
    return null;
  }
  function selector(el){
    const doc=el.ownerDocument;
    for(const attr of ['data-testid','data-test-id']){const v=el.getAttribute(attr);if(v&&/^[a-z][a-z0-9_-]{1,70}$/i.test(v)){const s='['+attr+'="'+v+'"]';if(doc.querySelectorAll(s).length===1)return s;}}
    const path=[];for(let node=el;node&&node.nodeType===1&&path.length<24;node=node.parentElement){const tag=node.tagName.toLowerCase();if(tag==='body'){path.unshift('body');break;}const siblings=[...node.parentElement?.children||[]].filter(e=>e.tagName===node.tagName);path.unshift(tag+':nth-of-type('+(siblings.indexOf(node)+1)+')');}
    const s=path.join(' > ');return s.length<=1200&&doc.querySelectorAll(s).length===1?s:null;
  }
  function validSelector(value){return typeof value==='string'&&value.length>0&&value.length<=1200&&/^[a-zA-Z0-9_\-\[\]=" :()>]+$/.test(value)&&!/(?:input|textarea|iframe|script|style|password)/i.test(value);}
  function clean(b){
    if(!b||!validSelector(b.selector)||!['credits','gpu_hours','gpu_minutes'].includes(b.unit)||!/^\w{1,12}$/.test(b.tag||''))return null;
    const steps=Array.isArray(b.steps)?b.steps.filter(s=>s&&kinds.has(s.kind)&&validSelector(s.selector)).map(s=>({kind:s.kind,selector:s.selector})).slice(0,8):[];
    return {selector:b.selector,unit:b.unit,tag:b.tag.toUpperCase(),steps};
  }
  function parse(value,unit){
    const raw=String(value).trim();if(!raw||raw.length>120)return null;
    if(unit==='credits')return CreditParser.parseCredits({label:'Credit balance',text:raw,trustedBalance:true});
    let duration=raw;if(/^[\d.,+\-\s/]+$/.test(raw))duration+=' '+(unit==='gpu_hours'?'hours':'minutes');
    return CreditParser.parseGPU({label:'Fast time remaining',text:duration});
  }
  function read(doc,b){
    b=clean(b);if(!b)return null;
    let el;try{el=doc.querySelector(b.selector);}catch{return null;}
    if(!visible(el)||el.tagName!==b.tag)return null;
    return parse(text(el),b.unit);
  }
  function stepElement(doc,step){
    if(!step||!kinds.has(step.kind)||!validSelector(step.selector))return null;
    const el=doc.querySelector(step.selector);if(!visible(el)||classify(el)!==step.kind)return null;
    if(el.tagName==='A'&&el.href&&new URL(el.href,doc.baseURI).origin!==new URL(doc.URL).origin)return null;
    return el;
  }
  return {text,visible,classify,selector,clean,parse,read,stepElement};
})();
