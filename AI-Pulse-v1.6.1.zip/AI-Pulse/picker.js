/* Runs only after the user presses '잔액 위치 지정' on the dashboard. */
globalThis.PulsePicker=(()=>{
  let stop;
  function start(id,nonce){
    stop?.();const host=document.createElement('div');host.setAttribute('data-ai-pulse-picker','');host.style.cssText='position:fixed;inset:auto 18px 18px auto;z-index:2147483647;max-width:360px;';
    const shadow=host.attachShadow({mode:'open'}),sheet=new CSSStyleSheet();sheet.replaceSync(':host{font:13px/1.7 "Segoe UI","Malgun Gothic",sans-serif;color:#213b29}section{background:#fff;border:2px solid #50876a;border-radius:12px;padding:18px;box-shadow:0 4px 30px #0003}h3{font-size:16px;margin:0 0 10px}p{margin:7px 0}button,select{font:inherit;border:1px solid #cbd9cd;border-radius:6px;padding:6px 10px;background:#f1f6ef;cursor:pointer;margin:5px 5px 0 0}button.primary{background:#28513b;color:#fff}strong{overflow-wrap:anywhere}small{display:block;color:#7e8c7d}');shadow.adoptedStyleSheets=[sheet];
    const panel=document.createElement('section');shadow.append(panel);document.documentElement.append(host);
    let mode='browse',selected=null,steps=[],oldOutline='',selectedElement=null;
    function restore(){if(selectedElement){selectedElement.style.outline=oldOutline;selectedElement=null;}}
    function cleanup(){restore();document.removeEventListener('click',capture,true);document.removeEventListener('keydown',key,true);host.remove();stop=null;}
    stop=cleanup;
    function button(label,fn,primary=false){const b=document.createElement('button');b.textContent=label;if(primary)b.className='primary';b.onclick=event=>{if(event.isTrusted)fn(event);};panel.append(b);}
    function show(message){panel.replaceChildren();const h=document.createElement('h3');h.textContent='AI Pulse · '+PROVIDERS[id].name;panel.append(h);const p=document.createElement('p');p.textContent=message;panel.append(p);}
    function begin(){mode='browse';show('공식 화면에서 현재 잔액이 보이도록 메뉴를 여세요. 준비되면 아래 버튼을 누르고 잔액 숫자를 클릭하세요.');button('숫자 선택 시작',()=>{mode='pick';show('현재 잔여 크레딧 또는 남은 Fast GPU 시간의 숫자를 클릭하세요.');button('취소',cleanup);},true);button('취소',cleanup);}
    function review(el){
      const value=PulseBinding.text(el),css=PulseBinding.selector(el);if(!css||!/[0-9]/.test(value)||value.length>120){show('숫자 하나가 표시된 작은 영역을 선택해 주세요.');button('다시 선택',()=>{mode='pick';});button('취소',cleanup);return;}
      mode='review';restore();selectedElement=el;oldOutline=el.style.outline;el.style.outline='3px solid #48a075';selected={selector:css,tag:el.tagName,steps};
      show('선택한 화면 표시값을 연결합니다. 현재 잔액인지 확인하고 단위를 선택해 주세요.');const strong=document.createElement('strong');strong.textContent=value;panel.append(strong);
      const unit=document.createElement('select');for(const [v,label] of [['','단위 선택'],['credits','크레딧'],['gpu_hours','Fast GPU 시간 (시간 단위)'],['gpu_minutes','Fast GPU 시간 (분 단위)']]){const o=document.createElement('option');o.value=v;o.textContent=label;unit.append(o);}unit.value=PROVIDERS[id].type==='gpu'?/hours?|hrs?|시간|\dh\b/i.test(value)?'gpu_hours':/minutes?|mins?|분|\dm\b/i.test(value)?'gpu_minutes':'':'credits';panel.append(document.createElement('br'),unit);
      button('이 위치 연결',async()=>{
        const metric=PulseBinding.parse(value,unit.value);if(!metric){show('단위가 맞지 않거나 여러 숫자가 선택되었습니다. 정확한 잔액 숫자를 다시 선택해 주세요.');button('다시 선택',begin);button('취소',cleanup);return;}
        const binding={...selected,unit:unit.value};
        try{const response=await chrome.runtime.sendMessage({type:'save-binding',id,nonce,binding,metric});if(response?.error)throw Error(response.error);show('잔액 위치를 저장했습니다. 대시보드로 돌아가 갱신하세요. 다음 조회부터 이 위치를 우선 사용합니다.');button('완료',cleanup,true);}catch(e){show('저장하지 못했습니다: '+e.message);button('닫기',cleanup);}
      },true);button('다시 선택',()=>{restore();begin();});button('취소',cleanup);
    }
    function capture(e){if(e.composedPath().includes(host)||!e.isTrusted)return;const el=e.target.closest?.('button,a,[role="button"],[role="tab"],[role="menuitem"]');
      if(mode==='browse'&&el){const kind=PulseBinding.classify(el),css=kind&&PulseBinding.selector(el);if(css&&steps.length<8)steps.push({kind,selector:css});return;}
      if(mode!=='pick')return;e.preventDefault();e.stopImmediatePropagation();let target=e.target;if(target.closest('input,textarea,[contenteditable="true"]'))return;review(target);
    }
    function key(e){if(e.key==='Escape')cleanup();}
    document.addEventListener('click',capture,true);document.addEventListener('keydown',key,true);begin();return true;
  }
  return {start};
})();
