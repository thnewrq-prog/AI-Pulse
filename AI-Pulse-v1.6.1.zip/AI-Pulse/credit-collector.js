/* Read bounded balance components only, never artwork, prompts, or billing history. */
globalThis.CreditCollector=(()=>{
  const visible=e=>!!e&&!e.closest('[hidden],[aria-hidden="true"]')&&e.getClientRects().length>0&&e.ownerDocument.defaultView.getComputedStyle(e).visibility!=='hidden';
  const text=e=>String(e?.innerText||e?.textContent||'').trim();
  const heading=/^(?:plan\s*(?:&|and)\s*credits|(?:total|additional|workspace|monthly)?\s*credits?|credit\s*balance|available\s+credits|remaining\s+credits|usage\s+details|(?:fast\s+)?(?:gpu\s+)?time\s+remaining|fast\s+(?:hours|time)(?:\s+remaining)?|크레딧|(?:총|추가|월간|사용\s*가능)?\s*크레딧|크레딧\s*잔액|보유\s*크레딧|잔여\s*크레딧|남은\s*(?:빠른|고속|패스트|Fast|GPU).*시간|요금제\s*(?:및|&)\s*크레딧)$/i;
  const explicit=/credit\s*balance|available\s*credits|remaining\s*credits|credits\s*(?:remaining|available)|total\s*credits|잔여\s*크레딧|남은\s*크레딧|보유\s*크레딧|크레딧\s*잔액|총\s*크레딧/i;
  function comfyCounters(doc){
    // CurrentUserPopoverWorkspace/Legacy render a plain numeric span next to
    // credits-info-button. The purchase button and tooltip are separate nodes.
    // Neither the row's combined text nor the surrounding account is a balance.
    const nodes=[...doc.querySelectorAll('[data-testid="header-credits"],[data-testid="header-session-credits"]')];
    for(const popover of doc.querySelectorAll('[data-testid="current-user-popover"]')){
      if(!visible(popover))continue;
      const info=popover.querySelector('[data-testid="credits-info-button"]');
      const row=info?.parentElement;
      if(!row||row.getAttribute('aria-busy')==='true')continue;
      for(const child of row.children)if(child.tagName==='SPAN')nodes.push(child);
    }
    return nodes.filter(visible).map(node=>({text:text(node),label:'Credit balance',trustedBalance:true})).filter(block=>block.text.length<=80);
  }
  function midjourneyCounters(doc,url){
    if(!/^\/account\/?$/.test(url.pathname))return null;
    const clean=e=>text(e).replace(/[\u200b-\u200d\ufeff]/g,'').replace(/\s+/g,' ').trim();
    const nodes=[...doc.querySelectorAll('h1,h2,h3,h4,h5,h6,div,p,span,dt,strong,b,label,font')].filter(visible);
    const anchors=nodes.filter(e=>/^(?:remaining\s+fast\s+(?:hours?|time)|fast\s+(?:hours?|time)\s+remaining|남은\s*fast\s*hours?)\s*[:：]?$/i.test(clean(e)));
    const metrics=[],seen=new Set();let matched=false;
    for(const anchor of anchors){
      let panel=anchor.parentElement;
      for(let depth=0;panel&&depth<12;depth++,panel=panel.parentElement){
        const panelText=clean(panel);if(panelText.length>1400)break;
        if(!/usage\s+details|사용\s*내역/i.test(panelText)&&!/(?:included|구독에\s*포함됨)/i.test(panelText))continue;
        matched=true;
        for(const labelNode of panel.querySelectorAll('div,p,span,dt,strong,b,label,font')){
          if(!visible(labelNode))continue;
          const label=clean(labelNode),included=/^(?:included|구독에\s*포함됨)\s*[:：]?$/i.test(label),extra=/^(?:purchased\s*(?:&|and)\s*awarded|구매\s*[·ㆍ・&]\s*지급\s*내역)\s*[ⓘℹi:：]?$/i.test(label);
          if(!included&&!extra)continue;
          const candidates=[];let row=labelNode;
          // Labels and values can be nested in separate flex/grid wrappers.
          // Ascend only within this remaining-hours panel, stopping before a
          // different balance row. Read a whole duration, never a plan sentence.
          for(let level=0;row&&row!==panel&&level<6;level++,row=row.parentElement){
            const rowText=clean(row);if(rowText.length>160)break;
            if(included&&/purchased|awarded|구매|지급|갱신/i.test(rowText))break;
            if(extra&&/included|구독에|갱신/i.test(rowText))break;
            candidates.push(...[...row.children].filter(e=>e!==labelNode&&!e.contains(labelNode)&&visible(e)));
          }
          for(const value of candidates){
            const raw=clean(value);if(!raw||raw.length>65)continue;
            if(!/^(?:\d+(?:\.\d+)?\s*(?:hours?|hrs?|h|minutes?|mins?|m|시간|분)\s*)+(?:\/\s*(?:\d+(?:\.\d+)?\s*(?:hours?|hrs?|h|minutes?|mins?|m|시간|분)\s*)+)?$/i.test(raw))continue;
            const metric=CreditParser.parseGPU({label:'Fast time remaining',text:raw});if(!metric)continue;
            const balanceType=included?'subscription':'topup',key=balanceType+'|'+metric.amount;if(seen.has(key))continue;
            seen.add(key);metrics.push({...metric,balanceType,label:included?'구독 Fast GPU 잔여 시간':'구매·보너스 Fast GPU 잔여 시간'});break;
          }
        }
        // Some translated pages split a row across font nodes or display:contents
        // wrappers. Fall back to the text of this bounded usage panel only.
        const time='(?:\\d+(?:\\.\\d+)?\\s*(?:hours?|hrs?|h|minutes?|mins?|m|시간|분)(?![a-z])\\s*)+';
        for(const [balanceType,labelPattern,label] of [
          ['subscription','(?:included|구독에\\s*포함됨)','구독 Fast GPU 잔여 시간'],
          ['topup','(?:purchased\\s*(?:&|and)\\s*awarded|구매\\s*[·ㆍ・&]\\s*지급\\s*내역)','구매·보너스 Fast GPU 잔여 시간']
        ]){
          if(metrics.some(m=>m.balanceType===balanceType))continue;
          const match=panelText.match(new RegExp(labelPattern+'\\s*[ⓘℹi:：]?\\s*('+time+'(?:/\\s*'+time+')?)','i'));
          const metric=match&&CreditParser.parseGPU({label:'Fast time remaining',text:match[1]});
          if(metric)metrics.push({...metric,balanceType,label});
        }
        // Stop at the closest Usage Details panel, even while it is loading.
        // Do not ascend into neighbouring plan features or billing columns.
        break;
      }
    }
    return matched?metrics.sort((a,b)=>(a.balanceType==='subscription'?0:1)-(b.balanceType==='subscription'?0:1)):null;
  }
  function readDocument(doc,id,pageUrl){
    const p=PROVIDERS[id];if(!p?.type)return {metrics:[],viewFound:false};
    let url;try{url=new URL(pageUrl);}catch{return {metrics:[],viewFound:false};}
    if(!(p.origins||[p.origin]).includes(url.origin))return {metrics:[],viewFound:false};
    // Never scan public pricing, help, community, or creation/gallery pages.
    if(/\/(?:pricing|creator-hub|blog|help)(?:\/|$)/i.test(url.pathname))return {metrics:[],viewFound:false,checkedAt:new Date().toISOString()};
    if(id==='comfy'){
      const metrics=CreditParser.parseBlocks(comfyCounters(doc),id);
      if(metrics.length)return {metrics,viewFound:true,checkedAt:new Date().toISOString(),source:'comfy-account-counter'};
    }
    if(id==='midjourney'){
      const metrics=midjourneyCounters(doc,url);
      if(metrics!==null)return {metrics,viewFound:true,checkedAt:new Date().toISOString(),source:'midjourney-usage-details'};
    }
    // A Comfy workflow can contain thousands of DOM nodes. Scanning every div's
    // innerText repeatedly can block the renderer before navigation can finish.
    // Only inspect account/settings surfaces; never traverse the workflow body.
    const sources=id==='comfy'?[...doc.querySelectorAll('[data-testid="settings-dialog"],.credits-container,[role="dialog"],[role="tabpanel"],[data-testid="current-user-popover"],header,aside,nav')].filter(visible):[doc];
    const query=selector=>[...new Set(sources.flatMap(root=>[...(root.matches?.(selector)?[root]:[]),...root.querySelectorAll(selector)]))];
    // Landing pages (/cloud/, /ko) are entry routes, not private balance pages.
    const privateRoute=/^\/(?:account|me\/settings|settings|billing|subscription)(?:\/|$)/.test(url.pathname);
    const roots=query('header,aside,nav,[role="navigation"],[role="banner"],[role="menu"]').filter(visible).map(node=>({node,nav:true}));
    // Some account counters sit in unlabelled div toolbars. Require an explicit
    // credit label and keep the bounded component; never scan the homepage body.
    for(const node of query('[data-testid*="credit" i],[aria-label*="credit" i],[title*="credit" i],[aria-label*="크레딧"],[title*="크레딧"]')){
      if(!visible(node)||text(node).length>120||node.closest('main,article'))continue;
      const counter=text(node)?node:node.parentElement;
      if(counter&&text(counter).length<=120)roots.push({node:counter,balance:true,label:'Credit balance'});
    }
    if(privateRoute&&(id!=='comfy'||sources.length))roots.push({node:id==='comfy'?sources[0]:doc.querySelector('main')||doc.body,nav:false});
    for(const panel of query('[role="dialog"],[role="tabpanel"],dialog')){
      if(visible(panel)&&[...panel.querySelectorAll('h1,h2,h3,[role="heading"]')].some(h=>heading.test(text(h))))roots.push({node:panel,nav:false});
    }
    for(const h of query('h1,h2,h3,[role="heading"]')){
      if(!visible(h)||!heading.test(text(h)))continue;
      if(!privateRoute&&!h.closest('[role="dialog"],[role="tabpanel"],dialog,header,aside,nav'))continue;
      let node=h.parentElement;for(let i=0;i<2&&node&&text(node).length<20;i++)node=node.parentElement;
      if(node&&text(node).length<=350)roots.push({node,balance:explicit.test(text(h))});
    }
    const blocks=[],seen=new Map();
    // Many real counters use ordinary div/span labels, not semantic headings.
    // Read only a short adjacent amount, never an entire panel or transaction log.
    for(const labelNode of query('h1,h2,h3,div,span,dt,p,label')){
      if(!visible(labelNode))continue;
      const label=text(labelNode).replace(/\s+/g,' ').trim();if(label.length>70||!heading.test(label))continue;
      const inPanel=labelNode.closest('[role="dialog"],[role="tabpanel"],.credits-container,.p-dialog,[data-testid*="credit" i]');
      if(!privateRoute&&!inPanel&&!labelNode.closest('header,aside,nav,[role="menu"]'))continue;
      const parent=labelNode.parentElement;if(!parent)continue;
      const row=text(parent);if(/[$€£₩]|\/(?:mo|month|generation)|per\s+(?:month|generation)|구매|포함/i.test(row))continue;
      if(/^(?:monthly|additional|workspace|월간|추가)\s*credits?$|^(?:월간|추가)\s*크레딧$/i.test(label)&&!labelNode.closest('.credits-container')&&!explicit.test(text(parent.parentElement).slice(0,350)))continue;
      const neighbors=[labelNode.nextElementSibling,...parent.children].filter(e=>e&&e!==labelNode&&visible(e));
      for(const neighbor of neighbors){const value=text(neighbor).replace(/\s+/g,' ').trim();if(!value||value.length>80||!/[0-9]/.test(value))continue;blocks.push({text:value,label,trustedBalance:true});}
    }
    for(const root of roots){
      const candidates=[root.node,...root.node.querySelectorAll('span,div,p,section,dl,dt,dd,h2,h3,button,a')];
      for(const el of candidates){
        if(!visible(el))continue;
        const raw=text(el),aria=el.getAttribute('aria-label')||'',title=el.getAttribute('title')||'';
        if(!raw||raw.length>240)continue;
        const combined=aria+' '+title+' '+(root.label||'')+' '+raw;
        if(id==='midjourney'?!/fast|gpu|빠른|고속|패스트/i.test(combined):!/credits?|크레딧/i.test(combined))continue;
        if(el.closest('a[href*="/pricing"],a[href*="checkout"],a[href*="/creator-hub"]'))continue;
        const control=el.closest('button,a');if(control&&/^(?:buy|get|upgrade|purchase|top[ -]?up|subscribe)\b|구매|충전하기/i.test(text(control)))continue;
        const trustedBalance=!!root.nav||!!root.balance||explicit.test(combined);
        if(seen.has(el)){seen.get(el).trustedBalance||=trustedBalance;continue;}
        const block={text:raw,label:aria||title||root.label||'',trustedBalance};seen.set(el,block);blocks.push(block);
      }
    }
    const metrics=CreditParser.parseBlocks(blocks,id);
    return {metrics,viewFound:metrics.length>0||privateRoute||roots.some(r=>r.balance),checkedAt:new Date().toISOString()};
  }
  function collect(id){return readDocument(document,id,location.href);}
  return {collect,readDocument};
})();
