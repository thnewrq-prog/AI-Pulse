/* Durable configuration contains no cookie, password, or authentication token. */
globalThis.PulseConnection=(()=>{
  class Failure extends Error{constructor(code,message){super(message);this.code=code;}}
  const allowed=(url,id)=>{try{return Object.hasOwn(PROVIDERS,id)&&(PROVIDERS[id].origins||[PROVIDERS[id].origin]).includes(new URL(url).origin);}catch{return false;}};
  function safeEntry(url,id){
    if(!allowed(url,id))return null;
    const u=new URL(url);
    // Save only settings routes or Gemini's account index; discard query tokens.
    if(PROVIDERS[id].entryPaths){if(!PROVIDERS[id].entryPaths.includes(u.pathname)&&!/^\/(?:account|me|settings|billing|subscription)(?:\/[a-z-]+){0,3}\/?$/i.test(u.pathname))return null;}
    else if(!/^\/(?:u\/\d+\/)?(?:app\/?|settings(?:\/usage)?\/?|usage\/?|)?$/.test(u.pathname))return null;
    const hash=/^#settings(?:[\/=](?:usage|limits))?$/i.test(u.hash)?u.hash:'';
    return u.origin+u.pathname+hash;
  }
  const kinds=new Set(['usage','settings','profile','sidebar','balance','account']);
  function cleanNavigation(steps){return Array.isArray(steps)?steps.filter(x=>kinds.has(x)).slice(0,5):[];}
  function cleanMetrics(metrics){
    if(!Array.isArray(metrics))return [];
    return metrics.flatMap(m=>{
      if(!m||typeof m.label!=='string')return [];
      if(m.kind==='balance'){
        if(!['credits','gpu_minutes'].includes(m.unit)||!Number.isFinite(m.amount)||Math.abs(m.amount)>1e12||(m.unit==='gpu_minutes'&&m.amount<0))return [];
        return [{kind:'balance',label:m.label.slice(0,100),amount:m.amount,unit:m.unit,period:'balance',balanceType:['total','subscription','topup','other'].includes(m.balanceType)?m.balanceType:'other',approximate:!!m.approximate,reset:typeof m.reset==='string'?m.reset.slice(0,140):''}];
      }
      if(!Number.isFinite(m.percentUsed)||m.percentUsed<0||m.percentUsed>100||!['used','remaining'].includes(m.direction))return [];
      return [{label:m.label.slice(0,100),period:['session','week','other'].includes(m.period)?m.period:'other',percentUsed:m.percentUsed,sourceValue:Number.isFinite(m.sourceValue)?m.sourceValue:null,direction:m.direction,reset:typeof m.reset==='string'?m.reset.slice(0,140):''}];
    }).slice(0,16);
  }
  function message(status,id,stage){
    if(id==='comfy'&&['no-quota','layout-changed'].includes(status)){
      const detail={'counter-missing':'Comfy 계정 메뉴는 열렸지만 잔액 숫자가 표시되지 않았습니다.','settings-open':'Comfy 설정은 열렸지만 Plan & Credits의 잔액을 찾지 못했습니다.','profile-visible':'Comfy 계정은 확인했지만 잔액 메뉴를 열지 못했습니다.','app-not-ready':'Comfy Cloud의 계정 화면이 아직 준비되지 않았습니다.'}[stage];
      if(detail)return detail+' 공식 화면의 로그인·워크스페이스 상태를 확인한 뒤 갱신해 주세요. 숫자가 보인다면 ‘잔액 위치 지정’으로 연결할 수 있습니다.';
    }
    if(status==='no-quota'&&PROVIDERS[id]?.type)return '현재 화면에서 잔액을 찾지 못했습니다. 카드 아래 ‘잔액 위치 지정’으로 실제 숫자를 한 번 연결해 주세요.';if(status==='layout-changed'&&!PROVIDERS[id]?.type)return '공식 사용량 화면으로 자동 이동하지 못했습니다. 공식 화면을 확인해 주세요.';return {
    ok:'공식 사용량을 자동 조회했습니다. 조회용 화면은 닫혔습니다.',
    'auth-required':'로그인이 만료되었거나 로그아웃되어 있습니다. ‘다시 로그인’ 후 갱신해 주세요.',
    challenge:'공식 사이트가 보안 확인을 요청했습니다. ‘로그인 확인’에서 직접 확인한 뒤 갱신해 주세요.',
    'no-quota':'공식 계정 화면에서 읽을 수 있는 사용량·잔액 수치가 제공되지 않았습니다.',
    'layout-changed':'잔액 화면을 자동 인식하지 못했습니다. 카드 아래 ‘잔액 위치 지정’으로 실제 숫자를 한 번 연결해 주세요.'
  }[status]||'사용량을 읽지 못했습니다. 다시 갱신해 주세요.';}
  return {Failure,allowed,safeEntry,cleanNavigation,cleanMetrics,message};
})();
