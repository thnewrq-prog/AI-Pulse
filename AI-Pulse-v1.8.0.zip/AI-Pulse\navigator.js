/* Navigation only: never touch chat editors, purchases, or login fields. */
globalThis.PulseNavigator=(()=>{
  const visible=e=>!!e&&!e.closest('[hidden],[aria-hidden="true"]')&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
  const text=e=>String(e?.innerText||e?.textContent||'').replace(/\s+/g,' ').trim();
  const name=e=>(e.getAttribute('aria-label')||e.getAttribute('title')||text(e)).replace(/\s*[（(](?:ctrl|control|cmd|⌘).*$/i,'').trim();
  const rules={
    usage:[/^(?:(?:view|manage)\s+)?usage(?:\s+limits)?$/i,/^(?:사용량(?:\s*(?:한도|제한|확인|보기))?|이용\s*한도)$/],
    settings:[/^(?:open\s+)?settings(?:\s*(?:&|and)\s*help)?(?:\s+menu)?$/i,/^(?:설정(?:\s*(?:및|과|&)\s*도움말)?)(?:\s*(?:열기|메뉴))?$/],
    profile:[/^(?:open\s+)?(?:profile|account|user)(?:\s+menu)?$/i,/^(?:프로필|계정|사용자)(?:\s*메뉴)?(?:\s*열기)?$/],
    sidebar:[/^(?:open|expand|show)\s+(?:sidebar|menu)$/i,/^(?:사이드바|메뉴)\s*(?:열기|펼치기)$/],
    balance:[/^(?:plan\s*(?:&|and)\s*credits|credits?|credit\s*balance|usage\s*details)$/i,/^(?:요금제\s*(?:및|&)\s*크레딧|크레딧|잔여\s*크레딧|사용\s*내역)$/],
    account:[/^(?:manage\s+(?:account|plan|subscription)|my\s+account|account\s+settings|subscription)$/i,/^(?:계정\s*관리|내\s*계정|요금제\s*관리|구독\s*관리|구독)$/]
  };
  const selectors={
    gpt:{profile:['[data-testid="accounts-profile-button"]','[data-testid="profile-button"]'],settings:['[data-testid="settings-menu-item"]','[data-testid="settings-button"]']},
    gemini:{settings:['[data-test-id="settings-and-help-button"]','button.settings-and-help-button'],profile:[]},
    claude:{profile:['[data-testid="user-menu-button"]']},
    comfy:{settings:['.comfy-settings-btn','button.side-bar-button[aria-label^="Settings"]','button.side-bar-button[aria-label^="설정"]'],profile:['[data-testid="current-user-button"]','[data-testid="header-account"]','.comfy-user-button'],account:['[data-testid="manage-plan-menu-item"]'],balance:['[data-testid="plans-credits-menu-item"]','[data-testid="settings-dialog"] [data-nav-id="workspace"]']}
  };
  function find(kind,id,exclude){
    for(const selector of selectors[id]?.[kind]||[]){const e=document.querySelector(selector);if(visible(e)&&!exclude?.has(e))return e;}
    const controls=[...document.querySelectorAll('button,a,[role="button"],[role="menuitem"],[role="tab"],[role="menuitemradio"]')].filter(visible).filter(e=>!e.hasAttribute('disabled')&&!exclude?.has(e)).filter(e=>{if(e.tagName!=='A'||!e.getAttribute('href'))return true;try{const origin=new URL(e.getAttribute('href'),location.href).origin;return origin===location.origin||(globalThis.PROVIDERS?.[id]?.origins||[]).includes(origin);}catch{return false;}});
    return controls.find(e=>rules[kind].some(r=>r.test(name(e))||r.test(text(e))));
  }
  function loginNeeded(id){
    if(/\/(?:auth|login|signin)(?:\/|$)/i.test(location.pathname))return true;
    if([...document.querySelectorAll('input[type="password"]')].some(visible))return true;
    if(find('profile',id))return false;
    return [...document.querySelectorAll('button,a')].filter(visible).some(e=>/^(?:log\s*in|sign\s*in|로그인)$/i.test(text(e)));
  }
  function challenge(){
    const heading=[...document.querySelectorAll('h1,h2')].filter(visible).map(text).join(' ');
    return /verify\s+(?:you|that)|just\s+a\s+moment|security\s+verification|보안\s*확인|사람인지\s*확인/i.test(heading)||[...document.querySelectorAll('iframe[src]')].some(e=>visible(e)&&/challenges\.cloudflare|recaptcha|hcaptcha/.test(e.getAttribute('src')));
  }
  async function run(id,saved=[],binding=null){
    const isCustom=!!globalThis.PROVIDERS?.[id]?.custom;
    const slowAccount=['comfy','midjourney'].includes(id)||isCustom;
    const startedAt=Date.now();
    const deadline=startedAt+((slowAccount||id==='gpt')?30000:18000),steps=[],clicked=new WeakSet();let viewSeenAt=0,lastStepAt=0,authSeenAt=0;let comfyProfileAt=0;const clickedKinds=new Set();
    const pause=ms=>new Promise(r=>setTimeout(r,ms));
    const hints=Array.isArray(saved)?saved.filter(s=>Object.hasOwn(rules,s)):[];
    while(Date.now()<deadline){
      if(binding&&globalThis.PulseBinding){const bound=PulseBinding.read(document,binding);if(bound)return {metrics:[bound],viewFound:true,status:'ok',entryUrl:location.href,navigation:steps};}
      const waitBindingOnly=binding&&Date.now()-startedAt<6000;
      const read=waitBindingOnly?{metrics:[],viewFound:false}:PulseCollector.collect(id,binding);
      if(read.metrics.length)return {...read,status:'ok',entryUrl:location.href,navigation:steps};
      if(challenge())return {...read,status:'challenge'};
      // comfy.org/cloud is the official entry/marketing page. Follow only its
      // known Cloud app link, before interpreting any public sign-in buttons.
      if(id==='comfy'&&['https://comfy.org','https://www.comfy.org'].includes(location.origin)){
        const launch=[...document.querySelectorAll('a[href]')].find(el=>{try{const u=new URL(el.href,location.href);return visible(el)&&u.origin==='https://cloud.comfy.org'&&u.pathname==='/'&&!clicked.has(el);}catch{return false;}});
        if(launch){clicked.add(launch);location.assign('https://cloud.comfy.org/');lastStepAt=Date.now();await pause(300);continue;}
      }
      // Some apps briefly render their signed-out shell before session hydration.
      if(loginNeeded(id)){authSeenAt||=Date.now();if(Date.now()-authSeenAt>=(id==='gpt'?8000:slowAccount?6000:1500))return {...read,status:'auth-required'};await pause(slowAccount?100:250);continue;}
      authSeenAt=0;
      // /account already contains Midjourney's subscription balance. Clicking
      // Account/Subscription again can remount or reload it before hydration,
      // restarting this script and its clicked set. This provider is read-only:
      // wait for the counter, including when saved menu steps still exist.
      if(id==='midjourney'){await pause(250);continue;}
      if(read.viewFound&&!globalThis.PROVIDERS?.[id]?.type){
        viewSeenAt||=Date.now();
        if(id!=='gpt'&&Date.now()-viewSeenAt>7000)return {...read,status:'no-quota'};
        await pause(300);continue;
      }
      if(id==='comfy'&&comfyProfileAt&&visible(document.querySelector('[data-testid="current-user-popover"]'))&&Date.now()-comfyProfileAt<2500){await pause(100);continue;}
      if(Date.now()-lastStepAt<(slowAccount?250:700)){await pause(250);continue;}
      let next=null,kind=null;
      if(binding&&globalThis.PulseBinding)for(const step of binding.steps||[]){if(id==='comfy'&&clickedKinds.has(step.kind))continue;const candidate=PulseBinding.stepElement(document,step);if(candidate&&!clicked.has(candidate)){next=candidate;kind=step.kind;break;}}
      if(!next&&(!isCustom||!binding)){
        const order=id==='comfy'?['balance','account','profile',...hints,'settings','sidebar']:globalThis.PROVIDERS?.[id]?.type?['balance','account','settings',...hints,'profile','sidebar']:['usage','settings',...hints,'profile','sidebar'];
        for(const candidate of order){
          if(next)break;
          if(id==='comfy'&&clickedKinds.has(candidate))continue;
          // React may replace controls while loading. Do not toggle settings or
          // reopen profile menus after they have already been opened for ChatGPT.
          if(id==='gpt'&&clickedKinds.has(candidate))continue;
          if(id==='gpt'&&candidate==='profile'&&document.querySelector('[role="dialog"],dialog,[role="tab"][aria-selected="true"]'))continue;
          const el=find(candidate,id,clicked);
          if(id==='gpt'&&candidate==='usage'&&el?.getAttribute('aria-selected')==='true')continue;
          if(el&&!clicked.has(el)){next=el;kind=candidate;break;}
        }
      }
      if(next){clicked.add(next);clickedKinds.add(kind);steps.push(kind);next.click();lastStepAt=Date.now();if(id==='comfy'&&kind==='profile')comfyProfileAt=lastStepAt;}
      await pause(250);
    }
    const read=PulseCollector.collect(id,binding);
    // Hydration may finish on the final poll. A newly available balance is a
    // successful read even when the navigation deadline has just elapsed.
    if(read.metrics.length)return {...read,status:'ok',entryUrl:location.href,navigation:steps};
    const comfyStage=id==='comfy'?(visible(document.querySelector('[data-testid="current-user-popover"]'))?'counter-missing':visible(document.querySelector('[data-testid="settings-dialog"]'))?'settings-open':find('profile',id)?'profile-visible':'app-not-ready'):undefined;
    return {...read,status:read.viewFound?'no-quota':'layout-changed',comfyStage};
  }
  return {run};
})();
