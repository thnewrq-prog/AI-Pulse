/* Shared by the extension worker and dashboard. No external libraries. */
globalThis.BUILTIN_PROVIDERS = {
  gemini: {name: 'Gemini', company: 'Google', mark: '✦', color: '#3978ed', origin: 'https://gemini.google.com', url: 'https://gemini.google.com/app', hint: '최초 로그인 후 갱신 버튼으로 조회합니다. 사용량 메뉴는 백그라운드에서 자동으로 엽니다.', help: 'https://support.google.com/gemini/answer/16275805?hl=ko'},
  claude: {name: 'Claude', company: 'Anthropic', mark: '✳', color: '#c46d50', origin: 'https://claude.ai', url: 'https://claude.ai/settings/usage', hint: '최초 로그인 후 갱신 버튼으로 세션·주간 사용량을 자동 조회합니다.', help: 'https://support.claude.com/en/articles/9797557-usage-limit-best-practices'},
  gpt: {name: 'ChatGPT', company: 'OpenAI', mark: '◎', color: '#149b79', origin: 'https://chatgpt.com', url: 'https://chatgpt.com/settings/usage', hint: '로그인 후 갱신을 누르면 공식 사용량 화면을 자동 조회합니다. 공식 화면에 명시된 세션·주간 한도만 읽습니다. 일반 채팅 전체의 사용률을 추정하지 않습니다.', help: 'https://learn.chatgpt.com/docs/sign-in-with-chatgpt'},
  comfy: {visibleRefresh:true,name:'ComfyUI Cloud',company:'Comfy',mark:'C',color:'#5369c7',type:'credits',origin:'https://cloud.comfy.org',origins:['https://cloud.comfy.org','https://comfy.org','https://www.comfy.org'],url:'https://cloud.comfy.org/',entryPaths:['/','/cloud','/cloud/'],hint:'최소화된 백그라운드 창에서 조회합니다. 화면 활성화가 필요한 경우 공식 화면을 열어 수동 조회할 수 있습니다.',help:'https://support.comfy.org/articles/5846341390-how-credits-work-in-comfy'},
  midjourney: {visibleRefresh:true,name:'Midjourney',company:'Midjourney',mark:'⛵',color:'#7865ab',type:'gpu',origin:'https://www.midjourney.com',origins:['https://www.midjourney.com','https://midjourney.com'],url:'https://www.midjourney.com/account',entryPaths:['/account','/account/','/'],hint:'백그라운드에서 /account의 Fast 잔여 시간을 읽습니다.',help:'https://docs.midjourney.com/hc/en-us/articles/28014179406861-Managing-Your-Subscription'},
  suno: {name:'Suno',company:'Suno AI',mark:'♪',color:'#d27c38',type:'credits',origin:'https://suno.com',origins:['https://suno.com','https://www.suno.com'],url:'https://suno.com/account',entryPaths:['/account','/account/','/'],hint:'로그인한 계정의 상단·왼쪽 메뉴에서 현재 크레딧 잔액을 조회합니다.',help:'https://help.suno.com/en/articles/2525441'},
  higgsfield: {visibleRefresh:true,name:'Higgsfield',company:'Higgsfield AI',mark:'H',color:'#607e30',type:'credits',origin:'https://higgsfield.ai',origins:['https://higgsfield.ai','https://www.higgsfield.ai'],url:'https://higgsfield.ai/ko',entryPaths:['/ko','/ko/','/me/settings','/me/settings/','/'],hint:'최소화된 백그라운드 창에서 상단 크레딧 잔액을 읽고 창을 닫습니다.',help:'https://higgsfield.ai/creator-hub/help-center/getting-started/whats-in-my-higgsfield-account'}
};

globalThis.CUSTOM_PRESETS = [
  {name: 'Magnific (매그니픽)', company: 'Magnific AI', url: 'https://magnific.ai/', mark: 'M', color: '#e85d75', type: 'credits'},
  {name: 'Lumina (루미나)', company: 'Lumina AI', url: 'https://lumina.ai/', mark: 'L', color: '#38b6ff', type: 'credits'},
  {name: 'Dreamina (드리미나)', company: 'ByteDance', url: 'https://dreamina.capcut.com/', mark: 'D', color: '#00c4cc', type: 'credits'},
  {name: 'Kling AI (클링)', company: 'Kuaishou', url: 'https://app.klingai.com/', mark: 'K', color: '#ff6b2b', type: 'credits'},
  {name: 'Hailuo AI (하일루오)', company: 'MiniMax', url: 'https://hailuoai.video/', mark: 'H', color: '#8c52ff', type: 'credits'},
  {name: 'OpenArt (오픈아트)', company: 'OpenArt', url: 'https://openart.ai/', mark: 'O', color: '#ff8533', type: 'credits'},
  {name: 'Runway (런웨이)', company: 'Runway', url: 'https://app.runwayml.com/', mark: 'R', color: '#2ec4b6', type: 'credits'},
  {name: 'Leonardo.Ai', company: 'Leonardo', url: 'https://app.leonardo.ai/', mark: '✦', color: '#9b5de5', type: 'credits'},
  {name: 'ElevenLabs', company: 'ElevenLabs', url: 'https://elevenlabs.io/app', mark: 'Ⅱ', color: '#f15bb5', type: 'credits'},
  {name: 'Luma Dream Machine', company: 'Luma AI', url: 'https://lumalabs.ai/dream-machine', mark: '◐', color: '#00bbf9', type: 'credits'}
];

globalThis.PROVIDERS = {...globalThis.BUILTIN_PROVIDERS};

globalThis.extractRootDomain = hostname => {
  const parts = String(hostname || '').toLowerCase().split('.').filter(Boolean);
  if (parts.length <= 2) return parts.join('.');
  const sld = parts[parts.length - 2];
  if (['co', 'com', 'net', 'org', 'gov', 'edu', 'ac'].includes(sld) && parts[parts.length - 1].length === 2) {
    return parts.slice(-3).join('.');
  }
  return parts.slice(-2).join('.');
};

globalThis.normalizeCustomUrl = rawUrl => {
  let s = String(rawUrl || '').trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  try {
    const u = new URL(s);
    if (!['https:', 'http:'].includes(u.protocol) || !u.hostname || !u.hostname.includes('.')) return null;
    return u;
  } catch {
    return null;
  }
};

globalThis.cleanCustomProvider = (raw, forcedId) => {
  if (!raw || typeof raw !== 'object') return null;
  const id = String(forcedId || raw.id || '').trim();
  if (!/^custom_[a-z0-9_]{3,40}$/.test(id) || Object.hasOwn(globalThis.BUILTIN_PROVIDERS, id)) return null;
  const u = globalThis.normalizeCustomUrl(raw.url || raw.origin);
  if (!u) return null;
  const rootDomain = globalThis.extractRootDomain(u.hostname);
  const name = String(raw.name || rootDomain).trim().slice(0, 40) || rootDomain;
  const company = String(raw.company || rootDomain).trim().slice(0, 40) || rootDomain;
  const defaultMark = [...name][0] || '★';
  const mark = [...String(raw.mark || defaultMark).trim()].slice(0, 2).join('') || defaultMark;
  const color = /^#[0-9a-fA-F]{6}$/.test(raw.color) ? raw.color : '#4ea8de';
  const type = raw.type === 'gpu' ? 'gpu' : 'credits';
  const origins = [...new Set([
    u.origin,
    `${u.protocol}//${rootDomain}`,
    `${u.protocol}//www.${rootDomain}`,
    `${u.protocol}//app.${rootDomain}`
  ])];
  return {
    id,
    custom: true,
    visibleRefresh: true,
    name,
    company,
    mark,
    color,
    type,
    origin: u.origin,
    origins,
    rootDomain,
    url: u.href,
    hint: `직접 추가한 서비스 (${u.hostname}) · ‘잔액 위치 지정’으로 크레딧 숫자를 마우스로 클릭해 연결하세요.`,
    help: u.origin
  };
};

globalThis.syncCustomProviders = customMap => {
  for (const key of Object.keys(globalThis.PROVIDERS)) {
    if (!Object.hasOwn(globalThis.BUILTIN_PROVIDERS, key)) delete globalThis.PROVIDERS[key];
  }
  Object.assign(globalThis.PROVIDERS, globalThis.BUILTIN_PROVIDERS);
  if (!customMap || typeof customMap !== 'object') return globalThis.PROVIDERS;
  for (const [id, item] of Object.entries(customMap)) {
    const cleaned = globalThis.cleanCustomProvider(item, id);
    if (cleaned) globalThis.PROVIDERS[id] = cleaned;
  }
  return globalThis.PROVIDERS;
};

globalThis.providerPatterns = id => {
  const p = globalThis.PROVIDERS[id];
  if (!p) return [];
  const base = (p.origins || [p.origin]).map(origin => origin + '/*');
  if (p.custom && p.rootDomain && p.rootDomain.includes('.')) {
    const proto = new URL(p.origin).protocol;
    return [...new Set([...base, `${proto}//${p.rootDomain}/*`, `${proto}//*.${p.rootDomain}/*`])];
  }
  return base;
};
