/* Keep quantities in the provider's actual unit. Never infer a price or plan grant. */
globalThis.CreditParser=(()=>{
  const number='[+-]?(?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?\\s*[kKmM]?';
  const credit=/credits?|크레딧/i;
  const explicit=/remaining|available|balance|\bleft\b|잔[여액]|남[은음]|보유|사용\s*가능/i;
  const reject=/[$€£₩%％]|\b(?:buy|get|subscribe|receive|purchase|upgrade|earn|cost|price|spent|consumed|used|included)\b|\/\s*(?:mo(?:nth)?|day|generation|run)\b|per\s+(?:month|day|generation|run)|구매|결제|소모|사용됨|사용한|지급|포함/i;
  function numeric(value){
    const s=String(value).trim();
    if(!new RegExp('^'+number+'$').test(s))return null;
    const factor=/k$/i.test(s)?1000:/m$/i.test(s)?1000000:1;
    const n=Number(s.replace(/[kKmM,\s]/g,''))*factor;
    return Number.isFinite(n)&&Math.abs(n)<=1e12?n:null;
  }
  function typeOf(s){return /top[ -]?up|purchased|credit\s*pack|auto[ -]?refill|추가|충전/i.test(s)?'topup':/subscription|monthly|구독|월간/i.test(s)?'subscription':'total';}
  function parseCredits(block){
    const label=String(block.label||'').trim(),value=String(block.text||'').trim().replace(/−/g,'-');
    const combined=(label+' '+value).replace(/\s+/g,' ').trim();
    if(!credit.test(combined)||reject.test(combined)||(!block.trustedBalance&&!explicit.test(combined)))return null;
    // Avoid reading reset dates, transaction rows, or multiple independent balances.
    const values=[...value.matchAll(new RegExp(number,'g'))];let amount;
    if(values.length===1)amount=numeric(values[0][0]);
    else if(values.length===2&&explicit.test(combined)&&new RegExp(number+'\\s*/\\s*'+number).test(value))amount=numeric(values[0][0]);
    else return null;
    if(amount===null)return null;
    const balanceType=typeOf(combined);
    return {kind:'balance',label:balanceType==='subscription'?'월간 크레딧 잔액':balanceType==='topup'?'추가 크레딧 잔액':'보유 크레딧',amount,unit:'credits',period:'balance',balanceType,approximate:/[kKmM]\b/.test(values[0][0]),reset:String(block.reset||'').slice(0,140)};
  }
  function parseGPU(block){
    const all=(String(block.label||'')+' '+String(block.text||'')).replace(/\s+/g,' ');
    if(!/fast|gpu|빠른|고속|패스트/i.test(all)||!explicit.test(all)||/[$€£₩]|-\s*\d|\b(?:buy|purchase|spent|used|price)\b|구매|사용됨/i.test(all))return null;
    const token='(?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?';
    const unit='(?:hours?|hrs?|h|minutes?|mins?|m|시간|분)';
    let duration=all;
    if(all.includes('/')){
      const parts=all.split('/');if(parts.length!==2)return null;
      const shared=parts[1].match(new RegExp('^\\s*'+token+'\\s*('+unit+')','i'));if(!shared)return null;
      duration=new RegExp(token+'\\s*'+unit,'i').test(parts[0])?parts[0]:parts[0]+' '+shared[1];
    }
    let amount=0,found=false;const units=new Set();
    for(const match of duration.matchAll(new RegExp('('+token+')\\s*('+unit+')(?![a-z])','gi'))){const n=numeric(match[1]);if(n===null)return null;const isHours=/^(?:h|hour|hr|시간)/i.test(match[2]),kind=isHours?'hours':'minutes';if(units.has(kind))return null;units.add(kind);amount+=n*(isHours?60:1);found=true;}
    if(!found||amount>1e12)return null;
    return {kind:'balance',label:'Fast GPU 잔여 시간',amount:Math.round(amount*1e6)/1e6,unit:'gpu_minutes',period:'balance',balanceType:'total',approximate:false,reset:String(block.reset||'').slice(0,140)};
  }
  function parseBlocks(blocks,id){
    const seen=new Set();return blocks.map(b=>id==='midjourney'?parseGPU(b):parseCredits(b)).filter(m=>{if(!m)return false;const key=m.unit+'|'+m.balanceType+'|'+m.amount;if(seen.has(key))return false;seen.add(key);return true;}).sort((a,b)=>(a.balanceType==='total'?0:1)-(b.balanceType==='total'?0:1)).slice(0,8);
  }
  return {numeric,parseCredits,parseGPU,parseBlocks};
})();
