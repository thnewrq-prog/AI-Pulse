/* A user-selected balance location, stored locally with no account text or tokens. */
globalThis.PulseBinding=(()=>{
  const kinds=new Set(['settings','balance','account','profile','sidebar','custom']);
  const visible=el=>el&&el.getClientRects().length&&!el.closest('input,textarea,[contenteditable="true"],[hidden],[aria-hidden="true"]')&&el.ownerDocument.defaultView.getComputedStyle(el).visibility!=='hidden';
  const text=el=>String(el?.innerText||el?.textContent||'').trim().replace(/\s+/g,' ');
  function classify(el){
    const testId=el.getAttribute('data-testid');
    if(['current-user-button','header-account'].includes(testId))return 'profile';
    if(testId==='manage-plan-menu-item')return 'account';
    if(testId==='plans-credits-menu-item'||(el.getAttribute('data-nav-id')==='workspace'&&el.closest('[data-testid="settings-dialog"]')))return 'balance';
    const name=(el.getAttribute('aria-label')||el.getAttribute('title')||text(el)).replace(/\s*[（(](?:ctrl|cmd|control|⌘).*$/i,'').trim();
    if(/^(?:settings(?:\s*(?:&|and)\s*help)?|설정(?:\s*및\s*도움말)?)$/i.test(name))return 'settings';
    if(/^(?:plan\s*(?:&|and)\s*credits|credits?|credit\s*balance|usage\s*details|크레딧|요금제\s*(?:및|&)\s*크레딧)$/i.test(name))return 'balance';
    if(/^(?:manage\s+(?:plan|account|subscription)|my\s+account|subscription|계정\s*관리|구독\s*관리)$/i.test(name))return 'account';
    if(/^(?:open\s+)?(?:profile|user|account)(?:\s+menu)?$|^(?:프로필|계정)\s*메뉴$/i.test(name)||(el.getAttribute('aria-haspopup')==='menu'&&el.querySelector('img')))return 'profile';
    if(/^(?:open|expand)\s+(?:sidebar|menu)$|^(?:메뉴|사이드바)\s*열기$/i.test(name))return 'sidebar';
    return null;
  }
  function anchorAttr(node,doc){
    for(const attr of ['data-testid','data-test-id']){
      const v=node.getAttribute(attr);
      if(v&&/^[a-zA-Z][a-zA-Z0-9_-]{1,70}$/.test(v)){
        const s=`[${attr}="${v}"]`;
        try{if(doc.querySelectorAll(s).length===1)return s;}catch{}
      }
    }
    const id=node.getAttribute('id');
    if(id&&/^[a-zA-Z][a-zA-Z0-9_-]{1,60}$/.test(id)&&!/\d{4,}/.test(id)){
      const s=`[id="${id}"]`;
      try{if(doc.querySelectorAll(s).length===1)return s;}catch{}
    }
    return null;
  }
  function selector(el){
    if(!el||el.nodeType!==1)return null;
    const doc=el.ownerDocument;
    const direct=anchorAttr(el,doc);
    if(direct)return direct;
    const path=[];
    for(let node=el;node&&node.nodeType===1&&path.length<60;node=node.parentElement){
      if(node!==el){
        const anchor=anchorAttr(node,doc);
        if(anchor){
          const candidate=[anchor,...path].join(' > ');
          try{if(candidate.length<=1200&&doc.querySelectorAll(candidate).length===1)return candidate;}catch{}
        }
      }
      const tag=node.tagName.toLowerCase();
      if(tag==='body'){path.unshift('body');break;}
      const siblings=[...node.parentElement?.children||[]].filter(e=>e.tagName===node.tagName);
      path.unshift(tag+':nth-of-type('+(siblings.indexOf(node)+1)+')');
    }
    const s=path.join(' > ');
    try{return s.length<=1200&&doc.querySelectorAll(s).length===1?s:null;}catch{return null;}
  }
  function validSelector(value){return typeof value==='string'&&value.length>0&&value.length<=1200&&/^[a-zA-Z0-9_\-\[\]=" :().#>]+$/.test(value)&&!/(?:input|textarea|iframe|script|style|password)/i.test(value);}
  function extractNumbers(raw){
    const s=String(raw||'').trim().replace(/−/g,'-');
    return [...s.matchAll(/[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\s*[kKmM]?/g)].map(m=>m[0].trim()).filter(t=>CreditParser.numeric(t)!==null);
  }
  function clean(b){
    if(!b||!validSelector(b.selector)||!['credits','gpu_hours','gpu_minutes'].includes(b.unit)||!/^[a-zA-Z][a-zA-Z0-9\-]{0,20}$/.test(b.tag||''))return null;
    const steps=Array.isArray(b.steps)?b.steps.filter(s=>s&&kinds.has(s.kind)&&validSelector(s.selector)).map(s=>({kind:s.kind,selector:s.selector})).slice(0,8):[];
    const numberIndex=Number.isInteger(b.numberIndex)&&b.numberIndex>=0&&b.numberIndex<10?b.numberIndex:0;
    return {selector:b.selector,unit:b.unit,tag:b.tag.toUpperCase(),steps,numberIndex};
  }
  function parse(value,unit,numberIndex=0){
    const raw=String(value||'').trim();if(!raw||raw.length>200)return null;
    if(numberIndex===0){
      if(unit==='credits'){
        const strict=CreditParser.parseCredits({label:'Credit balance',text:raw,trustedBalance:true});
        if(strict)return strict;
      }else if(unit==='gpu_hours'||unit==='gpu_minutes'){
        let duration=raw;if(/^[\d.,+\-\s/]+$/.test(raw))duration+=' '+(unit==='gpu_hours'?'hours':'minutes');
        const strict=CreditParser.parseGPU({label:'Fast time remaining',text:duration});
        if(strict)return strict;
      }
    }
    const tokens=extractNumbers(raw);
    if(!tokens.length)return null;
    const chosen=tokens[Math.min(numberIndex,tokens.length-1)];
    const amount=CreditParser.numeric(chosen);
    if(amount===null)return null;
    if(unit==='credits'){
      return {kind:'balance',label:'보유 크레딧',amount,unit:'credits',period:'balance',balanceType:'total',approximate:/[kKmM]$/i.test(chosen),reset:''};
    }
    if(unit==='gpu_hours'||unit==='gpu_minutes'){
      if(amount<0)return null;
      const mins=Math.round(amount*(unit==='gpu_hours'?60:1)*1e6)/1e6;
      return {kind:'balance',label:'Fast GPU 잔여 시간',amount:mins,unit:'gpu_minutes',period:'balance',balanceType:'total',approximate:false,reset:''};
    }
    return null;
  }
  function read(doc,b){
    b=clean(b);if(!b)return null;
    let el;try{el=doc.querySelector(b.selector);}catch{return null;}
    if(!visible(el)||el.tagName.toUpperCase()!==b.tag)return null;
    return parse(text(el),b.unit,b.numberIndex||0);
  }
  function stepElement(doc,step){
    if(!step||!kinds.has(step.kind)||!validSelector(step.selector))return null;
    let el;try{el=doc.querySelector(step.selector);}catch{return null;}
    if(!visible(el))return null;
    if(step.kind!=='custom'&&classify(el)!==step.kind)return null;
    if(el.tagName==='A'&&el.href){
      try{
        const targetOrigin=new URL(el.href,doc.baseURI).origin,currentOrigin=new URL(doc.URL).origin;
        if(targetOrigin!==currentOrigin)return null;
      }catch{return null;}
    }
    return el;
  }
  return {text,visible,classify,selector,extractNumbers,clean,parse,read,stepElement};
})();
