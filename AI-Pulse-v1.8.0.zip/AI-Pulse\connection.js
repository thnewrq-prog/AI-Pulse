/* Durable configuration contains no cookie, password, or authentication token. */
globalThis.PulseConnection=(()=>{
  class Failure extends Error{constructor(code,message){super(message);this.code=code;}}
  const allowed=(url,id)=>{
    try{
      if(!Object.hasOwn(PROVIDERS,id))return false;
      const p=PROVIDERS[id],u=new URL(url);
      if((p.origins||[p.origin]).includes(u.origin))return true;
      if(p.custom&&p.rootDomain&&['https:','http:'].includes(u.protocol)){
        const host=u.hostname.toLowerCase();
        if(host===p.rootDomain||host.endsWith('.'+p.rootDomain))return true;
      }
      return false;
    }catch{return false;}
  };
  function safeEntry(url,id){
    if(!allowed(url,id))return null;
    const u=new URL(url);
    if(PROVIDERS[id]?.custom){
      if(/\/(?:logout|signout|sign-out)(?:\/|$)/i.test(u.pathname))return null;
      const params=new URLSearchParams();
      for(const [k,v] of u.searchParams.entries()){
        if(/^(?:tab|view|page|section|panel|mode|lang|hl)$/i.test(k)&&v.length<=40)params.set(k,v);
      }
      const query=params.toString()?`?${params.toString()}`:'';
      const hash=u.hash&&u.hash.length<=80&&!/token|code|secret|auth/i.test(u.hash)?u.hash:'';
      return u.origin+u.pathname+query+hash;
    }
    // Save only settings routes or Gemini's account index; discard query tokens.
    if(PROVIDERS[id].entryPaths){if(!PROVIDERS[id].entryPaths.includes(u.pathname)&&!/^\/(?:account|me|settings|billing|subscription)(?:\/[a-z-]+){0,3}\/?$/i.test(u.pathname))return null;}
    else if(!/^\/(?:u\/\d+\/)?(?:app\/?|settings(?:\/usage)?\/?|usage\/?|)?$/.test(u.pathname))return null;
    const hash=/^#settings(?:[\/=](?:usage|limits))?$/i.test(u.hash)?u.hash:'';
    return u.origin+u.pathname+hash;
  }
  const kinds=new Set(['usage','settings','profile','sidebar','balance','account','custom']);
  function cleanNavigation(steps){return Array.isArray(steps)?steps.filter(x=>kinds.has(x)).slice(0,5):[];}
  function cleanMetrics(metrics){
    if(!Array.isArray(metrics))return [];
    return metrics.flatMap(m=>{
      if(!m||typeof m.label!=='string')return [];
      if(m.kind==='balance'){
        if(!['credits','gpu_minutes'].includes(m.unit)||!Number.isFinite(m.amount)||Math.abs(m.amount)>1e12||(m.unit==='gpu_minutes'&&m.amount<0))return [];
        return [{kind:'balance',label:m.label.slice(0,100),amount:m.amount,unit:m.unit,period:'balance',balanceType:['total','subscription','topup','other'].includes(m.balanceType)?m.balanceType:'other',approximate:!!m.approximate,reset:typeof m.reset==='string'?m.reset.slice(0,140):''}];
      }
      if(!Number.isFinite(m.percentUsed)||m.percentUsed<0||m.percentUsed>100||!['used','remaining'].includes(m.direction))return [];
      return [{label:m.label.slice(0,100),period:['session','week','other'].includes(m.period)?m.period:'other',percentUsed:m.percentUsed,sourceValue:Number.isFinite(m.sourceValue)?m.sourceValue:null,direction:m.direction,reset:typeof m.reset==='string'?m.reset.slice(0,140):''}];
    }).slice(0,16);
  }
  function message(status,id,stage){
    const en=globalThis.PulseI18n?.getLang()==='en';
    if(en){
      if(id==='gpt'&&status==='no-quota')return 'ChatGPT Usage settings opened, but no explicit session or weekly quota numbers were shown.';
      if(id==='gpt'&&status==='layout-changed')return 'Could not open ChatGPT Settings → Usage. Check your login state on the official page and refresh again.';
      if(id==='comfy'&&['no-quota','layout-changed'].includes(status)){
        const detail={'counter-missing':'Comfy account menu opened, but no credit balance was displayed.','settings-open':'Comfy settings opened, but Plan & Credits balance was not found.','profile-visible':'Comfy account detected, but the balance menu could not be opened.','app-not-ready':'Comfy Cloud account view is not ready yet.'}[stage];
        if(detail)return detail+' Check your login/workspace on the official page or use “Bind Balance”.';
      }
      if(PROVIDERS[id]?.custom&&['no-quota','layout-changed'].includes(status)){
        return 'Could not find a balance at the target location. Click “Bind Balance” on the card and click the credit number with your mouse.';
      }
      if(status==='no-quota'&&PROVIDERS[id]?.type)return 'Could not find a balance on the current page. Use “Bind Balance” below the card to link the number.';
      if(status==='layout-changed'&&!PROVIDERS[id]?.type)return 'Could not automatically navigate to the official usage screen. Please check the official page.';
      return {
        ok:'Automatically checked official usage. Temporary lookup window was closed.',
        'auth-required':'Session expired or signed out. Click “Sign In Again” and then Refresh.',
        challenge:'The official site requested a security check (CAPTCHA). Complete it in “Verify Login” and refresh.',
        'no-quota':'No readable usage or balance numbers were provided on the official account screen.',
        'layout-changed':'Could not automatically recognize the balance screen. Use “Bind Balance” to link the number.'
      }[status]||'Could not read usage data. Please refresh again.';
    }
    if(id==='gpt'&&status==='no-quota')return 'ChatGPT 사용량 화면은 열렸지만 세션·주간 한도의 명시적인 수치를 찾지 못했습니다. 계정·플랜에 따라 제공되는 항목이 다를 수 있습니다. 공식 화면의 설정 → 사용량을 확인해 주세요. 일반 채팅 횟수나 앱별 설정 한도를 사용량으로 추정하지 않습니다.';
    if(id==='gpt'&&status==='layout-changed')return 'ChatGPT의 설정 → 사용량 화면을 열지 못했습니다. 공식 화면에서 같은 브라우저 프로필의 로그인·워크스페이스와 사용량 메뉴를 확인한 뒤 다시 갱신해 주세요.';
    if(id==='comfy'&&['no-quota','layout-changed'].includes(status)){
      const detail={'counter-missing':'Comfy 계정 메뉴는 열렸지만 잔액 숫자가 표시되지 않았습니다.','settings-open':'Comfy 설정은 열렸지만 Plan & Credits의 잔액을 찾지 못했습니다.','profile-visible':'Comfy 계정은 확인했지만 잔액 메뉴를 열지 못했습니다.','app-not-ready':'Comfy Cloud의 계정 화면이 아직 준비되지 않았습니다.'}[stage];
      if(detail)return detail+' 공식 화면의 로그인·워크스페이스 상태를 확인한 뒤 갱신해 주세요. 숫자가 보인다면 ‘잔액 위치 지정’으로 연결할 수 있습니다.';
    }
    if(PROVIDERS[id]?.custom&&['no-quota','layout-changed'].includes(status)){
      return '지정한 화면에서 잔액 수치를 찾지 못했습니다. 카드 아래 ‘잔액 위치 지정’을 눌러 크레딧 숫자를 마우스로 클릭해 연결해 주세요.';
    }
    if(status==='no-quota'&&PROVIDERS[id]?.type)return '현재 화면에서 잔액을 찾지 못했습니다. 카드 아래 ‘잔액 위치 지정’으로 실제 숫자를 한 번 연결해 주세요.';if(status==='layout-changed'&&!PROVIDERS[id]?.type)return '공식 사용량 화면으로 자동 이동하지 못했습니다. 공식 화면을 확인해 주세요.';return {
    ok:'공식 사용량을 자동 조회했습니다. 조회용 화면은 닫혔습니다.',
    'auth-required':'로그인이 만료되었거나 로그아웃되어 있습니다. ‘다시 로그인’ 후 갱신해 주세요.',
    challenge:'공식 사이트가 보안 확인을 요청했습니다. ‘로그인 확인’에서 직접 확인한 뒤 갱신해 주세요.',
    'no-quota':'공식 계정 화면에서 읽을 수 있는 사용량·잔액 수치가 제공되지 않았습니다.',
    'layout-changed':'잔액 화면을 자동 인식하지 못했습니다. 카드 아래 ‘잔액 위치 지정’으로 실제 숫자를 한 번 연결해 주세요.'
  }[status]||'사용량을 읽지 못했습니다. 다시 갱신해 주세요.';}
  return {Failure,allowed,safeEntry,cleanNavigation,cleanMetrics,message};
})();
