/* CDP is scoped to fresh lookup tabs owned by this worker. No user tabs. */
globalThis.PulseBackgroundRenderer=(()=>{
 const sessions=new Map();
 async function command(tabId,method,params={}){const s=sessions.get(tabId);if(!s||s.canceled)throw new PulseConnection.Failure('renderer-unavailable','백그라운드 실행 연결이 해제되었습니다. 다시 갱신해 주세요.');return chrome.debugger.sendCommand({tabId},method,params);}
 async function ensure(tabId){
  await command(tabId,'Emulation.setFocusEmulationEnabled',{enabled:true});
  await command(tabId,'Page.setWebLifecycleState',{state:'active'});
 }
 async function create(id,url){
  if(!PulseConnection.allowed(url,id))throw new PulseConnection.Failure('renderer-unavailable','허용된 공식 조회 주소만 사용할 수 있습니다.');
  if(!await chrome.permissions.contains({permissions:['debugger']}))throw new PulseConnection.Failure('permission-required','백그라운드 실행에 필요한 디버깅 권한이 없습니다. 확장 프로그램을 업데이트하고 다시 사용 설정해 주세요.');
  // Creation is internal: callers cannot pass an existing user tab ID.
  const window=await chrome.windows.create({url:'about:blank',type:'popup',state:'minimized',focused:false});
  const tab=window?.tabs?.[0]||(Number.isInteger(window?.id)?(await chrome.tabs.query({windowId:window.id}))[0]:null);
  if(!Number.isInteger(tab?.id))throw new PulseConnection.Failure('network-error','조회 창을 만들지 못했습니다.');
  sessions.set(tab.id,{id,attached:false,canceled:false,balance:null,balanceWaiters:[],requests:new Map()});
  try{
   await chrome.debugger.attach({tabId:tab.id},'1.3');
   const s=sessions.get(tab.id);if(!s||s.canceled)throw Error('연결이 취소되었습니다.');s.attached=true;
   await command(tab.id,'Page.enable');if(id==='comfy')await command(tab.id,'Network.enable');await ensure(tab.id);
   // Set before navigating, so hidden-page initialization does not stall.
   await chrome.tabs.update(tab.id,{url});
   return tab;
  }catch(e){await stop(tab.id);try{await chrome.tabs.remove(tab.id);}catch{}if(e instanceof PulseConnection.Failure)throw e;throw new PulseConnection.Failure('renderer-unavailable','백그라운드 실행을 연결하지 못했습니다. 디버깅 권한 또는 회사 브라우저 정책을 확인해 주세요.');}
 }
 async function verify(tabId){
  await ensure(tabId);
  const result=await command(tabId,'Runtime.evaluate',{expression:'({visibility:document.visibilityState,focused:document.hasFocus()})',returnByValue:true});
  if(result?.result?.value?.visibility!=='visible')throw new PulseConnection.Failure('renderer-unavailable','브라우저가 조회 페이지의 활성 상태를 유지하지 못했습니다. Chrome/Edge를 업데이트한 뒤 다시 갱신해 주세요.');
 }
 async function stop(tabId){
  const s=sessions.get(tabId);sessions.delete(tabId);if(!s?.attached)return;
  try{await chrome.debugger.sendCommand({tabId},'Emulation.setFocusEmulationEnabled',{enabled:false});}catch{}
  try{await chrome.debugger.detach({tabId});}catch{}
 }
 chrome.debugger.onDetach.addListener(source=>{const s=sessions.get(source.tabId);if(s){s.attached=false;s.canceled=true;}});
 function waitBalance(tabId){const s=sessions.get(tabId);if(s?.balance)return Promise.resolve({metrics:[s.balance],status:'ok',source:'comfy-official-balance',viewFound:true});return new Promise(resolve=>{if(s)s.balanceWaiters.push(resolve);});}
 chrome.debugger.onEvent.addListener((source,method,params)=>{
  const s=sessions.get(source.tabId);if(!s||s.canceled)return;
  if(s.id==='comfy'&&method==='Network.responseReceived'){
   const response=params?.response;
   const scope=response?.status===200&&PulseComfyBalance.endpoint(response.url);
   if(scope==='workspace'&&s.requests.size<8)s.requests.set(params.requestId,{scope,url:'https://cloud.comfy.org/api/billing/balance'});
   return;
  }
  if(s.id==='comfy'&&method==='Network.loadingFailed'){s.requests.delete(params.requestId);return;}
  if(s.id==='comfy'&&method==='Network.loadingFinished'){
   const request=s.requests.get(params.requestId);if(!request)return;s.requests.delete(params.requestId);
   command(source.tabId,'Network.getResponseBody',{requestId:params.requestId}).then(result=>{
    if(sessions.get(source.tabId)!==s||s.canceled||result.base64Encoded)return;
    const metric=PulseComfyBalance.parse(request.url,result.body);if(!metric)return;
    if(s.balanceScope==='workspace'&&request.scope!=='workspace')return;
    s.balance=metric;s.balanceScope=request.scope;
    const read={metrics:[metric],status:'ok',source:'comfy-official-balance',viewFound:true};s.balanceWaiters.splice(0).forEach(resolve=>resolve(read));
   }).catch(()=>{});return;
  }
  if(method!=='Page.frameNavigated'||params?.frame?.parentId)return;
  if(params?.frame?.url==='about:blank')return;
  if(!PulseConnection.allowed(params?.frame?.url,s.id)){stop(source.tabId);return;}
  ensure(source.tabId).catch(()=>{if(sessions.has(source.tabId))sessions.get(source.tabId).canceled=true;});
 });
 return {create,verify,stop,waitBalance};
})();
