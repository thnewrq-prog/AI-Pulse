(() => {
  'use strict';
  const native=typeof chrome!=='undefined' && !!chrome.runtime?.id && !!chrome.storage?.local;
  let state={connections:{},snapshots:{},history:[],customProviders:{},language:PulseI18n.getLang()};
  let period='session',view='dashboard',toastTimer;
  let editing=false,draft=null,dragged=null,savingLayout=false,submitMode='bind';
  const displayLayout=()=>PulseLayout.clean(editing?draft:state.layout);
  if(!native){
    try{
      state.layout=JSON.parse(localStorage.getItem('pulsePreviewLayout')||'null');
      state.customProviders=JSON.parse(localStorage.getItem('pulsePreviewCustom')||'{}');
      state.language=localStorage.getItem('pulseLang')||'ko';
      PulseI18n.setLang(state.language);
      syncCustomProviders(state.customProviders);
    }catch{}
  }
  const busy=new Set();
  const working=id=>busy.has(id)||!!state.jobs?.[id];
  const t=(key,vars)=>PulseI18n.t(key,vars);
  const statusName=code=>code?t('status.'+code):'';
  const $=id=>document.getElementById(id);
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const date=value=>new Date(value).toLocaleString(PulseI18n.locale(),{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false});
  const clock=value=>new Date(value).toLocaleTimeString(PulseI18n.locale(),{hour:'2-digit',minute:'2-digit',hour12:false});
  function toast(message,error=false){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;$('toast').classList.toggle('error-toast',error);toastTimer=setTimeout(()=>$('toast').hidden=true,6000);}
  async function send(type,id,extra={}){if(!native)throw Error(t('toast.needInstall'));const response=await chrome.runtime.sendMessage({type,id,...extra});if(response?.error)throw Error(response.error);return response;}
  async function load(){
    if(native){
      state=await send('read');
      if(state.language)PulseI18n.setLang(state.language);
      syncCustomProviders(state.customProviders);
    }
    render();
  }
  function updateBreadcrumb(){
    const names={
      dashboard:t('nav.dashboard'),
      connections:t('nav.connectionsTitle'),
      history:t('nav.history'),
      settings:t('nav.settings'),
      help:t('nav.help')
    };
    $('breadcrumb').innerHTML=escape(t('topbar.workspace'))+' <span>/</span> '+escape(names[view]||names.dashboard);
  }
  function changeView(next){
    view=next;
    document.querySelectorAll('.view').forEach(e=>e.hidden=e.id!==view);
    document.querySelectorAll('.nav-item').forEach(e=>e.classList.toggle('active',e.dataset.view===view));
    updateBreadcrumb();
    window.scrollTo(0,0);
  }
  const logo=(id,extra='')=>`<div class="provider-logo ${extra}" style="--provider:${escape(PROVIDERS[id]?.color||'#4ea8de')}">${escape(PROVIDERS[id]?.mark||'★')}</div>`;
  const number=n=>Number(n).toLocaleString(PulseI18n.locale(),{maximumFractionDigits:2});
  function metricText(m){
    if(m.kind!=='balance')return t('metric.usedPercent',{percent:m.percentUsed});
    const prefix=m.approximate?t('metric.approx'):'';
    if(m.unit==='gpu_minutes'){
      const hours=Math.floor(m.amount/60),minutes=Math.round((m.amount-hours*60)*100)/100;
      return prefix+(hours?t('metric.hours',{h:hours}):'')+t('metric.minutes',{m:number(minutes)});
    }
    return prefix+number(m.amount)+' credits';
  }
  function balanceCard(id){
    const p=PROVIDERS[id],connected=state.connections[id]?.enabled,s=state.snapshots[id],loading=working(id),valid=s?.status==='ok';
    const hasBinding=!!state.connections[id]?.binding;
    const metrics=valid?s.metrics.filter(m=>m.kind==='balance'):[],m=metrics[0];
    const stale=valid&&Date.now()-new Date(s.checkedAt).getTime()>300000;
    const status=loading?t('status.working'):!connected?t('status.disconnected'):valid?(stale?t('status.stale'):t('status.ok')):(p.custom&&!hasBinding?t('status.needsBind'):statusName(s?.status)||t('status.waitingFirst'));
    const unit=p.type==='gpu'?t('card.unitGpu'):t('card.unitCredits');
    const job=state.jobs?.[id],elapsed=job?Math.max(0,Math.floor((Date.now()-new Date(job.startedAt).getTime())/1000)):0;
    const stage=job?.stage?t('stage.'+job.stage):t('stage.default');
    const note=loading?(job?t('card.loadingJobNote',{stage,elapsed}):t('card.loadingParallelNote')):!connected?t('card.disconnectedBalanceNote'):(p.custom&&!hasBinding&&!valid)?t('card.needsBindNote'):!valid?(s?.message||PulseI18n.providerHint(p)):(PulseI18n.translateMetricLabel(m?.label)||t('card.noBalanceNote'));
    const customBadge=p.custom?`<span class="custom-pill">${escape(t('card.customPill'))}</span>`:'';
    return `<article class="service-card credit-card" style="--provider:${escape(p.color)}"><div class="card-head">${logo(id)}<div class="provider-title"><h3>${escape(p.name)} ${customBadge}</h3><small>${escape(p.company)}</small></div><span class="status ${valid&&!stale?'ok':connected?'warn':''}">${escape(status)}</span></div><div class="card-middle"><div class="balance-label">${escape(unit)}</div><div class="balance-value ${m?'has-value':''} ${m&&m.amount<=0?'low-balance':''}"><strong>${loading?'···':m?escape(metricText(m)):'—'}</strong><span>${escape(m?(stale?t('card.staleSub'):t('card.officialBalanceSub')):(p.custom&&!hasBinding?t('card.waitBindSub'):t('card.waitConnectSub')))}</span></div><p class="empty-note">${escape(note)}</p>${metrics.slice(1).map(m=>`<div class="metric-line"><span>${escape(PulseI18n.translateMetricLabel(m.label))}</span><b>${escape(metricText(m))}</b></div>`).join('')}</div><div class="card-actions">${connected?`<button class="button secondary" data-action="refresh" data-id="${id}" ${loading?'disabled':''}>${escape(t('card.refreshBalance'))}</button><button class="icon-button" data-action="open" data-id="${id}" aria-label="${escape(t('card.openOfficialAria',{name:p.name}))}" ${loading?'disabled':''}>↗</button>`:`<button class="button secondary" data-action="connect" data-id="${id}">${escape(t('card.connectAccount'))}</button>`}</div><div class="card-meta"><span>${escape(t('card.metaOfficialBalance'))}</span><span>${escape(s?.checkedAt?t('card.checkedAt',{time:clock(s.checkedAt)}):t('card.notCheckedYet'))}</span></div></article>`;
  }
  function card(id){
    if(PROVIDERS[id].type)return balanceCard(id);
    const p=PROVIDERS[id],connected=state.connections[id]?.enabled,s=state.snapshots[id],loading=working(id);
    const valid=s?.status==='ok';
    const stale=valid && Date.now()-new Date(s.checkedAt).getTime()>300000;
    const metrics=valid?s.metrics:[];
    const chosen=metrics.filter(m=>period==='all'||m.period===period);
    const m=chosen[0];
    const label=loading?t('status.working'):!connected?t('status.disconnected'):valid?(stale?t('status.stale'):t('status.ok')):statusName(s?.status)||t('status.waitingFirst');
    let note=!connected?t('card.disconnectedQuotaNote'):loading?t('card.loadingQuotaNote'):!valid?escape(s?.message||t('card.defaultQuotaNote')):!m?t('card.noPeriodQuotaNote'):escape(PulseI18n.translateMetricLabel(m.label));
    const value=m?`${m.percentUsed}<small>%</small>`:'—';
    const circumference=364.42;
    const circle=m?`<circle class="progress" cx="72" cy="72" r="58" stroke-dasharray="${circumference}" stroke-dashoffset="${circumference*(1-m.percentUsed/100)}"/>`:'';
    const extras=chosen.slice(1).map(m=>`<div class="metric-line"><span>${escape(PulseI18n.translateMetricLabel(m.label))}</span><b>${escape(t('metric.usedPercent',{percent:m.percentUsed}))}</b></div>`).join('');
    const quotaLabel=period==='session'?t('card.quotaLabelSession'):period==='week'?t('card.quotaLabelWeek'):t('card.quotaLabelAll');
    return `<article class="service-card" style="--provider:${escape(p.color)}"><div class="card-head">${logo(id)}<div class="provider-title"><h3>${escape(p.name)}</h3><small>${escape(p.company)}</small></div><span class="status ${valid&&!stale?'ok':connected?'warn':''}">${escape(label)}</span></div><div class="card-middle"><div class="quota-label">${escape(quotaLabel)}</div><div class="gauge" role="img" aria-label="${m?escape(m.label)+' '+m.percentUsed+'%':''}"><svg viewBox="0 0 144 144" aria-hidden="true"><circle class="track" cx="72" cy="72" r="58"/>${circle}</svg><div class="gauge-center ${m?'has-value':''}"><strong>${loading?'···':value}</strong></div></div><div class="gauge-caption">${escape(m?(stale?t('card.gaugeCaptionStale'):t('card.gaugeCaptionOk')):t('card.gaugeCaptionWait'))}</div><p class="empty-note ${loading?'loading-text':''}">${note}</p>${m?.reset?`<p class="reset-note">${escape(m.reset)}</p>`:''}${extras}</div><div class="card-actions">${connected?`<button class="button secondary" data-action="open" data-id="${id}" ${loading?'disabled':''}>${escape(t('card.openOfficial'))}</button><button class="icon-button ${loading?'spin':''}" data-action="refresh" data-id="${id}" title="${escape(p.name)}" aria-label="${escape(p.name)}" ${loading?'disabled':''}>↻</button>`:`<button class="button secondary" data-action="connect" data-id="${id}">${escape(t('card.connectAccount'))}</button>`}</div><div class="card-meta"><span>${escape(connected?t('card.metaOfficialQuota'):t('card.metaConnectHint'))}</span><span>${escape(s?.checkedAt?t('card.checkedAt',{time:clock(s.checkedAt)}):t('card.notCheckedYet'))}</span></div></article>`;
  }
  function rows(items){if(!items.length)return `<div class="empty-history"><span class="empty-symbol">◷</span><b>${escape(t('history.emptyTitle'))}</b><p>${escape(t('history.emptyDesc'))}</p></div>`;return items.filter(h=>PROVIDERS[h.id]).map(h=>`<div class="history-row">${logo(h.id)}<div><b>${escape(PROVIDERS[h.id].name)}</b><p>${h.metrics.slice(0,3).map(m=>`${escape(PulseI18n.translateMetricLabel(m.label))} ${escape(metricText(m))}`).join(' · ')}</p></div><time datetime="${escape(h.at)}">${date(h.at)}</time></div>`).join('');}
  function renderLayout(){
    const layout=displayLayout(),ids=PulseLayout.visible(layout).filter(id=>PROVIDERS[id]);
    $('editLayout').textContent=editing?t('dashboard.editingLayout'):t('dashboard.editLayout');
    $('editLayout').setAttribute('aria-expanded',String(editing));$('editLayout').hidden=editing;
    $('layoutEditor').hidden=!editing;$('cards').classList.toggle('layout-editing',editing);
    if(editing)$('serviceToggles').innerHTML=layout.order.filter(id=>PROVIDERS[id]).map(id=>`<label class="service-toggle"><input type="checkbox" data-show-service="${id}" ${layout.hidden.includes(id)?'':'checked'} ${savingLayout?'disabled':''}><span>${escape(PROVIDERS[id].name)}</span></label>`).join('');
    $('saveLayout').disabled=savingLayout;$('cancelLayout').disabled=savingLayout;
    $('resetLayout').disabled=savingLayout;
    $('cards').innerHTML=ids.map(id=>card(id).replace('<article ',`<article data-service="${id}" `)).join('');
    $('emptyLayout').hidden=ids.length!==0;
    if(editing)for(const [index,id] of ids.entries()){
      const element=$('cards').querySelector(`[data-service="${id}"]`),tools=document.createElement('div');tools.className='card-edit-tools';
      tools.innerHTML=`<button class="drag-handle" draggable="true" data-drag-id="${id}" aria-label="${escape(PROVIDERS[id].name)} ${escape(t('layout.dragTitle'))}" title="${escape(t('layout.dragTitle'))}">⠿</button><span>${index+1}</span><button data-layout-action="previous" data-id="${id}" aria-label="${escape(PROVIDERS[id].name)} ${escape(t('layout.prev'))}" ${index===0?'disabled':''}>←</button><button data-layout-action="next" data-id="${id}" aria-label="${escape(PROVIDERS[id].name)} ${escape(t('layout.next'))}" ${index===ids.length-1?'disabled':''}>→</button><button data-layout-action="hide" data-id="${id}" aria-label="${escape(PROVIDERS[id].name)} ${escape(t('layout.hide'))}">${escape(t('layout.hide'))}</button>`;
      element.prepend(tools);
    }
  }
  function moveCard(id,target){draft=PulseLayout.move(draft,id,target);render();}
  async function finishEditing(){
    savingLayout=true;render();const layout=PulseLayout.clean(draft);
    try{if(native)await send('set-layout',null,{layout});else localStorage.setItem('pulsePreviewLayout',JSON.stringify(layout));state.layout=layout;editing=false;draft=null;toast(t('toast.layoutSaved'));}catch(e){toast(t('toast.layoutError',{error:e.message}),true);}finally{savingLayout=false;render();}
  }
  async function selectLanguage(lang){
    const normalized=PulseI18n.setLang(lang);
    state.language=normalized;
    try{
      if(native)await send('set-language',null,{language:normalized});
      else localStorage.setItem('pulseLang',normalized);
      render();
      toast(t('toast.langSaved'));
    }catch(e){
      render();
    }
  }
  function render(){
    if(dragged)return;
    if(state.language&&state.language!==PulseI18n.getLang())PulseI18n.setLang(state.language);
    PulseI18n.applyStaticDOM(document);
    updateBreadcrumb();
    const curLang=PulseI18n.getLang();
    document.querySelectorAll('[data-lang-select]').forEach(btn=>{
      const active=btn.getAttribute('data-lang-select')===curLang;
      btn.classList.toggle('active',active);
      btn.setAttribute('aria-pressed',String(active));
    });
    syncCustomProviders(state.customProviders);
    const totalServices=Object.keys(PROVIDERS).length;
    const focused=document.activeElement,focusedToggle=focused?.dataset.showService,focusedMove=focused?.dataset.layoutAction,focusedId=focused?.dataset.id;
    const connected=Object.keys(PROVIDERS).filter(id=>state.connections[id]?.enabled).length;
    $('connectedCount').innerHTML=connected+' <small>/ '+totalServices+'</small>';
    document.querySelector('[data-view="connections"] i').textContent=totalServices;
    if($('footerServiceCount'))$('footerServiceCount').textContent=t('footer.serviceCount',{count:totalServices});
    $('readCount').innerHTML=Object.values(state.snapshots).filter(s=>s.status==='ok'&&PROVIDERS[s.id]).length+' <small>'+escape(t('summary.readUnit'))+'</small>';
    const dates=Object.values(state.snapshots).filter(s=>PROVIDERS[s?.id]).map(s=>s.checkedAt).filter(Boolean).sort();
    $('lastRefresh').textContent=dates.length?clock(dates.at(-1)):t('summary.noneYet');
    const running=new Set([...busy,...Object.keys(state.jobs||{})]).size;
    $('refreshMeta').textContent=running?t('summary.runningCount',{count:running}) : dates.length?date(dates.at(-1)):t('summary.refreshWait');
    renderLayout();
    $('recentHistory').innerHTML=rows(state.history.slice(0,3));$('fullHistory').innerHTML=rows(state.history);
    $('connectionCards').innerHTML=Object.entries(PROVIDERS).map(([id,p])=>{
      const isConn=state.connections[id]?.enabled;
      const customBadge=p.custom?`<span class="custom-pill">${escape(t('card.customPill'))}</span>`:'';
      const urlInfo=p.custom?`<p class="custom-url-line">${escape(t('conn.entryUrl'))} <code>${escape(state.connections[id]?.entryUrl||p.url)}</code></p>`:'';
      return `<article class="connection-row">${logo(id)}<div><h3>${escape(p.name)} ${customBadge} <small style="font-size:11px;color:#8c9889;font-weight:400">${escape(p.company)}</small></h3><p>${escape(PulseI18n.providerHint(p))}</p>${urlInfo}<p>${escape(isConn?t('conn.statusSaved'):t('conn.notConnected'))}</p></div><div class="connection-buttons">${isConn?`<button class="button secondary" data-action="open" data-id="${id}" ${busy.has(id)?'disabled':''}>${escape(t('card.openOfficial'))}</button>${p.type?`<button class="button secondary" data-action="bind" data-id="${id}" ${busy.has(id)?'disabled':''}>${escape(state.connections[id]?.binding?t('card.rebindBtnIcon'):t('card.bindBtnIcon'))}</button>`:''}${p.custom?`<button class="button secondary" data-action="edit-custom" data-id="${id}" ${busy.has(id)?'disabled':''}>${escape(t('card.editCustomFull'))}</button><button class="button danger-outline" data-action="delete-custom" data-id="${id}" ${busy.has(id)?'disabled':''}>${escape(t('card.deleteCustom'))}</button>`:`<button class="button secondary" data-action="disconnect" data-id="${id}" ${busy.has(id)?'disabled':''}>${escape(t('card.disconnect'))}</button>`}`:`<button class="button primary" data-action="connect" data-id="${id}">${escape(t('card.connectAccountLink'))}</button>${p.custom?`<button class="button secondary" data-action="edit-custom" data-id="${id}">${escape(t('card.editCustom'))}</button><button class="button danger-outline" data-action="delete-custom" data-id="${id}">${escape(t('card.deleteCustom'))}</button>`:''}`}</div></article>`;
    }).join('');
    for(const [index,id] of Object.keys(PROVIDERS).entries()) {
      if(!state.connections[id]?.enabled)continue;
      const p=PROVIDERS[id];
      const cardElement=$('cards').querySelector(`[data-service="${id}"]`),snapshot=state.snapshots[id];
      const hasBinding=!!state.connections[id]?.binding;
      if(cardElement){
        const meta=cardElement.querySelector('.card-meta');
        const recovery=['auth-required','challenge','permission-required'].includes(snapshot?.status);
        const needsFirstBind=p.custom&&!hasBinding&&snapshot?.status!=='ok';
        const action=cardElement.querySelector('.card-actions .button');
        action.dataset.action=recovery?(snapshot.status==='permission-required'?'connect':'open'):needsFirstBind?'bind':'refresh';
        action.textContent=recovery?(snapshot.status==='permission-required'?t('card.recoverPermission'):snapshot.status==='challenge'?t('card.recoverChallenge'):t('card.recoverAuth')):needsFirstBind?t('card.bindAction'):p.type?t('card.refreshBalance'):t('card.refreshUsage');
        action.classList.toggle('primary',!recovery);action.disabled=working(id);
        const icon=cardElement.querySelector('.icon-button');icon.dataset.action=recovery?'refresh':'open';icon.textContent=recovery?'↻':'↗';icon.title=recovery?t('card.refreshUsage'):t('card.openOfficial');icon.setAttribute('aria-label',p.name+' '+icon.title);icon.disabled=working(id);
        icon.classList.toggle('spin',working(id)&&recovery);
        meta.firstElementChild.textContent=t('card.metaRestartSupport');
        if(p.type){
          const leftWrap=document.createElement('span');
          leftWrap.className='card-meta-actions';
          const bind=document.createElement('button');
          bind.className='text-button';
          bind.dataset.action='bind';
          bind.dataset.id=id;
          bind.textContent=hasBinding?t('card.rebindBtn'):t('card.bindBtn');
          bind.disabled=working(id);
          leftWrap.append(bind);
          if(p.custom){
            const editBtn=document.createElement('button');
            editBtn.className='text-button';
            editBtn.dataset.action='edit-custom';
            editBtn.dataset.id=id;
            editBtn.textContent=t('card.editCustom');
            editBtn.disabled=working(id);
            const delBtn=document.createElement('button');
            delBtn.className='text-button danger-text';
            delBtn.dataset.action='delete-custom';
            delBtn.dataset.id=id;
            delBtn.textContent=t('card.deleteCustom');
            delBtn.disabled=working(id);
            leftWrap.append(document.createTextNode(' · '),editBtn,document.createTextNode(' · '),delBtn);
          }
          meta.firstElementChild.replaceWith(leftWrap);
        }
        if(state.snapshots[id]?.mode==='screen')meta.lastElementChild.textContent=t('card.screenReadAt',{time:clock(state.snapshots[id].checkedAt)});
      }
      const row=$('connectionCards').children[index];
      if(row){
        const info=row.querySelector('p:last-child');
        info.textContent=state.connections[id].binding?t('conn.statusBound'):state.connections[id].lastSuccessAt?t('conn.statusReady'):t('conn.statusSaved');
        const buttons=row.querySelector('.connection-buttons');
        const scan=document.createElement('button');scan.className='text-button';scan.dataset.action='scan';scan.dataset.id=id;scan.disabled=working(id);scan.textContent=t('card.scanScreen');scan.title=t('card.scanScreenTitle');buttons.append(scan);
        buttons.querySelectorAll('button').forEach(b=>b.disabled=working(id));
      }
    }
    const refreshing=busy.size>0||Object.keys(state.jobs||{}).length>0;
    $('refreshAll').disabled=refreshing||editing;
    $('refreshAll').classList.toggle('busy',refreshing);
    $('refreshAll').lastElementChild.textContent=refreshing?t('dashboard.refreshingAll'):t('dashboard.refreshAll');
    $('clearData').disabled=refreshing;
    if($('settingsClearData'))$('settingsClearData').disabled=refreshing;
    $('exportData').disabled=!state.history.length;
    if($('settingsExportData'))$('settingsExportData').disabled=!state.history.length;
    $('helpLinks').innerHTML=Object.values(BUILTIN_PROVIDERS).map(p=>`<a href="${p.help}" target="_blank" rel="noopener noreferrer">${escape(t('help.officialGuide',{name:p.name}))}</a>`).join('');
    if(editing){const target=focusedToggle?$(`serviceToggles`).querySelector(`[data-show-service="${focusedToggle}"]`):focusedMove&&focusedId?$('cards').querySelector(`[data-layout-action="${focusedMove}"][data-id="${focusedId}"]`):null;if(target&&!target.disabled)target.focus({preventScroll:true});}
  }
  async function connect(id){
    if(!native){changeView('help');toast(t('toast.connectPreview'));return;}
    const granted=await chrome.permissions.request({origins:providerPatterns(id)});
    if(!granted){toast(t('toast.connectPermDenied'),true);return;}
    await send('connect',id);await load();toast(t('toast.connectSuccess'));
  }
  async function bindService(id){
    if(!native){changeView('help');toast(t('toast.bindPreview'));return;}
    const granted=await chrome.permissions.request({origins:providerPatterns(id)});
    if(!granted){toast(t('toast.bindPermDenied'),true);return;}
    await send('bind',id);
    await load();
    toast(t('toast.bindStarted'));
  }
  async function refresh(ids,mode='refresh'){
    ids=PulseLayout.refreshOrder(ids);
    if(!native){changeView('help');toast(t('toast.refreshPreview'));return;}
    if(!ids.length){changeView('connections');toast(t('toast.refreshNone'));return;}
    for(const id of ids)busy.add(id);render();
    let successes=0;const failures=[];
    await Promise.all(ids.map(async id=>{try{const r=await send(mode,id);if(r.status==='ok')successes++;else failures.push(PROVIDERS[id].name+': '+(statusName(r.status)||t('toast.refreshFailed')));}catch(e){failures.push(PROVIDERS[id].name+': '+e.message);}finally{busy.delete(id);await load();}}));
    const failStr=failures.length?' · '+failures.join(', '):'';
    toast(successes?t('toast.refreshDone',{count:successes,mode:mode==='scan'?t('toast.modeScan'):t('toast.modeAuto'),failures:failStr}):failures.join(' · ')||t('toast.refreshFailed'),!successes);
  }

  function renderPresets(){
    const container=$('presetChips');
    if(!container||!globalThis.CUSTOM_PRESETS)return;
    container.innerHTML=CUSTOM_PRESETS.map((p,idx)=>`<button type="button" class="preset-chip" data-preset-index="${idx}"><span class="preset-mark" style="color:${escape(p.color)}">${escape(p.mark)}</span><span>${escape(p.name)}</span></button>`).join('');
  }
  function openCustomModal(editId=null){
    renderPresets();
    const modal=$('customModal');
    if(editId&&PROVIDERS[editId]?.custom){
      const p=PROVIDERS[editId];
      $('customModalTitle').textContent=t('modal.editTitle');
      $('customId').value=editId;
      $('customName').value=p.name;
      $('customCompany').value=p.company;
      $('customUrl').value=state.connections[editId]?.entryUrl||p.url;
      $('customType').value=p.type==='gpu'?'gpu':'credits';
      $('customMark').value=p.mark;
      $('customColor').value=p.color||'#00c4cc';
    }else{
      $('customModalTitle').textContent=t('modal.addTitle');
      $('customId').value='';
      $('customName').value='';
      $('customCompany').value='';
      $('customUrl').value='';
      $('customType').value='credits';
      $('customMark').value='';
      $('customColor').value='#00c4cc';
    }
    modal.hidden=false;
    setTimeout(()=>$('customName').focus(),50);
  }
  function closeCustomModal(){
    $('customModal').hidden=true;
  }

  $('openCustomModal')?.addEventListener('click',()=>openCustomModal());
  $('openCustomModalConn')?.addEventListener('click',()=>openCustomModal());
  $('guideAddService')?.addEventListener('click',()=>openCustomModal());
  $('settingsAddCustom')?.addEventListener('click',()=>openCustomModal());
  $('settingsOpenLayout')?.addEventListener('click',()=>{changeView('dashboard');editing=true;draft=PulseLayout.clean(state.layout);render();});
  $('closeCustomModal')?.addEventListener('click',closeCustomModal);
  $('cancelCustomModal')?.addEventListener('click',closeCustomModal);
  $('customModal')?.addEventListener('click',e=>{if(e.target===$('customModal'))closeCustomModal();});
  $('presetChips')?.addEventListener('click',e=>{
    const chip=e.target.closest('[data-preset-index]');
    if(!chip)return;
    const p=CUSTOM_PRESETS[Number(chip.dataset.presetIndex)];
    if(!p)return;
    $('customName').value=p.name;
    $('customCompany').value=p.company;
    $('customUrl').value=p.url;
    $('customType').value=p.type||'credits';
    $('customMark').value=p.mark;
    $('customColor').value=p.color;
  });
  $('saveCustomOnly')?.addEventListener('click',()=>{submitMode='save';});
  $('saveAndBindCustom')?.addEventListener('click',()=>{submitMode='bind';});

  $('customServiceForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const raw={
      id:$('customId').value.trim()||undefined,
      name:$('customName').value.trim(),
      company:$('customCompany').value.trim(),
      url:$('customUrl').value.trim(),
      type:$('customType').value,
      mark:$('customMark').value.trim(),
      color:$('customColor').value
    };
    const tempId=raw.id||'custom_'+Date.now().toString(36);
    const preview=cleanCustomProvider(raw,tempId);
    if(!preview){
      toast(t('toast.invalidCustom'),true);
      return;
    }
    if(!native){
      state.customProviders||={};
      state.customProviders[tempId]=preview;
      state.connections[tempId]={enabled:true,entryUrl:preview.url};
      localStorage.setItem('pulsePreviewCustom',JSON.stringify(state.customProviders));
      syncCustomProviders(state.customProviders);
      closeCustomModal();
      render();
      toast(t('toast.customAddedPreview',{name:preview.name}));
      return;
    }
    try{
      const proto=new URL(preview.origin).protocol;
      const origins=[...new Set([
        ...preview.origins.map(o=>o+'/*'),
        ...(preview.rootDomain.includes('.')?[`${proto}//${preview.rootDomain}/*`,`${proto}//*.${preview.rootDomain}/*`]:[])
      ])];
      const granted=await chrome.permissions.request({origins});
      if(!granted){
        toast(t('toast.customPermDenied'),true);
        return;
      }
      const res=await send('save-custom-provider',null,{provider:raw});
      closeCustomModal();
      await load();
      if(submitMode==='bind'){
        await send('bind',res.id);
        toast(t('toast.customSavedBind',{name:res.provider.name}));
      }else{
        toast(t('toast.customSavedOnly',{name:res.provider.name}));
      }
    }catch(err){
      toast(err.message,true);
    }
  });

  document.addEventListener('click',async event=>{
    const langBtn=event.target.closest('[data-lang-select]');
    if(langBtn){await selectLanguage(langBtn.dataset.langSelect);return;}
    const layoutAction=event.target.closest('[data-layout-action]');
    if(layoutAction&&editing&&!savingLayout){const {id,layoutAction:type}=layoutAction.dataset,ids=PulseLayout.visible(draft),index=ids.indexOf(id);if(type==='hide'){draft.hidden=[...new Set([...draft.hidden,id])];render();}else{const target=ids[index+(type==='previous'?-1:1)];if(target)moveCard(id,target);}return;}
    const nav=event.target.closest('[data-view]');if(nav){changeView(nav.dataset.view);return;}
    const segment=event.target.closest('[data-period]');if(segment){period=segment.dataset.period;document.querySelectorAll('[data-period]').forEach(e=>{const selected=e===segment;e.classList.toggle('selected',selected);e.setAttribute('aria-pressed',String(selected));});render();return;}
    const action=event.target.closest('[data-action]');if(!action)return;
    const {id,action:type}=action.dataset;
    try{
      if(type==='connect')await connect(id);
      if(type==='open')await send('open',id);
      if(type==='bind')await bindService(id);
      if(type==='edit-custom')openCustomModal(id);
      if(type==='delete-custom'){
        const name=PROVIDERS[id]?.name||id;
        if(!confirm(t('toast.confirmDeleteCustom',{name})))return;
        if(!native){
          delete state.customProviders[id];
          delete state.connections[id];
          localStorage.setItem('pulsePreviewCustom',JSON.stringify(state.customProviders));
          syncCustomProviders(state.customProviders);
          render();
          toast(t('toast.deletedCustom',{name}));
          return;
        }
        await send('delete-custom-provider',id);
        await load();
        toast(t('toast.deletedCustom',{name}));
      }
      if(type==='disconnect'){await send('disconnect',id);await load();toast(t('toast.disconnected',{name:PROVIDERS[id].name}));}
      if(type==='refresh')await refresh([id]);
      if(type==='scan')await refresh([id],'scan');
    }catch(e){toast(e.message,true);}
  });
  $('editLayout').addEventListener('click',()=>{editing=true;draft=PulseLayout.clean(state.layout);render();});
  $('saveLayout').addEventListener('click',finishEditing);
  $('cancelLayout').addEventListener('click',()=>{editing=false;draft=null;render();});
  $('resetLayout').addEventListener('click',()=>{draft=PulseLayout.defaults();render();});
  $('serviceToggles').addEventListener('change',event=>{const id=event.target.dataset.showService;if(!editing||savingLayout||!Object.hasOwn(PROVIDERS,id))return;draft.hidden=event.target.checked?draft.hidden.filter(item=>item!==id):[...new Set([...draft.hidden,id])];render();});
  $('cards').addEventListener('dragstart',event=>{const handle=event.target.closest('[data-drag-id]');if(!editing||savingLayout||!handle){event.preventDefault();return;}dragged=handle.dataset.dragId;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',dragged);handle.closest('.service-card').classList.add('dragging');});
  $('cards').addEventListener('dragover',event=>{if(!dragged)return;const target=event.target.closest('[data-service]');if(!target)return;event.preventDefault();event.dataTransfer.dropEffect='move';$('cards').querySelectorAll('.drop-target').forEach(e=>e.classList.remove('drop-target'));target.classList.add('drop-target');});
  $('cards').addEventListener('drop',event=>{if(!dragged)return;event.preventDefault();const id=dragged,target=event.target.closest('[data-service]')?.dataset.service;dragged=null;if(target)moveCard(id,target);else render();});
  $('cards').addEventListener('dragend',()=>{dragged=null;render();});
  $('refreshAll').addEventListener('click',async()=>{const ids=PulseLayout.visible(state.layout).filter(id=>state.connections[id]?.enabled);if(!ids.length&&Object.values(state.connections).some(c=>c.enabled)){toast(t('toast.refreshHidden'));return;}if(!native){refresh(ids);return;}if(!ids.length){changeView('connections');toast(t('toast.refreshNone'));return;}try{const result=await send('refresh-all');PulseRefreshWarning.notify(result.count);await load();}catch(e){toast(e.message,true);}});
  function exportHistory(){
    const data={application:'AI Pulse',version:'1.8.0',exportedAt:new Date().toISOString(),history:state.history};
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='ai-pulse-'+new Date().toISOString().slice(0,10)+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  async function clearAllData(){
    if(!native){toast(t('toast.clearPreview'));return;}
    if(!confirm(t('toast.confirmClear')))return;
    try{await send('clear');await load();toast(t('toast.cleared'));}catch(e){toast(e.message,true);}
  }
  $('exportData').addEventListener('click',exportHistory);
  $('settingsExportData')?.addEventListener('click',exportHistory);
  $('clearData').addEventListener('click',clearAllData);
  $('settingsClearData')?.addEventListener('click',clearAllData);
  $('previewNotice').hidden=native;
  if(native){chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.pulse){state=changes.pulse.newValue||{connections:{},snapshots:{},history:[],customProviders:{}};if(state.language)PulseI18n.setLang(state.language);syncCustomProviders(state.customProviders);render();}});}
  load().catch(e=>{render();toast(t('toast.loadError',{error:e.message}),true);});
  setInterval(()=>{if(!editing)render();},5000);
})();
