/* Read only visible quota rows, never conversation text or app-limit controls. */
globalThis.PulseGPTCollector=(()=>{
  const visible=e=>!!e&&!e.closest('[hidden],[aria-hidden="true"],article,[data-message-author-role]')&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
  const text=e=>String(e?.innerText||e?.textContent||'').trim();
  const usage=/^(?:usage(?:\s+limits)?|plan\s+usage\s+limits|사용량(?:\s*(?:한도|제한))?|이용\s*한도|利用状況|使用量)$/i;
  const period=/current\s*session|session|weekly|week|daily|5[\s-]*(?:h(?:our)?s?|시간)|세션|주간|이번\s*주|일일|週間/i;
  const direction=/\bused\b|consumed|remaining|\bleft\b|남[은음아]|잔여|사용[됨했한]|소진|사용\s*가능/i;
  const percentage=/[+-]?\d+(?:[.,]\d+)?\s*[%％]/g;
  const heading='h1,h2,h3,h4,[role="heading"]';
  function scopes(){
    const roots=[...document.querySelectorAll('[role="dialog"],dialog')].filter(visible);
    const panels=[...document.querySelectorAll('[role="tabpanel"]')].filter(visible);
    const selected=[...document.querySelectorAll('[role="tab"][aria-selected="true"]')].filter(visible).filter(e=>usage.test(text(e))||usage.test(e.getAttribute('aria-label')||''));
    for(const tab of selected){const panel=document.getElementById(tab.getAttribute('aria-controls'));if(visible(panel))return [panel];}
    const named=panels.filter(e=>usage.test(e.getAttribute('aria-label')||'')||usage.test(text(document.getElementById(e.getAttribute('aria-labelledby'))))||[...e.querySelectorAll(heading)].some(h=>visible(h)&&usage.test(text(h))));
    if(named.length)return named;
    const dialogs=roots.filter(e=>usage.test(e.getAttribute('aria-label')||'')||[...e.querySelectorAll(heading)].some(h=>visible(h)&&usage.test(text(h)))||selected.some(t=>e.contains(t)));
    if(dialogs.length)return dialogs;
    // A route alone is insufficient: a redirected conversation can contain numbers.
    if(!/^\/settings\/usage\/?$/i.test(location.pathname)&&!/^#settings[\/=]usage$/i.test(location.hash))return [];
    const main=document.querySelector('main')||document.body;
    return [...main.querySelectorAll(heading)].some(h=>visible(h)&&usage.test(text(h)))?[main]:[];
  }
  function collect(){
    const areas=scopes(),blocks=[];
    for(const area of areas){
      // Some layouts put labels and values in sibling nodes without row wrappers.
      const lines=(area.querySelector('article,[data-message-author-role]')?'':text(area)).split('\n').map(s=>s.trim()).filter(Boolean);
      let label='',near=[],appLimits=false;
      for(let i=0;i<lines.length;i++){
        const line=lines[i],values=line.match(percentage)||[];
        if(/app\s*limits|앱별\s*한도|앱\s*한도/i.test(line)){appLimits=true;label='';}
        if(appLimits)continue;
        if(period.test(line)&&!values.length&&!/reset|refresh|초기화|재설정|갱신/i.test(line)){label=line;near=[];}
        if(!values.length){near.push(line);near=near.slice(-2);continue;}
        if(values.length!==1||!label)continue;
        const after=lines[i+1]||'';
        const valueText=[...near,line,...(!period.test(after)&&!(after.match(percentage)||[]).length?[after]:[])].join(' ');
        if(direction.test(valueText))blocks.push({label,valueText,context:'Usage',reset:lines.slice(i+1,i+4).find(s=>/reset|refresh|초기화|재설정|갱신/i.test(s))||''});
        label='';near=[];
      }
      const candidates=[...area.querySelectorAll('span,p,div,li,[role="progressbar"],meter,progress')].filter(visible);
      for(const el of candidates){
        if(el.closest('button,a,[role="combobox"],[role="menu"],[role="listbox"],select'))continue;
        // App allocation sections can also use plain text or progress bars.
        // A separate enclosing heading must not turn their percentages into usage.
        const appHeading=[...area.querySelectorAll(heading)].filter(visible).find(h=>/^(?:app\s*limits|앱별\s*한도|앱\s*한도)$/i.test(text(h))&&(h.compareDocumentPosition(el)&Node.DOCUMENT_POSITION_FOLLOWING));
        if(appHeading)continue;
        const isBar=el.matches('[role="progressbar"],meter,progress');
        if(!isBar&&(!(text(el).match(percentage)||[]).length||[...el.children].some(c=>visible(c)&&(text(c).match(percentage)||[]).length)))continue;
        let row=el,found=null;
        for(let depth=0;row&&area.contains(row)&&depth<6;depth++,row=row.parentElement){
          const value=text(row),values=value.match(percentage)||[];
          if(value.length>700||values.length>1)break;
          if(/app\s*limits|앱별\s*한도|앱\s*한도|set.*limit|한도\s*설정/i.test(value))break;
          const aria=el.getAttribute('aria-valuetext')||'',label=el.getAttribute('aria-label')||'';
          const context=[value,label,aria].join(' ');
          if(period.test(context)&&direction.test(context)){
            const lines=value.split('\n').map(s=>s.trim()).filter(Boolean);
            const title=lines.filter(s=>period.test(s)&&!(s.match(percentage)||[]).length&&!/reset|초기화|재설정/i.test(s)).slice(0,2).join(' · ')||label||(period.test(lines[0]||'')&&!/reset|초기화|재설정/i.test(lines[0])?lines[0].replace(percentage,'').replace(/\b(?:used|remaining|left|consumed)\b|사용됨|남음/gi,'').trim():'');
            if(!title)continue;
            const raw=isBar?(el.getAttribute('aria-valuenow')??el.getAttribute('value')):null;
            const max=isBar?(el.getAttribute('aria-valuemax')??el.getAttribute('max')??(el.matches('meter,progress')?String(el.max):'100')):null;
            const min=isBar?Number(el.getAttribute('aria-valuemin')??el.getAttribute('min')??'0'):0;
            found={label:title,valueText:aria||[value,label].join(' '),value:raw===null||raw.trim()===''?null:Number(raw)-min,max:max===null?null:Number(max)-min,context:'Usage',reset:lines.find(s=>/reset|refresh|재설정|초기화|갱신/i.test(s))||''};
            break;
          }
        }
        if(found)blocks.push(found);
      }
    }
    return {metrics:UsageParser.parseBlocks(blocks),viewFound:areas.length>0,checkedAt:new Date().toISOString()};
  }
  return {collect};
})();
