/* Only official balance response bodies, never credentials or other traffic. */
globalThis.PulseComfyBalance=(()=>{
 function endpoint(url){try{const u=new URL(url);if(u.origin==='https://cloud.comfy.org'&&u.pathname==='/api/billing/balance')return 'workspace';if(u.origin==='https://api.comfy.org'&&u.pathname==='/customers/balance')return 'personal';}catch{}return null;}
 function parse(url,body){
  const scope=endpoint(url);if(!scope||typeof body!=='string'||body.length>16000)return null;
  let data;try{data=JSON.parse(body);}catch{return null;}
  if(!data||Array.isArray(data)||typeof data.amount_micros!=='number'||!Number.isFinite(data.amount_micros))return null;
  const cents=data.effective_balance_micros??data.amount_micros;if(typeof cents!=='number'||!Number.isFinite(cents)||Math.abs(cents)>1e11)return null;
  // Official BalanceInfo: *_micros is cents, not millionths of a dollar.
  // Official creditsUtil: round(cents * 211 / 100).
  return {kind:'balance',label:scope==='workspace'?'Comfy 워크스페이스 잔여 크레딧':'Comfy 개인 계정 잔여 크레딧',amount:Math.round(cents*211/100),unit:'credits',period:'balance',balanceType:'total',approximate:false,reset:''};
 }
 return {endpoint,parse};
})();