using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Automation;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("AI Pulse Automated Installer & Configurator")]
[assembly: AssemblyDescription("AI Pulse v1.8.0 Automated Browser Extension Installer (Edge / Chrome)")]
[assembly: AssemblyCompany("AI Pulse")]
[assembly: AssemblyProduct("AI Pulse Setup")]
[assembly: AssemblyVersion("1.8.0.0")]
[assembly: AssemblyFileVersion("1.8.0.0")]

namespace AIPulseInstaller
{
    internal static class NativeMethods
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool EnumChildWindows(IntPtr hWndParent, EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll")]
        public static extern int GetDlgCtrlID(IntPtr hwndCtl);

        [DllImport("user32.dll")]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);

        [DllImport("user32.dll")]
        public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);

        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        public const uint WM_COMMAND = 0x0111;
        public const uint WM_CLOSE = 0x0010;
        public const uint WM_SETTEXT = 0x000C;
        public const uint BM_CLICK = 0x00F5;
        public const int IDC_MANAGE_EXTENSIONS = 40022;
        public const uint SPI_GETSCREENREADER = 0x0046;
        public const uint SPI_SETSCREENREADER = 0x0047;
        public const int SW_RESTORE = 9;
        public const int SW_SHOW = 5;
    }

    public enum BrowserKind
    {
        Edge,
        Chrome
    }

    public sealed class InstallOptions
    {
        public BrowserKind Browser = BrowserKind.Chrome;
        public string Language = "ko";
        public string ExtensionFolder = "";
        public string CustomUserDataDir = "";
        public bool CloseBrowserAfter = false;
        public bool Silent = false;
    }

    public sealed class InstallResult
    {
        public bool Success;
        public string Message = "";
        public string ExtensionPath = "";
        public string BrowserName = "";
        public List<string> Logs = new List<string>();
    }

    public static class BrowserInstallerEngine
    {
        public static bool IsAdministrator()
        {
            try
            {
                using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
                {
                    WindowsPrincipal principal = new WindowsPrincipal(identity);
                    return principal.IsInRole(WindowsBuiltInRole.Administrator);
                }
            }
            catch
            {
                return false;
            }
        }

        public static string FindBrowserExe(BrowserKind kind)
        {
            string exeName = kind == BrowserKind.Edge ? "msedge.exe" : "chrome.exe";
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + exeName))
                {
                    if (key != null)
                    {
                        string val = key.GetValue(null) as string;
                        if (!string.IsNullOrEmpty(val) && File.Exists(val)) return val;
                    }
                }
            }
            catch { }

            string[] candidates = kind == BrowserKind.Edge
                ? new[]
                {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft\Edge\Application\msedge.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft\Edge\Application\msedge.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\Edge\Application\msedge.exe")
                }
                : new[]
                {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Google\Chrome\Application\chrome.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Google\Chrome\Application\chrome.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Google\Chrome\Application\chrome.exe")
                };

            foreach (string c in candidates)
            {
                if (File.Exists(c)) return c;
            }
            return null;
        }

        public static string ResolveExtensionFolder(string explicitFolder = null)
        {
            if (!string.IsNullOrEmpty(explicitFolder))
            {
                string full = Path.GetFullPath(explicitFolder);
                if (File.Exists(Path.Combine(full, "manifest.json"))) return full;
                if (File.Exists(Path.Combine(full, "AI-Pulse", "manifest.json"))) return Path.Combine(full, "AI-Pulse");
            }

            string exeDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\', '/');
            DirectoryInfo parentInfo = Directory.GetParent(exeDir);
            string parentDir = parentInfo != null ? parentInfo.FullName : exeDir;
            string[] searchDirs = new[]
            {
                Path.Combine(exeDir, "AI-Pulse"),
                exeDir,
                Path.Combine(parentDir, "AI-Pulse"),
                parentDir,
                Path.Combine(Environment.CurrentDirectory, "AI-Pulse"),
                Environment.CurrentDirectory
            };

            foreach (string candidate in searchDirs)
            {
                if (!string.IsNullOrEmpty(candidate) && File.Exists(Path.Combine(candidate, "manifest.json")))
                {
                    return Path.GetFullPath(candidate);
                }
            }
            return Path.Combine(exeDir, "AI-Pulse");
        }

        public static void ApplyExtensionLanguagePreference(string extFolder, string lang)
        {
            string normalized = (lang ?? "ko").ToLowerInvariant().StartsWith("en") ? "en" : "ko";
            string i18nPath = Path.Combine(extFolder, "i18n.js");
            if (File.Exists(i18nPath))
            {
                try
                {
                    string content = File.ReadAllText(i18nPath, Encoding.UTF8);
                    string updated = Regex.Replace(
                        content,
                        @"let\s+currentLang\s*=\s*'(?:ko|en)'\s*;",
                        "let currentLang = '" + normalized + "';");
                    if (updated != content)
                    {
                        File.WriteAllText(i18nPath, updated, new UTF8Encoding(false));
                    }
                }
                catch { }
            }

            string indexPath = Path.Combine(extFolder, "index.html");
            if (File.Exists(indexPath))
            {
                try
                {
                    string content = File.ReadAllText(indexPath, Encoding.UTF8);
                    string updated = Regex.Replace(
                        content,
                        @"<html\s+lang=""(?:ko|en)"">",
                        "<html lang=\"" + normalized + "\">");
                    if (updated != content)
                    {
                        File.WriteAllText(indexPath, updated, new UTF8Encoding(false));
                    }
                }
                catch { }
            }
        }

        private static void PreconfigureProfilePreferences(BrowserKind kind, string extFolder, string customUserDataDir, Action<string> log)
        {
            try
            {
                string userDataDir = !string.IsNullOrEmpty(customUserDataDir)
                    ? customUserDataDir
                    : Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        kind == BrowserKind.Edge ? @"Microsoft\Edge\User Data" : @"Google\Chrome\User Data");

                if (!Directory.Exists(userDataDir))
                {
                    Directory.CreateDirectory(Path.Combine(userDataDir, "Default"));
                }

                List<string> profileDirs = new List<string>();
                string defaultProfile = Path.Combine(userDataDir, "Default");
                if (Directory.Exists(defaultProfile)) profileDirs.Add(defaultProfile);
                foreach (string sub in Directory.GetDirectories(userDataDir, "Profile *"))
                {
                    profileDirs.Add(sub);
                }

                string escapedPath = extFolder.Replace("\\", "\\\\");
                foreach (string pDir in profileDirs)
                {
                    string prefFile = Path.Combine(pDir, "Preferences");
                    try
                    {
                        if (!File.Exists(prefFile))
                        {
                            string minimalJson = "{\"extensions\":{\"ui\":{\"developer_mode\":true}},\"selectfile\":{\"last_directory\":\"" + escapedPath + "\"}}";
                            File.WriteAllText(prefFile, minimalJson, new UTF8Encoding(false));
                            log("Pre-configured Preferences in " + Path.GetFileName(pDir));
                        }
                        else
                        {
                            string raw = File.ReadAllText(prefFile, Encoding.UTF8);
                            bool changed = false;
                            if (raw.Contains("\"last_directory\""))
                            {
                                string next = Regex.Replace(raw, @"""last_directory""\s*:\s*""[^""]*""", "\"last_directory\":\"" + escapedPath + "\"");
                                if (next != raw) { raw = next; changed = true; }
                            }
                            else if (raw.TrimEnd().EndsWith("}"))
                            {
                                raw = raw.TrimEnd();
                                raw = raw.Substring(0, raw.Length - 1) + ",\"selectfile\":{\"last_directory\":\"" + escapedPath + "\"}}";
                                changed = true;
                            }
                            if (changed)
                            {
                                File.WriteAllText(prefFile, raw, new UTF8Encoding(false));
                                log("Updated selectfile.last_directory in " + Path.GetFileName(pDir));
                            }
                        }
                    }
                    catch
                    {
                        // Browser may be running and locking Preferences; UI automation handles live state.
                    }
                }
            }
            catch (Exception ex)
            {
                log("Preferences pre-config note: " + ex.Message);
            }
        }

        private static List<IntPtr> GetBrowserTopWindows(BrowserKind kind)
        {
            string targetProcName = kind == BrowserKind.Edge ? "msedge" : "chrome";
            List<IntPtr> list = new List<IntPtr>();

            NativeMethods.EnumWindows((hWnd, lParam) =>
            {
                if (!NativeMethods.IsWindowVisible(hWnd)) return true;
                StringBuilder cls = new StringBuilder(128);
                NativeMethods.GetClassName(hWnd, cls, 128);
                if (cls.ToString() != "Chrome_WidgetWin_1") return true;

                StringBuilder title = new StringBuilder(256);
                NativeMethods.GetWindowText(hWnd, title, 256);
                if (title.Length == 0) return true;

                NativeMethods.RECT rect;
                if (NativeMethods.GetWindowRect(hWnd, out rect))
                {
                    if (!NativeMethods.IsIconic(hWnd) && ((rect.Right - rect.Left) < 250 || (rect.Bottom - rect.Top) < 180))
                    {
                        return true;
                    }
                }

                uint pid;
                NativeMethods.GetWindowThreadProcessId(hWnd, out pid);
                if (pid == 0) return true;
                try
                {
                    Process p = Process.GetProcessById((int)pid);
                    if (string.Equals(p.ProcessName, targetProcName, StringComparison.OrdinalIgnoreCase))
                    {
                        list.Add(hWnd);
                    }
                }
                catch { }
                return true;
            }, IntPtr.Zero);

            return list;
        }

        private static void WakeBrowserAccessibility(IntPtr browserHwnd)
        {
            try
            {
                NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENREADER, 1u, IntPtr.Zero, 0);
                NativeMethods.EnumChildWindows(browserHwnd, (childHwnd, l) =>
                {
                    StringBuilder sb = new StringBuilder(128);
                    NativeMethods.GetClassName(childHwnd, sb, 128);
                    if (sb.ToString().Contains("Chrome_RenderWidgetHostHWND"))
                    {
                        try
                        {
                            AutomationElement el = AutomationElement.FromHandle(childHwnd);
                            if (el != null)
                            {
                                string _ = el.Current.Name;
                                el.FindFirst(TreeScope.Children, System.Windows.Automation.Condition.TrueCondition);
                            }
                        }
                        catch { }
                    }
                    return true;
                }, IntPtr.Zero);
            }
            catch { }
        }

        private static AutomationElement FindDevModeToggle(AutomationElement winEl, BrowserKind kind)
        {
            string[] ids = kind == BrowserKind.Edge
                ? new[] { "dev-switch", "devMode" }
                : new[] { "devMode", "dev-switch" };

            foreach (string id in ids)
            {
                try
                {
                    AutomationElement found = winEl.FindFirst(
                        TreeScope.Descendants,
                        new PropertyCondition(AutomationElement.AutomationIdProperty, id));
                    if (found != null) return found;
                }
                catch { }
            }

            try
            {
                AutomationElementCollection buttons = winEl.FindAll(
                    TreeScope.Descendants,
                    new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button));
                foreach (AutomationElement b in buttons)
                {
                    string n = b.Current.Name ?? "";
                    if (Regex.IsMatch(n, @"개발자\s*모드|Developer\s*mode", RegexOptions.IgnoreCase))
                    {
                        return b;
                    }
                }
            }
            catch { }
            return null;
        }

        private static AutomationElement FindLoadUnpackedButton(AutomationElement winEl)
        {
            string[] ids = new[] { "loadUnpacked", "load-unpacked" };
            foreach (string id in ids)
            {
                try
                {
                    AutomationElement found = winEl.FindFirst(
                        TreeScope.Descendants,
                        new PropertyCondition(AutomationElement.AutomationIdProperty, id));
                    if (found != null) return found;
                }
                catch { }
            }

            try
            {
                AutomationElementCollection buttons = winEl.FindAll(
                    TreeScope.Descendants,
                    new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button));
                foreach (AutomationElement b in buttons)
                {
                    string n = b.Current.Name ?? "";
                    if (Regex.IsMatch(n, @"압축\s*해제된\s*확장|압축\s*풀린\s*파일\s*로드|Load\s*unpacked", RegexOptions.IgnoreCase))
                    {
                        return b;
                    }
                }
            }
            catch { }
            return null;
        }

        private static AutomationElement FindUpdateExtensionsButton(AutomationElement winEl)
        {
            try
            {
                AutomationElement byId = winEl.FindFirst(
                    TreeScope.Descendants,
                    new PropertyCondition(AutomationElement.AutomationIdProperty, "updateNow"));
                if (byId != null) return byId;

                AutomationElementCollection buttons = winEl.FindAll(
                    TreeScope.Descendants,
                    new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button));
                foreach (AutomationElement b in buttons)
                {
                    string n = b.Current.Name ?? "";
                    if (Regex.IsMatch(n, @"^(?:업데이트|Update)$", RegexOptions.IgnoreCase))
                    {
                        return b;
                    }
                }
            }
            catch { }
            return null;
        }

        private static IntPtr FindFolderPickerDialog(IntPtr ownerBrowserHwnd)
        {
            IntPtr foundDlg = IntPtr.Zero;
            NativeMethods.EnumWindows((hWnd, lParam) =>
            {
                if (!NativeMethods.IsWindowVisible(hWnd)) return true;
                StringBuilder cls = new StringBuilder(128);
                NativeMethods.GetClassName(hWnd, cls, 128);
                if (cls.ToString() != "#32770") return true;

                StringBuilder title = new StringBuilder(256);
                NativeMethods.GetWindowText(hWnd, title, 256);
                string t = title.ToString();

                bool hasEdit1152 = false;
                bool hasButton1 = false;
                NativeMethods.EnumChildWindows(hWnd, (child, l) =>
                {
                    StringBuilder ccls = new StringBuilder(128);
                    NativeMethods.GetClassName(child, ccls, 128);
                    int id = NativeMethods.GetDlgCtrlID(child);
                    if (ccls.ToString() == "Edit" && id == 1152) hasEdit1152 = true;
                    if (ccls.ToString() == "Button" && id == 1) hasButton1 = true;
                    return true;
                }, IntPtr.Zero);

                if (hasEdit1152 && hasButton1 &&
                    (Regex.IsMatch(t, @"확장|디렉터리|폴더|Select|Extension|Directory|Folder|열기|Open", RegexOptions.IgnoreCase) || t.Length > 0))
                {
                    foundDlg = hWnd;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            return foundDlg;
        }

        private static bool CompleteFolderPickerDialog(IntPtr dlgHwnd, string targetFolderPath, Action<string> log)
        {
            IntPtr editHwnd = IntPtr.Zero;
            IntPtr okBtnHwnd = IntPtr.Zero;
            string currentAddress = "";

            NativeMethods.EnumChildWindows(dlgHwnd, (h, l) =>
            {
                StringBuilder sb = new StringBuilder(128);
                NativeMethods.GetClassName(h, sb, 128);
                StringBuilder tb = new StringBuilder(512);
                NativeMethods.GetWindowText(h, tb, 512);
                int id = NativeMethods.GetDlgCtrlID(h);
                string cls = sb.ToString();
                if (cls == "Edit" && id == 1152) editHwnd = h;
                if (cls == "Button" && id == 1) okBtnHwnd = h;
                if (cls == "ToolbarWindow32" && id == 1001) currentAddress = tb.ToString();
                return true;
            }, IntPtr.Zero);

            if (editHwnd == IntPtr.Zero || okBtnHwnd == IntPtr.Zero)
            {
                log("Dialog controls (Edit 1152 / Button 1) not ready yet.");
                return false;
            }

            log("Folder Picker Address Bar: [" + currentAddress + "]");
            bool inTarget = currentAddress.EndsWith(targetFolderPath, StringComparison.OrdinalIgnoreCase);

            if (!inTarget)
            {
                log("Automatically setting AI-Pulse folder path: " + targetFolderPath);
                bool setViaUia = false;
                try
                {
                    AutomationElement editEl = AutomationElement.FromHandle(editHwnd);
                    object vpObj;
                    if (editEl != null && editEl.TryGetCurrentPattern(ValuePattern.Pattern, out vpObj))
                    {
                        ((ValuePattern)vpObj).SetValue(targetFolderPath);
                        setViaUia = true;
                    }
                }
                catch { }

                if (!setViaUia)
                {
                    NativeMethods.SendMessage(editHwnd, NativeMethods.WM_SETTEXT, IntPtr.Zero, targetFolderPath);
                }

                Thread.Sleep(250);
                NativeMethods.PostMessage(dlgHwnd, NativeMethods.WM_COMMAND, (IntPtr)1, IntPtr.Zero);
                Thread.Sleep(850);
            }

            for (int attempt = 0; attempt < 3 && NativeMethods.IsWindowVisible(dlgHwnd); attempt++)
            {
                try
                {
                    AutomationElement editEl = AutomationElement.FromHandle(editHwnd);
                    object vpObj;
                    if (editEl != null && editEl.TryGetCurrentPattern(ValuePattern.Pattern, out vpObj))
                    {
                        ((ValuePattern)vpObj).SetValue("");
                    }
                    else
                    {
                        NativeMethods.SendMessage(editHwnd, NativeMethods.WM_SETTEXT, IntPtr.Zero, "");
                    }
                }
                catch
                {
                    NativeMethods.SendMessage(editHwnd, NativeMethods.WM_SETTEXT, IntPtr.Zero, "");
                }

                Thread.Sleep(180);
                log("Confirming folder selection (Select Folder / 폴더 선택)...");
                NativeMethods.PostMessage(dlgHwnd, NativeMethods.WM_COMMAND, (IntPtr)1, IntPtr.Zero);
                Thread.Sleep(750);
            }

            return !NativeMethods.IsWindowVisible(dlgHwnd);
        }

        private static bool VerifyAIPulsePresent(AutomationElement winEl)
        {
            try
            {
                AutomationElementCollection all = winEl.FindAll(
                    TreeScope.Descendants,
                    System.Windows.Automation.Condition.TrueCondition);
                foreach (AutomationElement el in all)
                {
                    string n = el.Current.Name ?? "";
                    if (n.IndexOf("AI Pulse", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        return true;
                    }
                }
            }
            catch { }
            return false;
        }

        public static InstallResult RunInstallation(InstallOptions options, Action<string> onProgress = null)
        {
            InstallResult result = new InstallResult();
            Action<string> log = msg =>
            {
                string line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg;
                result.Logs.Add(line);
                if (onProgress != null) onProgress(msg);
            };

            string browserTitle = options.Browser == BrowserKind.Edge ? "Microsoft Edge" : "Google Chrome";
            result.BrowserName = browserTitle;
            bool isEn = (options.Language ?? "ko").ToLowerInvariant().StartsWith("en");

            try
            {
                string extFolder = ResolveExtensionFolder(options.ExtensionFolder);
                result.ExtensionPath = extFolder;
                if (!File.Exists(Path.Combine(extFolder, "manifest.json")))
                {
                    result.Success = false;
                    result.Message = isEn
                        ? "Could not find manifest.json inside AI-Pulse folder: " + extFolder
                        : "AI-Pulse 폴더에서 manifest.json 파일을 찾을 수 없습니다: " + extFolder;
                    return result;
                }

                log(isEn ? "Located AI-Pulse folder: " + extFolder : "AI-Pulse 폴더 자동 지정 완료: " + extFolder);

                ApplyExtensionLanguagePreference(extFolder, options.Language);
                log(isEn
                    ? "Configured default language: " + (isEn ? "English (en)" : "Korean (ko)")
                    : "기본 언어 설정 반영 완료: " + (isEn ? "English (영어)" : "한국어 (Korean)"));

                string browserExe = FindBrowserExe(options.Browser);
                if (string.IsNullOrEmpty(browserExe) || !File.Exists(browserExe))
                {
                    result.Success = false;
                    result.Message = isEn
                        ? browserTitle + " is not installed on this PC."
                        : "이 PC에서 " + browserTitle + " 설치 경로를 찾을 수 없습니다.";
                    return result;
                }
                log((isEn ? "Found browser executable: " : "브라우저 실행 파일 확인: ") + browserExe);

                PreconfigureProfilePreferences(options.Browser, extFolder, options.CustomUserDataDir, log);

                List<IntPtr> beforeWindows = GetBrowserTopWindows(options.Browser);

                IntPtr targetHwnd = IntPtr.Zero;
                Process launchedProcess = null;

                if (beforeWindows.Count > 0 && string.IsNullOrEmpty(options.CustomUserDataDir))
                {
                    targetHwnd = beforeWindows[0];
                    log(isEn
                        ? "Detected running " + browserTitle + " window. Connecting..."
                        : "실행 중인 " + browserTitle + " 창을 감지했습니다. 확장 프로그램 관리 화면을 엽니다...");
                    if (NativeMethods.IsIconic(targetHwnd))
                    {
                        NativeMethods.ShowWindow(targetHwnd, NativeMethods.SW_RESTORE);
                    }
                    NativeMethods.SetForegroundWindow(targetHwnd);
                }
                else
                {
                    log(isEn
                        ? "Launching " + browserTitle + " for automatic extension registration..."
                        : browserTitle + " 실행 및 확장 프로그램 자동 등록 준비 중...");

                    List<string> args = new List<string>();
                    if (!string.IsNullOrEmpty(options.CustomUserDataDir))
                    {
                        args.Add("--user-data-dir=\"" + options.CustomUserDataDir + "\"");
                    }
                    args.Add("--force-renderer-accessibility");
                    args.Add("--no-first-run");
                    args.Add("--no-default-browser-check");
                    if (options.Browser == BrowserKind.Edge)
                    {
                        args.Add("--load-extension=\"" + extFolder + "\"");
                    }
                    args.Add("about:blank");

                    ProcessStartInfo psi = new ProcessStartInfo
                    {
                        FileName = browserExe,
                        Arguments = string.Join(" ", args),
                        WorkingDirectory = extFolder,
                        UseShellExecute = false
                    };
                    launchedProcess = Process.Start(psi);

                    for (int i = 0; i < 30; i++)
                    {
                        Thread.Sleep(350);
                        List<IntPtr> currentWindows = GetBrowserTopWindows(options.Browser);
                        if (!string.IsNullOrEmpty(options.CustomUserDataDir) && launchedProcess != null)
                        {
                            foreach (IntPtr h in currentWindows)
                            {
                                uint pid;
                                NativeMethods.GetWindowThreadProcessId(h, out pid);
                                if (pid == (uint)launchedProcess.Id || !beforeWindows.Contains(h))
                                {
                                    targetHwnd = h;
                                    break;
                                }
                            }
                        }
                        else if (currentWindows.Count > 0)
                        {
                            targetHwnd = currentWindows[0];
                        }
                        if (targetHwnd != IntPtr.Zero) break;
                    }
                }

                if (targetHwnd == IntPtr.Zero)
                {
                    result.Success = false;
                    result.Message = isEn
                        ? "Failed to detect " + browserTitle + " browser window."
                        : browserTitle + " 브라우저 창을 열지 못했습니다.";
                    return result;
                }

                try
                {
                    NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENREADER, 1u, IntPtr.Zero, 0);

                    log(isEn
                        ? "Opening Extensions Manager (" + (options.Browser == BrowserKind.Edge ? "edge://extensions" : "chrome://extensions") + ")..."
                        : "확장 프로그램 관리 페이지(" + (options.Browser == BrowserKind.Edge ? "edge://extensions" : "chrome://extensions") + ")로 자동 이동 중...");

                    NativeMethods.PostMessage(targetHwnd, NativeMethods.WM_COMMAND, (IntPtr)NativeMethods.IDC_MANAGE_EXTENSIONS, IntPtr.Zero);
                    Thread.Sleep(1600);
                    WakeBrowserAccessibility(targetHwnd);

                    AutomationElement winEl = AutomationElement.FromHandle(targetHwnd);
                    AutomationElement devToggle = null;
                    for (int attempt = 0; attempt < 16; attempt++)
                    {
                        WakeBrowserAccessibility(targetHwnd);
                        devToggle = FindDevModeToggle(winEl, options.Browser);
                        if (devToggle != null) break;
                        Thread.Sleep(450);
                    }

                    if (devToggle != null)
                    {
                        log(isEn ? "Checking Developer Mode state..." : "개발자 모드 활성화 상태 확인 중...");
                        object tpObj;
                        if (devToggle.TryGetCurrentPattern(TogglePattern.Pattern, out tpObj))
                        {
                            TogglePattern tp = (TogglePattern)tpObj;
                            if (tp.Current.ToggleState != ToggleState.On)
                            {
                                log(isEn ? "Enabling Developer Mode..." : "개발자 모드를 자동으로 켭니다...");
                                tp.Toggle();
                                Thread.Sleep(700);
                            }
                        }
                        else
                        {
                            AutomationElement existingLoadBtn = FindLoadUnpackedButton(winEl);
                            if (existingLoadBtn == null)
                            {
                                object ipObj;
                                if (devToggle.TryGetCurrentPattern(InvokePattern.Pattern, out ipObj))
                                {
                                    ((InvokePattern)ipObj).Invoke();
                                    Thread.Sleep(700);
                                }
                            }
                        }
                    }

                    AutomationElement loadBtn = null;
                    for (int attempt = 0; attempt < 12; attempt++)
                    {
                        WakeBrowserAccessibility(targetHwnd);
                        loadBtn = FindLoadUnpackedButton(winEl);
                        if (loadBtn != null) break;
                        Thread.Sleep(400);
                    }

                    if (loadBtn != null)
                    {
                        log(isEn
                            ? "Clicking 'Load unpacked' and selecting AI-Pulse folder automatically..."
                            : "‘압축해제된 확장 프로그램 로드’ 실행 및 AI-Pulse 폴더 자동 선택 중...");
                        object ipObj;
                        if (loadBtn.TryGetCurrentPattern(InvokePattern.Pattern, out ipObj))
                        {
                            ((InvokePattern)ipObj).Invoke();
                        }

                        IntPtr dlgHwnd = IntPtr.Zero;
                        for (int waitDlg = 0; waitDlg < 24; waitDlg++)
                        {
                            Thread.Sleep(300);
                            dlgHwnd = FindFolderPickerDialog(targetHwnd);
                            if (dlgHwnd != IntPtr.Zero) break;
                        }

                        if (dlgHwnd != IntPtr.Zero)
                        {
                            Thread.Sleep(350);
                            CompleteFolderPickerDialog(dlgHwnd, extFolder, log);
                            Thread.Sleep(1200);
                        }
                    }

                    AutomationElement updateBtn = FindUpdateExtensionsButton(winEl);
                    if (updateBtn != null)
                    {
                        object uip;
                        if (updateBtn.TryGetCurrentPattern(InvokePattern.Pattern, out uip))
                        {
                            log(isEn ? "Refreshing loaded extensions..." : "확장 프로그램 최신 버전 새로고침 적용 중...");
                            ((InvokePattern)uip).Invoke();
                            Thread.Sleep(800);
                        }
                    }

                    bool verified = VerifyAIPulsePresent(winEl);
                    log(verified
                        ? (isEn ? "Verified AI Pulse v1.8.0 registered in " + browserTitle + "!" : browserTitle + "에 AI Pulse v1.8.0 등록이 확인되었습니다!")
                        : (isEn ? "Completed extension registration steps in " + browserTitle + "." : browserTitle + " 확장 프로그램 자동 등록 절차를 완료했습니다."));

                    if (options.CloseBrowserAfter)
                    {
                        NativeMethods.PostMessage(targetHwnd, NativeMethods.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                        if (launchedProcess != null)
                        {
                            launchedProcess.WaitForExit(5000);
                        }
                    }

                    result.Success = true;
                    result.Message = isEn
                        ? "AI Pulse v1.8.0 has been automatically registered in " + browserTitle + "!\nFolder: " + extFolder
                        : browserTitle + "에 AI Pulse v1.8.0 확장 프로그램 자동 등록 및 폴더 지정이 완료되었습니다!\n폴더 경로: " + extFolder;
                    return result;
                }
                finally
                {
                    NativeMethods.SystemParametersInfo(NativeMethods.SPI_SETSCREENREADER, 0u, IntPtr.Zero, 0);
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = (isEn ? "Installation error: " : "설치 중 오류가 발생했습니다: ") + ex.Message;
                log("Error: " + ex);
                return result;
            }
        }
    }

    public sealed class InstallerForm : Form
    {
        private string currentLang = "ko";
        private readonly string extFolder;
        private readonly string edgeExe;
        private readonly string chromeExe;

        private Label lblBadge;
        private Label lblTitle;
        private Label lblSubtitle;
        private Label lblFolderTitle;
        private TextBox txtFolderPath;
        private Label lblLangTitle;
        private Button btnLangKo;
        private Button btnLangEn;
        private Label lblBrowserPrompt;
        private Button btnEdge;
        private Button btnChrome;
        private Label lblStatus;
        private ProgressBar progressBar;
        private bool isBusy = false;

        private static readonly Color BgDark = Color.FromArgb(13, 15, 17);
        private static readonly Color CardBg = Color.FromArgb(24, 28, 33);
        private static readonly Color CardHover = Color.FromArgb(35, 42, 26);
        private static readonly Color BorderColor = Color.FromArgb(52, 60, 68);
        private static readonly Color AccentLime = Color.FromArgb(210, 255, 0);
        private static readonly Color TextMain = Color.FromArgb(242, 244, 247);
        private static readonly Color TextMuted = Color.FromArgb(156, 166, 178);

        public InstallerForm(string initialLang)
        {
            currentLang = (initialLang ?? "ko").ToLowerInvariant().StartsWith("en") ? "en" : "ko";
            extFolder = BrowserInstallerEngine.ResolveExtensionFolder();
            edgeExe = BrowserInstallerEngine.FindBrowserExe(BrowserKind.Edge);
            chromeExe = BrowserInstallerEngine.FindBrowserExe(BrowserKind.Chrome);

            InitializeComponents();
            UpdateTranslations();
        }

        private void InitializeComponents()
        {
            Text = "AI Pulse v1.8.0 — 자동 설치 및 설정 (Setup)";
            Size = new Size(620, 520);
            MinimumSize = new Size(600, 500);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            BackColor = BgDark;
            ForeColor = TextMain;
            Font = new Font("Malgun Gothic", 9.5f, FontStyle.Regular);

            try
            {
                Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            }
            catch { }

            lblBadge = new Label
            {
                Location = new Point(28, 22),
                Size = new Size(540, 20),
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = AccentLime
            };
            Controls.Add(lblBadge);

            lblTitle = new Label
            {
                Location = new Point(26, 44),
                Size = new Size(550, 34),
                Font = new Font("Malgun Gothic", 17f, FontStyle.Bold),
                ForeColor = TextMain
            };
            Controls.Add(lblTitle);

            lblSubtitle = new Label
            {
                Location = new Point(28, 82),
                Size = new Size(550, 38),
                Font = new Font("Malgun Gothic", 9.5f, FontStyle.Regular),
                ForeColor = TextMuted
            };
            Controls.Add(lblSubtitle);

            // Language selection row
            Panel langPanel = new Panel
            {
                Location = new Point(28, 126),
                Size = new Size(548, 50),
                BackColor = CardBg
            };
            langPanel.Paint += (s, e) =>
            {
                using (Pen p = new Pen(BorderColor))
                {
                    e.Graphics.DrawRectangle(p, 0, 0, langPanel.Width - 1, langPanel.Height - 1);
                }
            };

            lblLangTitle = new Label
            {
                Location = new Point(14, 15),
                Size = new Size(270, 22),
                Font = new Font("Malgun Gothic", 9.5f, FontStyle.Bold),
                ForeColor = TextMain
            };
            langPanel.Controls.Add(lblLangTitle);

            btnLangKo = CreateChipButton("한국어 (Korean)", new Point(310, 10), new Size(110, 30));
            btnLangKo.Click += (s, e) => SetLanguage("ko");
            langPanel.Controls.Add(btnLangKo);

            btnLangEn = CreateChipButton("English (영어)", new Point(426, 10), new Size(110, 30));
            btnLangEn.Click += (s, e) => SetLanguage("en");
            langPanel.Controls.Add(btnLangEn);

            Controls.Add(langPanel);

            // Auto-detected AI-Pulse folder panel
            Panel folderPanel = new Panel
            {
                Location = new Point(28, 186),
                Size = new Size(548, 66),
                BackColor = CardBg
            };
            folderPanel.Paint += (s, e) =>
            {
                using (Pen p = new Pen(BorderColor))
                {
                    e.Graphics.DrawRectangle(p, 0, 0, folderPanel.Width - 1, folderPanel.Height - 1);
                }
            };

            lblFolderTitle = new Label
            {
                Location = new Point(14, 9),
                Size = new Size(520, 18),
                Font = new Font("Malgun Gothic", 8.5f, FontStyle.Bold),
                ForeColor = AccentLime
            };
            folderPanel.Controls.Add(lblFolderTitle);

            txtFolderPath = new TextBox
            {
                Location = new Point(14, 32),
                Size = new Size(520, 24),
                ReadOnly = true,
                BackColor = Color.FromArgb(15, 18, 21),
                ForeColor = TextMain,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 9f),
                Text = extFolder
            };
            folderPanel.Controls.Add(txtFolderPath);
            Controls.Add(folderPanel);

            // Browser Choice Prompt
            lblBrowserPrompt = new Label
            {
                Location = new Point(28, 266),
                Size = new Size(548, 22),
                Font = new Font("Malgun Gothic", 10.5f, FontStyle.Bold),
                ForeColor = TextMain
            };
            Controls.Add(lblBrowserPrompt);

            // Two large browser choice buttons: [Microsoft Edge] and [Google Chrome]
            btnEdge = CreateBrowserButton(new Point(28, 294), new Size(266, 108));
            btnEdge.Click += async (s, e) => await StartInstallAsync(BrowserKind.Edge);
            Controls.Add(btnEdge);

            btnChrome = CreateBrowserButton(new Point(310, 294), new Size(266, 108));
            btnChrome.Click += async (s, e) => await StartInstallAsync(BrowserKind.Chrome);
            Controls.Add(btnChrome);

            progressBar = new ProgressBar
            {
                Location = new Point(28, 416),
                Size = new Size(548, 10),
                Style = ProgressBarStyle.Continuous,
                Visible = false
            };
            Controls.Add(progressBar);

            lblStatus = new Label
            {
                Location = new Point(28, 432),
                Size = new Size(548, 40),
                Font = new Font("Malgun Gothic", 9f, FontStyle.Regular),
                ForeColor = TextMuted
            };
            Controls.Add(lblStatus);
        }

        private Button CreateChipButton(string text, Point location, Size size)
        {
            Button b = new Button
            {
                Text = text,
                Location = location,
                Size = size,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                Font = new Font("Malgun Gothic", 8.5f, FontStyle.Bold)
            };
            b.FlatAppearance.BorderSize = 1;
            return b;
        }

        private Button CreateBrowserButton(Point location, Size size)
        {
            Button b = new Button
            {
                Location = location,
                Size = size,
                FlatStyle = FlatStyle.Flat,
                BackColor = CardBg,
                ForeColor = TextMain,
                Cursor = Cursors.Hand,
                Font = new Font("Malgun Gothic", 11f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };
            b.FlatAppearance.BorderColor = BorderColor;
            b.FlatAppearance.BorderSize = 2;
            b.FlatAppearance.MouseOverBackColor = CardHover;
            return b;
        }

        private void SetLanguage(string lang)
        {
            if (isBusy) return;
            currentLang = lang == "en" ? "en" : "ko";
            BrowserInstallerEngine.ApplyExtensionLanguagePreference(extFolder, currentLang);
            UpdateTranslations();
        }

        private void UpdateTranslations()
        {
            bool en = currentLang == "en";
            bool isAdmin = BrowserInstallerEngine.IsAdministrator();

            Text = en
                ? "AI Pulse v1.8.0 — Automated Installer & Setup"
                : "AI Pulse v1.8.0 — 자동화 설치 및 설정 도우미";

            lblBadge.Text = isAdmin
                ? (en ? "🛡️ ADMINISTRATOR MODE · AI PULSE v1.8.0" : "🛡️ 관리자 권한 실행됨 · AI PULSE v1.8.0")
                : (en ? "AI PULSE v1.8.0 SETUP" : "AI PULSE v1.8.0 설치 도우미");

            lblTitle.Text = en
                ? "Select Browser for AI Pulse"
                : "사용할 웹 브라우저를 선택하세요";

            lblSubtitle.Text = en
                ? "Automatically enables Developer Mode, registers the AI Pulse extension, and binds the AI-Pulse folder without manual browsing."
                : "선택한 브라우저(Edge 또는 Chrome)에 확장 프로그램을 자동으로 등록하고 AI-Pulse 폴더 지정 및 언어 설정까지 한 번에 완료합니다.";

            lblLangTitle.Text = en
                ? "🌐 Language (언어 설정)"
                : "🌐 사용 언어 설정 (Language)";

            btnLangKo.BackColor = !en ? AccentLime : Color.FromArgb(36, 42, 48);
            btnLangKo.ForeColor = !en ? Color.FromArgb(15, 20, 0) : TextMain;
            btnLangKo.FlatAppearance.BorderColor = !en ? AccentLime : BorderColor;

            btnLangEn.BackColor = en ? AccentLime : Color.FromArgb(36, 42, 48);
            btnLangEn.ForeColor = en ? Color.FromArgb(15, 20, 0) : TextMain;
            btnLangEn.FlatAppearance.BorderColor = en ? AccentLime : BorderColor;

            lblFolderTitle.Text = en
                ? "📁 Auto-Detected AI-Pulse Extension Directory"
                : "📁 자동 지정된 AI-Pulse 확장 프로그램 폴더";

            lblBrowserPrompt.Text = en
                ? "Choose which browser to install & configure [Edge / Chrome]:"
                : "어떤 웹 프로그램에서 사용할지 선택해 주세요 [Edge / Chrome]:";

            string edgeState = !string.IsNullOrEmpty(edgeExe)
                ? (en ? "✓ Installed · Click to Auto-Register" : "✓ 설치됨 · 클릭 시 자동 등록")
                : (en ? "Not Detected" : "미설치");
            btnEdge.Text = "🌐 Microsoft Edge\n\n" + edgeState;
            btnEdge.Enabled = !isBusy && !string.IsNullOrEmpty(edgeExe);

            string chromeState = !string.IsNullOrEmpty(chromeExe)
                ? (en ? "✓ Installed · Click to Auto-Register" : "✓ 설치됨 · 클릭 시 자동 등록")
                : (en ? "Not Detected" : "미설치");
            btnChrome.Text = "🌐 Google Chrome\n\n" + chromeState;
            btnChrome.Enabled = !isBusy && !string.IsNullOrEmpty(chromeExe);

            if (!isBusy)
            {
                lblStatus.Text = en
                    ? "Ready. Click [Microsoft Edge] or [Google Chrome] above to start automatic setup."
                    : "준비 완료. 위에서 [Microsoft Edge] 또는 [Google Chrome] 버튼을 누르면 자동으로 등록됩니다.";
            }
        }

        private async Task StartInstallAsync(BrowserKind browser)
        {
            if (isBusy) return;
            isBusy = true;
            btnEdge.Enabled = false;
            btnChrome.Enabled = false;
            btnLangKo.Enabled = false;
            btnLangEn.Enabled = false;
            progressBar.Visible = true;
            progressBar.Style = ProgressBarStyle.Marquee;

            InstallOptions opts = new InstallOptions
            {
                Browser = browser,
                Language = currentLang,
                ExtensionFolder = extFolder
            };

            InstallResult res = await Task.Run(() =>
                BrowserInstallerEngine.RunInstallation(opts, statusMsg =>
                {
                    if (IsHandleCreated)
                    {
                        BeginInvoke(new Action(() =>
                        {
                            lblStatus.ForeColor = AccentLime;
                            lblStatus.Text = statusMsg;
                        }));
                    }
                }));

            isBusy = false;
            progressBar.Style = ProgressBarStyle.Continuous;
            progressBar.Value = res.Success ? 100 : 0;
            btnLangKo.Enabled = true;
            btnLangEn.Enabled = true;
            UpdateTranslations();

            lblStatus.ForeColor = res.Success ? AccentLime : Color.FromArgb(255, 110, 150);
            lblStatus.Text = res.Message;

            MessageBox.Show(
                this,
                res.Message,
                currentLang == "en" ? "AI Pulse v1.8.0 Setup" : "AI Pulse v1.8.0 자동 설치 완료",
                MessageBoxButtons.OK,
                res.Success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }
    }

    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            bool silent = false;
            bool closeAfter = false;
            bool skipAdminCheck = false;
            string cliBrowser = null;
            string cliLang = "ko";
            string cliExtDir = null;
            string cliUserDataDir = null;
            string cliLogFile = null;

            foreach (string rawArg in args)
            {
                string a = rawArg.Trim();
                if (a.Equals("--silent", StringComparison.OrdinalIgnoreCase)) silent = true;
                else if (a.Equals("--close-after", StringComparison.OrdinalIgnoreCase)) closeAfter = true;
                else if (a.Equals("--no-elevate", StringComparison.OrdinalIgnoreCase)) skipAdminCheck = true;
                else if (a.StartsWith("--browser=", StringComparison.OrdinalIgnoreCase)) cliBrowser = a.Substring(10).Trim('"');
                else if (a.StartsWith("--lang=", StringComparison.OrdinalIgnoreCase)) cliLang = a.Substring(7).Trim('"');
                else if (a.StartsWith("--ext-dir=", StringComparison.OrdinalIgnoreCase)) cliExtDir = a.Substring(10).Trim('"');
                else if (a.StartsWith("--user-data-dir=", StringComparison.OrdinalIgnoreCase)) cliUserDataDir = a.Substring(16).Trim('"');
                else if (a.StartsWith("--log=", StringComparison.OrdinalIgnoreCase)) cliLogFile = a.Substring(6).Trim('"');
            }

            if (!skipAdminCheck && !BrowserInstallerEngine.IsAdministrator())
            {
                try
                {
                    ProcessStartInfo elevatePsi = new ProcessStartInfo
                    {
                        FileName = Application.ExecutablePath,
                        Arguments = string.Join(" ", args),
                        Verb = "runas",
                        UseShellExecute = true
                    };
                    Process.Start(elevatePsi);
                    return 0;
                }
                catch
                {
                    if (!silent)
                    {
                        MessageBox.Show(
                            "이 프로그램은 관리자 권한이 필요합니다. 관리자 권한으로 다시 실행해 주세요.\nThis installer requires Administrator privileges.",
                            "AI Pulse Setup",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                    return 1;
                }
            }

            if (!string.IsNullOrEmpty(cliBrowser))
            {
                BrowserKind kind = cliBrowser.Equals("edge", StringComparison.OrdinalIgnoreCase)
                    ? BrowserKind.Edge
                    : BrowserKind.Chrome;
                InstallOptions opts = new InstallOptions
                {
                    Browser = kind,
                    Language = cliLang,
                    ExtensionFolder = cliExtDir,
                    CustomUserDataDir = cliUserDataDir,
                    CloseBrowserAfter = closeAfter,
                    Silent = silent
                };
                InstallResult res = BrowserInstallerEngine.RunInstallation(opts, msg => Console.WriteLine(msg));
                string finalLine = res.Success ? "RESULT: SUCCESS" : "RESULT: FAILED - " + res.Message;
                Console.WriteLine(finalLine);
                if (!string.IsNullOrEmpty(cliLogFile))
                {
                    try
                    {
                        List<string> lines = new List<string>(res.Logs);
                        lines.Add(finalLine);
                        File.WriteAllLines(cliLogFile, lines.ToArray(), new UTF8Encoding(false));
                    }
                    catch { }
                }
                return res.Success ? 0 : 2;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new InstallerForm(cliLang));
            return 0;
        }
    }
}
