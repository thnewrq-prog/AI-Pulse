/* Runs only after the user presses '잔액 위치 지정' / 'Bind Balance' on the dashboard. */
globalThis.PulsePicker=(()=>{
  let stop;
  const t=(key,vars)=>globalThis.PulseI18n?PulseI18n.t(key,vars):key;
  const locale=()=>globalThis.PulseI18n?PulseI18n.locale():'ko-KR';
  function resolveNumericTarget(target){
    let el=target;
    if(el&&(el.namespaceURI==='http://www.w3.org/2000/svg'||['SVG','PATH','G','CIRCLE','RECT','USE','IMG','I'].includes(el.tagName?.toUpperCase()))){
      el=el.closest('button,a,span,div,p,strong,b,label')||el.parentElement;
    }
    for(let i=0;i<3&&el&&el.parentElement&&el.tagName!=='BODY';i++){
      const txt=PulseBinding.text(el);
      if(/[0-9]/.test(txt))break;
      const pText=PulseBinding.text(el.parentElement);
      if(/[0-9]/.test(pText)&&pText.length<=160)el=el.parentElement;
      else break;
    }
    return el;
  }
  function start(id,nonce,lang='ko'){
    stop?.();
    if(globalThis.PulseI18n&&lang)PulseI18n.setLang(lang);
    const provider=globalThis.PROVIDERS?.[id]||{name:id,type:'credits'};
    const host=document.createElement('div');
    host.setAttribute('data-ai-pulse-picker','');
    host.style.cssText='position:fixed;inset:auto 18px 18px auto;z-index:2147483647;max-width:380px;';
    const shadow=host.attachShadow({mode:'open'}),sheet=new CSSStyleSheet();
    sheet.replaceSync(':host{font:13px/1.65 "Segoe UI","Malgun Gothic",sans-serif;color:#1b3124}section{background:#fff;border:2px solid #28513b;border-radius:14px;padding:18px;box-shadow:0 8px 34px #0004}h3{font-size:15px;margin:0 0 8px;display:flex;align-items:center;justify-content:space-between;gap:8px}h3 span{font-size:11px;font-weight:600;background:#e7f4ec;color:#24593c;padding:2px 8px;border-radius:99px}p{margin:6px 0;color:#384d3f}button,select{font:inherit;border:1px solid #c6d6c9;border-radius:7px;padding:6px 11px;background:#f3f7f2;color:#1b3124;cursor:pointer;margin:6px 6px 0 0}button:hover{background:#e4efe7}button.primary{background:#214e36;color:#fff;border-color:#214e36;font-weight:600}button.primary:hover{background:#183b28}select{width:100%;margin-top:6px;background:#fff}.preview-box{background:#f5f9f6;border:1px solid #d5e4d8;border-radius:8px;padding:8px 10px;margin:8px 0;font-size:12px}.preview-box strong{display:block;font-size:14px;color:#173d28;overflow-wrap:anywhere}.parsed-badge{display:inline-block;margin-top:4px;font-size:11px;color:#216b4c;font-weight:600}small{display:block;color:#6f8072;font-size:11px;margin-top:4px}');
    shadow.adoptedStyleSheets=[sheet];
    const panel=document.createElement('section');
    shadow.append(panel);
    document.documentElement.append(host);
    let mode='browse',selected=null,steps=[],oldOutline='',selectedElement=null,hoverElement=null,hoverOutline='';
    function clearHover(){
      if(hoverElement){
        if(hoverElement!==selectedElement)hoverElement.style.outline=hoverOutline;
        hoverElement=null;
      }
    }
    function restore(){
      clearHover();
      if(selectedElement){selectedElement.style.outline=oldOutline;selectedElement=null;}
    }
    function cleanup(){
      restore();
      document.removeEventListener('click',capture,true);
      document.removeEventListener('mousemove',move,true);
      document.removeEventListener('keydown',key,true);
      host.remove();
      stop=null;
    }
    stop=cleanup;
    function button(label,fn,primary=false){
      const b=document.createElement('button');
      b.textContent=label;
      if(primary)b.className='primary';
      b.onclick=event=>{if(event.isTrusted)fn(event);};
      panel.append(b);
      return b;
    }
    function show(message,badge=t('picker.step1Badge')){
      panel.replaceChildren();
      const h=document.createElement('h3');
      h.textContent='AI Pulse · '+provider.name;
      const tag=document.createElement('span');
      tag.textContent=badge;
      h.append(tag);
      panel.append(h);
      const p=document.createElement('p');
      p.textContent=message;
      panel.append(p);
    }
    let livePreview=null;
    function begin(){
      mode='browse';
      restore();
      show(t('picker.step1Msg'),t('picker.step1Badge'));
      if(steps.length){
        const stepNote=document.createElement('small');
        stepNote.textContent=t('picker.stepsRecorded',{count:steps.length});
        panel.append(stepNote);
      }
      button(t('picker.startPickBtn'),()=>{
        mode='pick';
        show(t('picker.step2Msg'),t('picker.step2Badge'));
        livePreview=document.createElement('div');
        livePreview.className='preview-box';
        livePreview.innerHTML=`<small>${t('picker.hoverHint')}</small><strong>—</strong>`;
        panel.append(livePreview);
        button(t('picker.reopenMenuBtn'),begin);
        button(t('picker.cancelBtn'),cleanup);
      },true);
      if(steps.length)button(t('picker.resetStepsBtn'),()=>{steps=[];begin();});
      button(t('picker.cancelBtn'),cleanup);
    }
    function review(rawEl){
      const el=resolveNumericTarget(rawEl);
      const value=PulseBinding.text(el),css=PulseBinding.selector(el);
      const numbers=PulseBinding.extractNumbers(value);
      if(!css||!numbers.length||value.length>200){
        show(t('picker.retryMsg'),t('picker.retryBadge'));
        button(t('picker.retryPickBtn'),()=>{
          mode='pick';
          show(t('picker.step2Msg'),t('picker.step2Badge'));
          livePreview=document.createElement('div');
          livePreview.className='preview-box';
          livePreview.innerHTML=`<small>${t('picker.hoverHint')}</small><strong>—</strong>`;
          panel.append(livePreview);
          button(t('picker.cancelBtn'),cleanup);
        },true);
        button(t('picker.cancelBtn'),cleanup);
        return;
      }
      mode='review';
      restore();
      selectedElement=el;
      oldOutline=el.style.outline;
      el.style.outline='3px solid #216b4c';
      selected={selector:css,tag:el.tagName,steps,numberIndex:0};
      show(t('picker.step3Msg'),t('picker.step3Badge'));
      const box=document.createElement('div');
      box.className='preview-box';
      const small=document.createElement('small');
      small.textContent=t('picker.selectedText');
      const strong=document.createElement('strong');
      strong.textContent=value;
      const parsedInfo=document.createElement('span');
      parsedInfo.className='parsed-badge';
      box.append(small,strong,parsedInfo);
      panel.append(box);

      let numberSelect=null;
      if(numbers.length>1){
        const numLabel=document.createElement('small');
        numLabel.textContent=t('picker.multiNumHint');
        panel.append(numLabel);
        numberSelect=document.createElement('select');
        numbers.forEach((n,idx)=>{
          const o=document.createElement('option');
          o.value=String(idx);
          o.textContent=t('picker.nthNumber',{n:idx+1,val:n});
          numberSelect.append(o);
        });
        panel.append(numberSelect);
      }

      const unit=document.createElement('select');
      for(const [v,label] of [
        ['credits',t('picker.unitCredits')],
        ['gpu_hours',t('picker.unitGpuHours')],
        ['gpu_minutes',t('picker.unitGpuMinutes')]
      ]){
        const o=document.createElement('option');
        o.value=v;
        o.textContent=label;
        unit.append(o);
      }
      unit.value=provider.type==='gpu'?(/minutes?|mins?|분|\dm\b/i.test(value)?'gpu_minutes':'gpu_hours'):'credits';
      panel.append(unit);

      function updateParsedPreview(){
        const idx=numberSelect?Number(numberSelect.value):0;
        selected.numberIndex=idx;
        const m=PulseBinding.parse(value,unit.value,idx);
        const unitLabel=m?.unit==='gpu_minutes'?(PulseI18n?.getLang()==='en'?'mins (GPU)':'분 (GPU)'):'credits';
        parsedInfo.textContent=m?t('picker.parsedOk',{amount:m.amount.toLocaleString(locale()),unit:unitLabel}):t('picker.parsedFail');
      }
      unit.onchange=updateParsedPreview;
      if(numberSelect)numberSelect.onchange=updateParsedPreview;
      updateParsedPreview();

      button(t('picker.saveBindBtn'),async()=>{
        const idx=numberSelect?Number(numberSelect.value):0;
        const metric=PulseBinding.parse(value,unit.value,idx);
        if(!metric){
          show(t('picker.parseErrorMsg'),t('picker.errorBadge'));
          button(t('picker.retryPickBtn'),begin,true);
          button(t('picker.cancelBtn'),cleanup);
          return;
        }
        const binding={...selected,unit:unit.value,numberIndex:idx};
        try{
          const response=await chrome.runtime.sendMessage({type:'save-binding',id,nonce,binding,metric});
          if(response?.error)throw Error(response.error);
          const unitLabel=metric.unit==='gpu_minutes'?(PulseI18n?.getLang()==='en'?'mins':'분'):'credits';
          show(t('picker.doneMsg',{amount:metric.amount.toLocaleString(locale()),unit:unitLabel}),t('picker.doneBadge'));
          button(t('picker.doneCloseBtn'),cleanup,true);
        }catch(e){
          show(t('picker.saveFailMsg',{error:e.message}),t('picker.errorBadge'));
          button(t('picker.retrySaveBtn'),()=>review(el),true);
          button(t('picker.closeBtn'),cleanup);
        }
      },true);

      if(el.parentElement&&el.parentElement.tagName!=='BODY'&&PulseBinding.text(el.parentElement).length<=180){
        button(t('picker.parentBtn'),()=>review(el.parentElement));
      }
      button(t('picker.retryPickBtn'),()=>{
        restore();
        mode='pick';
        show(t('picker.step2Msg'),t('picker.step2Badge'));
        livePreview=document.createElement('div');
        livePreview.className='preview-box';
        livePreview.innerHTML=`<small>${t('picker.hoverHint')}</small><strong>—</strong>`;
        panel.append(livePreview);
        button(t('picker.cancelBtn'),cleanup);
      });
      button(t('picker.cancelBtn'),cleanup);
    }
    function move(e){
      if(mode!=='pick'||e.composedPath().includes(host))return;
      const target=resolveNumericTarget(e.target);
      if(!target||target===hoverElement||target===document.body||target===document.documentElement)return;
      clearHover();
      hoverElement=target;
      hoverOutline=target.style.outline;
      const txt=PulseBinding.text(target);
      const hasNum=/[0-9]/.test(txt)&&txt.length<=200;
      target.style.outline=hasNum?'2px dashed #1f7a4c':'1px dashed #9aa59d';
      if(livePreview){
        const nums=PulseBinding.extractNumbers(txt);
        livePreview.innerHTML=`<small>${hasNum?t('picker.detectedNums',{nums:nums.join(', ')}):t('picker.hoverNumHint')}</small><strong>${(txt||'—').slice(0,80)}</strong>`;
      }
    }
    function capture(e){
      if(e.composedPath().includes(host)||!e.isTrusted)return;
      const el=e.target.closest?.('button,a,[role="button"],[role="tab"],[role="menuitem"],summary,[aria-haspopup]');
      if(mode==='browse'){
        const target=el||e.target;
        const kind=PulseBinding.classify(target)||'custom',css=PulseBinding.selector(target);
        if(css&&steps.length<8&&steps.at(-1)?.selector!==css)steps.push({kind,selector:css});
        return;
      }
      if(mode!=='pick')return;
      e.preventDefault();
      e.stopImmediatePropagation();
      let target=e.target;
      if(target.closest('input,textarea,[contenteditable="true"]'))return;
      review(target);
    }
    function key(e){if(e.key==='Escape')cleanup();}
    document.addEventListener('click',capture,true);
    document.addEventListener('mousemove',move,true);
    document.addEventListener('keydown',key,true);
    begin();
    return true;
  }
  return {start};
})();
