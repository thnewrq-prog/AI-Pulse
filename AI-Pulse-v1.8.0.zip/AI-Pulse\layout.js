/* Display preferences only. Account connections and history are independent. */
globalThis.PulseLayout=(()=>{
  const defaults=()=>({order:Object.keys(PROVIDERS),hidden:[]});
  function clean(value){
    const ids=Object.keys(PROVIDERS),known=new Set(ids);
    const order=[...new Set(Array.isArray(value?.order)?value.order.filter(id=>known.has(id)):[])];
    return {order:[...order,...ids.filter(id=>!order.includes(id))],hidden:[...new Set(Array.isArray(value?.hidden)?value.hidden.filter(id=>known.has(id)):[])]};
  }
  const visible=value=>{const layout=clean(value);return layout.order.filter(id=>!layout.hidden.includes(id));};
  function move(value,id,target){const layout=clean(value),from=layout.order.indexOf(id),to=layout.order.indexOf(target);if(from<0||to<0||from===to)return layout;layout.order.splice(from,1);layout.order.splice(to,0,id);return layout;}
  const refreshOrder=ids=>[...ids].sort((a,b)=>({midjourney:0,higgsfield:1,comfy:2}[a]??3)-({midjourney:0,higgsfield:1,comfy:2}[b]??3));
  return {defaults,clean,visible,move,refreshOrder};
})();
