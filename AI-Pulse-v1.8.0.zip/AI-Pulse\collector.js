/* Injected only when requested, in an isolated world on an allowed provider. */
globalThis.PulseCollector = (() => {
  const visible = e => !!e && !e.closest('[hidden],[aria-hidden="true"]') && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden';
  const text = e => String(e?.innerText || e?.textContent || '').trim();
  const quota = /usage|사용량|사용\s*한도|이용\s*한도|plan\s*limits|weekly\s*limits/i;
  const direction = /\bused\b|consumed|remaining|\bleft\b|남[은음아]|잔여|사용[됨했한]|소진|사용\s*가능/i;
  const period = /current\s*session|session\s*limit|weekly|daily|5\s*hour|주간|세션|현재\s*세션|일일|한도/i;
  function scopes() {
    const exactHeading=/^(?:usage(?:\s+limits)?|plan\s+usage\s+limits|사용량(?:\s*한도)?|이용\s*한도)$/i;
    const dialogs = [...document.querySelectorAll('[role="dialog"],dialog,[role="tabpanel"]')].filter(visible).filter(e => [...e.querySelectorAll('h1,h2,h3,[role="heading"]')].some(h=>visible(h)&&exactHeading.test(text(h))) || exactHeading.test(e.getAttribute('aria-label')||''));
    if (dialogs.length) return dialogs;
    // A conversation body must never be treated as a quota page.
    if (/^\/settings\/usage\/?$/.test(location.pathname)) return [document.querySelector('main') || document.body];
    if(!/\/(?:settings|usage)(?:\/|$)/i.test(location.pathname) && !/settings/i.test(location.hash))return [];
    const headings = [...document.querySelectorAll('h1,h2,h3,[role="heading"]')].filter(visible).filter(e => /^(?:usage(?:\s+limits)?|plan\s+usage\s+limits|사용량(?:\s*한도)?|이용\s*한도)$/i.test(text(e)));
    return headings.map(h => {
      let el = h.parentElement;
      for (let i=0; el && i<4; i++, el=el.parentElement) {
        if (el.querySelector('[role="progressbar"],meter,progress') || /\d\s*[%％]/.test(text(el))) return el;
      }
      return h.parentElement;
    }).filter(Boolean);
  }
  function collect(id, binding=null) {
    if(binding&&globalThis.PulseBinding){
      const bound=PulseBinding.read(document,binding);
      if(bound)return {metrics:[bound],viewFound:true,checkedAt:new Date().toISOString()};
    }
    if(id==='gpt'&&globalThis.PulseGPTCollector)return PulseGPTCollector.collect();
    if(globalThis.PROVIDERS?.[id]?.type&&globalThis.CreditCollector)return CreditCollector.collect(id);
    const areas = scopes();
    const blocks = [];
    for (const area of areas) {
      const lines = text(area).split('\n').map(s=>s.trim()).filter(Boolean);
      // Extract only bounded metric rows, never the whole page or chat content.
      for (let i=0; i<lines.length; i++) {
        const line=lines[i];
        if (!/\d{1,3}(?:[.,]\d+)?\s*[%％]/.test(line)) continue;
        const before=lines.slice(Math.max(0,i-3),i).filter(l=>!/%/.test(l));
        const near = [...before,line,lines[i+1]||''].join(' ');
        if (!direction.test(line) && !direction.test(lines[i+1]||'')) continue;
        const label=before.slice(-2).join(' · ') || (period.test(line) ? line : '');
        const reset=lines.slice(i+1,i+4).find(l=>/reset|refresh|재설정|초기화|갱신/i.test(l)) || '';
        const after=lines[i+1]||'';
        blocks.push({label, valueText:line+' '+(!direction.test(line)&&direction.test(after)&&!/%|％/.test(after)?after:''), context:'Usage '+near,reset});
      }
      for (const bar of area.querySelectorAll('[role="progressbar"],meter,progress')) {
        if (!visible(bar)) continue;
        let row=bar.parentElement;
        for (let i=0;i<3 && row && text(row).length<8;i++) row=row.parentElement;
        if (!row || text(row).length > 800) continue;
        const rowText=text(row), aria=bar.getAttribute('aria-valuetext')||'';
        const label=bar.getAttribute('aria-label') || rowText.split('\n').filter(s=>!/%/.test(s)).slice(0,2).join(' · ');
        const raw=bar.getAttribute('aria-valuenow') ?? bar.getAttribute('value');
        const max=bar.getAttribute('aria-valuemax') ?? bar.getAttribute('max') ?? '100';
        blocks.push({label,valueText:aria || (direction.test(rowText)?rowText:''),value:raw===null||raw.trim()===''?null:Number(raw),max:Number(max),context:'Usage '+rowText,reset:rowText.split('\n').find(l=>/reset|refresh|재설정|초기화|갱신/i.test(l))||''});
      }
    }
    const metrics=UsageParser.parseBlocks(blocks);
    return {metrics, viewFound:areas.length>0, checkedAt:new Date().toISOString()};
  }
  async function openUsage() {
    if (scopes().length) return true;
    const clickExact = patterns => {
      const controls=[...document.querySelectorAll('button,a,[role="menuitem"],[role="tab"]')].filter(visible);
      const el=controls.find(e=>patterns.some(p=>p.test((e.getAttribute('aria-label')||text(e)).trim())));
      if(el){el.click();return true;} return false;
    };
    const pause=ms=>new Promise(r=>setTimeout(r,ms));
    const usagePatterns=[/^(?:usage(?:\s+limits)?|사용량(?:\s*한도)?|이용\s*한도)$/i];
    if(clickExact(usagePatterns)){await pause(1000);return scopes().length>0;}
    // Navigation-only controls. Never click model, purchase, credit, or app-cap menus.
    const settings=[/^(?:settings(?:\s*(?:&|and)\s*help)?|설정(?:\s*(?:및|과|&)\s*도움말)?)$/i];
    if(!clickExact(settings)) {
      clickExact([/^(?:open\s+profile\s+menu|profile(?:\s+menu)?|account(?:\s+menu)?|프로필(?:\s*메뉴)?|계정(?:\s*메뉴)?)$/i]);
      await pause(400);clickExact(settings);
    }
    await pause(600);clickExact(usagePatterns);await pause(1100);
    return scopes().length>0;
  }
  return {collect,openUsage};
})();
